import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router, CanActivateChild } from '@angular/router';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { AuthRolesConstants } from 'src/app/shared/constants/auth-roles.constants';
import { UserAuthService } from 'src/app/shared/service/user-auth.service';
import { UserService } from '../service/user.service';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivateChild, CanActivate {
  userData: any;
  public userDetails = new BehaviorSubject<any>({});
  public customerSearch = this.userDetails.asObservable();
  constructor(private userAuthService: UserAuthService, private userService: UserService, private http: HttpClient, private router: Router) { }

  canActivateChild(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    let url = route.url[0].path;
    // let securityLevel = this.userAuthService.userAuth.securityLevel?.split(',').map(x => +x);
    let accessGranted = false;
    return true;
  }

  async canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    //let userObj = this.userService.getUserDetails();
    let userObj = {
      app: 'cpr',
      appId: 27,
      userId: this.userService.getUserDetails().attuid,
      orgCode: this.userService.getUserDetails().orgCode
    }
    let user:any = await this.userAuthService.userAuth;
    if (user.securityLevel === null && user.accessGranted === null) {
      user = await this.http.post(environment.commonApiBaseUrl + '/common/userAuth', userObj).toPromise();
    }
    this.userDetails.next(user);
    
    if (user) {
      let lvl = user?.securityLevel?.split(',');
      user.securityLevel = lvl[lvl?.length - 1];
      // check if route is restricted by role
      if (route?.data?.securityLevel && route?.data?.securityLevel?.indexOf(user['securityLevel']) == -1) {
        // role not authorised so redirect to home page
        if (user['securityLevel'] == "5") {
          this.router.navigate(['/application-reports']);
          return true;
        }
        this.router.navigate(['/']);
        return false;
      }
      // authorised so return true
      return true;
    }

    // not logged in so redirect to login page with the return url
    this.router.navigate(['/login'], { queryParams: { returnUrl: state.url } });
    return false;
}
}
