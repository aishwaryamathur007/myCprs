import { Injectable } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CanDeactivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable, Subject } from 'rxjs';
import { ConfirmComponent } from 'src/app/common/component/confirm/confirm.component';
import { StandaloneCommitmentComponent } from 'src/app/cpr-views/standalone-commitment/standalone-commitment.component';

@Injectable({
  providedIn: 'root'
})
export class ConfirmguardGuard implements CanDeactivate<StandaloneCommitmentComponent> {
  constructor(public dialog: MatDialog,
    public router: Router) {

  }

  canDeactivate(
    component: StandaloneCommitmentComponent,
    currentRoute: ActivatedRouteSnapshot,
    currentState: RouterStateSnapshot,
    nextState?: RouterStateSnapshot
  ):
    | Observable<boolean | UrlTree>
    | Promise<boolean | UrlTree>
    | boolean
    | UrlTree {
    console.log('deactivate');
    let subject = new Subject<boolean>();
    component.openDialog();
    subject = component.subject;
    return subject.asObservable();
  }
}
