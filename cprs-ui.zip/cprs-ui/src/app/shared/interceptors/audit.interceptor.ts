import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor } from '@angular/common/http';
import { Observable } from 'rxjs';
import { UserService } from 'src/app/shared/service/user.service';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';

@Injectable()
export class AuditInterceptor implements HttpInterceptor {

    constructor(private userService: UserService,
        private router: Router) { }
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        let auditData = `${this.userService.getUserDetails().attuid}||${this.router.url}||27||${environment.env}`;
        request = request.clone({
            headers: request.headers.set('Audit-Data', auditData)
        });
        return next.handle(request);
    }
}
