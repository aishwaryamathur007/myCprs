import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpErrorResponse,
  HttpResponse,
} from '@angular/common/http';
import { EMPTY, Observable, of, throwError } from 'rxjs';
import { catchError, switchMap } from 'rxjs/operators';
//import { doesNotThrow } from 'assert';
//import { error } from 'console';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ErrorNotificationComponent } from 'src/app/common/component/error-notification/error-notification.component';
import { NotificationService } from 'src/app/common/services/notification.service';
import { IpServiceService } from 'src/app/ipservice.service';

@Injectable()
export class ErrorInterceptor implements HttpInterceptor {
  constructor(
    private snackBar: MatSnackBar,
    private notifService: NotificationService,
    private ipService: IpServiceService
  ) {}
  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<any> {
    return this.ipService.getIPAddress().pipe(
      switchMap((res: any) => {
        const ipAddress = res;
        const modifiedReq = request.clone({
          headers: request.headers.set('Remote-Address', `${ipAddress}`),
        });
        return next.handle(modifiedReq).pipe(
          catchError((errRequest: HttpErrorResponse) => {
            switch (errRequest.status) {
              case 200: {
                // Convert the error to a standard response with a null body and then return
                return of(
                  new HttpResponse({
                    headers: errRequest.headers,
                    status: errRequest.status,
                    statusText: errRequest.statusText,
                    url: errRequest.url,
                    body: errRequest.error.text
                  })
                );
              }
              case 417: {
                if (errRequest.error instanceof Blob) {
                  return throwError(errRequest);
                } else {
                  this.notifService.showWarningNotification(
                    errRequest.error.message
                  );
                  return of(
                    new HttpResponse({
                      body: errRequest.error?.result ?? [],
                    })
                  );
                }
              }
              // case 400: {
              //   if (errRequest.error instanceof Blob) {
              //     return throwError(errRequest);
              //   } else {
              //     this.notifService.showErrorNotification(
              //       errRequest.error.message
              //     );
              //     return of(
              //       new HttpResponse({
              //         body: errRequest.error.message || JSON.parse(errRequest.error).message || [], 
              //       })
              //     );
              //   }
              // }

              case 504: {
                this.notifService.showErrorNotification(
                  'Sorry, an error occurred! Please refresh the page and narrow down the search criteria.'
                );
                return of(
                  new HttpResponse({
                    body: errRequest.status
                  })
                );
              }

              default: {
                //console.error(errRequest);
                if (errRequest?.error instanceof Blob) {
                  let x = errRequest?.error as Blob;
                  let reader = new FileReader();
                  reader.readAsText(x);
                  let errorObject = null;
                  // tslint:disable-next-line: variable-name
                  let _this = this;
                  // tslint:disable-next-line: space-before-function-paren
                  reader.onload = function () {
                    errorObject = JSON.parse(this.result as string);
                    _this.snackBar.openFromComponent(
                      ErrorNotificationComponent,
                      {
                        data: {
                          errorDetails: errorObject,
                          app: 'cprs',
                        },
                        verticalPosition: 'top',
                        horizontalPosition: 'center',
                      }
                    );
                  };
                } else {
                  this.snackBar.openFromComponent(ErrorNotificationComponent, {
                    data: {
                      errorDetails: typeof (errRequest.error) === 'string' ? JSON.parse(errRequest.error) : errRequest.error,
                      app: 'cprs',
                    },
                    verticalPosition: 'top',
                    horizontalPosition: 'center',
                  });
                }

                return of(
                  new HttpResponse({
                    body: null,
                  })
                );
              }
            }
          })
        );
      })
    );
  }
}
