export class AuthRolesConstants {

    public static readonly CPRS_ADMIN_USER = 1;
}
