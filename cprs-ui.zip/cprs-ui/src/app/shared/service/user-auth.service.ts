import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { UserDetails, UserService } from 'src/app/shared/service/user.service';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class UserAuthService {

  static authCheckComplete: Subject<boolean> = new Subject<boolean>();
  public userDeatils:Subject<any> = new Subject();
  userAuth: UserAuth = new UserAuth();
  constructor(private http: HttpClient,
    private userService: UserService) {

  }

  getUserAuthentication() {


    let cookies: Array<string> = document.cookie.split(';');
    let userAuthFromCookies: UserAuth = new UserAuth();
    cookies.forEach(c => {
      let values = c.trim().split('=');
      if (this.userAuth.hasOwnProperty(values[0])) {
        userAuthFromCookies[values[0]] = values[1];
      }
    });

    if (userAuthFromCookies.securityLevel &&
      userAuthFromCookies.app === 'cpr' &&
      userAuthFromCookies.userId === this.userService.getUserDetails().attuid) {

      userAuthFromCookies.userId = this.userService.getUserDetails().attuid;
      userAuthFromCookies.orgCode = this.userService.getUserDetails().orgCode;
      userAuthFromCookies.app = 'cpr'; // Should match with appl_code_nm_tx of appls table
      userAuthFromCookies.appId = 27;
      this.userAuth = userAuthFromCookies;
      this.userDeatils.next(this.userAuth);
      setTimeout(() => {
        UserAuthService.authCheckComplete.next(true);
      }, 300);

    } else {

      this.userAuth.userId = this.userService.getUserDetails().attuid;
      this.userAuth.orgCode = this.userService.getUserDetails().orgCode;
      this.userAuth.app = 'cpr'; // Should match with appl_code_nm_tx of appls table
      this.userAuth.appId = 27;
      this.http.post<UserAuth>(environment.commonApiBaseUrl + '/common/userAuth', this.userAuth)
        .toPromise().then(resp => {
          this.userAuth = resp;
          this.userDeatils.next(resp);
          if (resp.securityLevel) {
            this.setCookies(resp);
          }
          setTimeout(() => {
            UserAuthService.authCheckComplete.next(true);
          }, 300);
        });



    }
  }

  setCookies(obj) {
    for (let key in obj) {
      if (obj.hasOwnProperty(key)) {
        if (!['userVars'].includes(key)) {
          document.cookie = `${key}=;Path=/;expires=Thu, 01 Jan 1970 00:00:01 GMT;`;
          document.cookie = `${key}=${obj[key]};Path=/`;
        }

      }
    }
  }
}

export class UserAuth {
  userId: string = '';
  app: string = '';
  appId: number;
  orgCode: string = '';
  whl: string = '';
  indKy: string = '';
  govRestNd: string = '';
  aebm: string = '';
  securityLevel: string = null;
  accessGranted: boolean = null;
  userVars: any[] = [];
}
