import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { UserDetails, UserService } from 'src/app/shared/service/user.service';
import { UserAuthService } from 'src/app/shared/service/user-auth.service';
import { environment } from 'src/environments/environment';
import { environment as envProd } from 'src/environments/environment.prod';
import { environment as envDev } from 'src/environments/environment.dev';
import { environment as envTest } from 'src/environments/environment.test';

@Injectable({
  providedIn: 'root'
})
export class AppInitService {

  userDetails: UserDetails = null;

  constructor(private userService: UserService,
    private http: HttpClient,
    private userAuth: UserAuthService) { }

  async initApp() {

    let hostname = window.location.hostname;

    if (hostname.includes('absweb.dev.att.com')) {

      Object.keys(environment).forEach(keys => {
        environment[keys] = envDev[keys];
      });

    } else if (hostname.includes('absweb.test.att.com')) {
      Object.keys(environment).forEach(keys => {
        environment[keys] = envTest[keys];
      });

    } else if (hostname.includes('absdw.web.att.com')) {
      Object.keys(environment).forEach(keys => {
        environment[keys] = envProd[keys];
      });

    }

    if (environment.env === 'local') {
      await this.getUserLoginDetails().then(resp => {
        this.userDetails = resp;
        this.userService.setUserDetails(resp);
        this.userAuth.getUserAuthentication();
      });

      return;
    }

    if (this.checkCookies()) {
      let user: UserDetails = this.getUserFromCookies();
      this.userService.setUserDetails(user);
      this.userAuth.getUserAuthentication();
      return;
    }

    const urlParams = new URLSearchParams(window.location.search);
    const code = urlParams.get('code');
    const state = urlParams.get('state')?.split('?')[0] ?? null;
    const paramObj = urlParams.get('state')?.split('?')[1] ?? null;

    if (code && state) {
      urlParams.delete('code');
      urlParams.delete('state');

      let newURL = `${location.pathname}`;
      if (paramObj) {

        let params = JSON.parse(decodeURIComponent(paramObj));
        let searchString = '';
        for (const key in params) {
          if (params[key]) {
            searchString = searchString + `${key}=${params[key]}&`;
          }
        }
        searchString = searchString.substr(0, searchString.length - 1);
        newURL = newURL + `?${searchString}`;
      }
      window.history.replaceState({}, '', newURL);

      await this.getUserLoginDetails(code, state).then(resp => {
        this.userDetails = resp;
        this.userService.setUserDetails(resp);
        this.setCookies(resp);
        this.userAuth.getUserAuthentication();
      });
    } else {

      let params = new URLSearchParams(window.location.search);
      let obj = {};
      params.forEach((value, key) => {
        obj = { ...obj, ... { [key]: value } };
      });

      let url = '?' + encodeURIComponent(JSON.stringify(obj));
      let stateText = (Math.random().toString(36) + Math.random().toString(36) + Math.random().toString(36) + Math.random().toString(36) + Math.random().toString(36)).replace(/[^a-z^1-9]+/g, '').substr(0, 20);
      let oidcRedirectURL = environment.oidcUrl;
      oidcRedirectURL = oidcRedirectURL.replace('#stateString#', stateText + url);
      oidcRedirectURL = oidcRedirectURL.replace('#redirectUri#', window.location.origin + window.location.pathname);

      location.href = oidcRedirectURL;
    }

  }

  getUserFromCookies(): UserDetails {
    let user: UserDetails = {
      attuid: this.getCookie('attuid'),
      email: this.getCookie('email'),
      firstName: this.getCookie('firstName'),
      lastName: this.getCookie('lastName'),
      fullName: this.getCookie('fullName'),
      orgCode: this.getCookie('orgCode')
    };

    return user;
  }

  checkCookies() {
    if (this.getCookie('attuid') && this.getCookie('orgCode') && this.getCookie('email') &&
      this.getCookie('firstName') && this.getCookie('fullName') && this.getCookie('lastName')) {
      return true;
    }
    return false;
  }

  setCookies(obj) {
    for (let key in obj) {
      if (obj.hasOwnProperty(key)) {
        document.cookie = `${key}=${obj[key]};Path=/`;
      }
    }
  }

  getCookie(name: string) {
    let ca: Array<string> = document.cookie.split(';');
    let caLen: number = ca.length;
    let cookieName = `${name}=`;
    let c: string;

    for (let i: number = 0; i < caLen; i += 1) {
      c = ca[i].replace(/^\s+/g, '');
      if (c.indexOf(cookieName) === 0) {
        return c.substring(cookieName.length, c.length);
      }
    }
    return '';
  }

  getUserLoginDetails(code?, state?) {

    return new Promise<UserDetails>((resolve, reject) => {
      if (environment.env === 'local') {
        this.http.get<UserDetails>('assets/json/local-user.json').subscribe(res => {
          resolve(res);
        }, err => {
          reject();
        });
      } else {
        this.http.post<UserDetails>(environment.commonApiBaseUrl + '/common/authLogin', {
          code: code,
          state: state,
          redirectUri: window.location.origin + window.location.pathname
        }).subscribe(res => {
          resolve(res);
        }, err => {
          reject();
        });
      }
    });
  }
}

