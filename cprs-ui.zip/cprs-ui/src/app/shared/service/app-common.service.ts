import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})
export class AppCommonService {

  constructor(private http: HttpClient) { }

  getDowntime(): Observable<any> {
    return this.http.get(environment.commonApiBaseUrl + '/common/getDowntimeForApp', {
      params: {
        appId: '27'
      }
    });
  }

  getVersionInfoForCommon(): Observable<any> {
    return this.http.get(environment.commonApiBaseUrl + '/common/versionDetails', {
      responseType: 'text' as 'json'
    });
  }

  getVersionInfoForCprs(): Observable<any> {
    return this.http.get(environment.cprApiBaseUrl + '/common/getVersion', {
      responseType: 'text' as 'json'
    });
  }
}
