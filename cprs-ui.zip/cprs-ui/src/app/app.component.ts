import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'Commitment Performance Reporting';
  ngOnInit() {
    window.addEventListener("click", function (event: any) {
      let snackEl = document.getElementsByClassName('mat-snack-bar-container').item(0);
      if (snackEl) {
        snackEl.remove();
      }
    });
  }
}
