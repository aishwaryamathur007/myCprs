import { BrowserModule } from '@angular/platform-browser';
import { APP_INITIALIZER, NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LayoutComponent } from './layout/layout.component';
import { SharedModule } from 'src/app/shared/root-material/shared.module';
import { FlexLayoutModule } from '@angular/flex-layout';
import { SideNavMenuItemComponent } from './layout/side-nav-menu-item/side-nav-menu-item.component';
import { CommonModule } from '@angular/common';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { CommonReportTableModule } from '@report-table-library/common-report-table';
import { NgApexchartsModule } from 'ng-apexcharts';
import { AppCommonModule } from 'src/app/common/app-common.module';
import { AuditInterceptor } from 'src/app/shared/interceptors/audit.interceptor';
import { ErrorInterceptor } from 'src/app/shared/interceptors/error.interceptor';
import { AppInitService } from 'src/app/shared/service/app-init.service';
import { environment } from 'src/environments/environment';


@NgModule({
  declarations: [
    AppComponent,
    LayoutComponent,
    SideNavMenuItemComponent
  ],
  imports: [
    CommonModule,
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    SharedModule,
    FlexLayoutModule,
    HttpClientModule,
    NgApexchartsModule,
    AppCommonModule,
    CommonReportTableModule.forRoot(environment)
  ],
  providers: [{
    provide: HTTP_INTERCEPTORS,
    useClass: AuditInterceptor,
    multi: true
  }, {
    provide: APP_INITIALIZER,
    useFactory: appInitProviderFactory,
    deps: [AppInitService],
    multi: true
  }, {
    provide: HTTP_INTERCEPTORS,
    useClass: ErrorInterceptor,
    multi: true
  }],
  bootstrap: [AppComponent]
})
export class AppModule { }

export function appInitProviderFactory(provider: AppInitService) {
  return () => provider.initApp();
}
