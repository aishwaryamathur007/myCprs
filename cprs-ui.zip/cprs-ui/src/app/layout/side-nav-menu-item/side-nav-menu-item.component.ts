import { AfterViewInit, Component, Input, OnInit, ViewChild } from '@angular/core';
import { MatMenu, MatMenuTrigger } from '@angular/material/menu';
import { NavigationEnd, Router } from '@angular/router';
import { UserAuthService } from 'src/app/shared/service/user-auth.service';

@Component({
  selector: 'side-nav-menu-item',
  templateUrl: './side-nav-menu-item.component.html',
  styleUrls: ['./side-nav-menu-item.component.scss']
})
export class SideNavMenuItemComponent implements OnInit, AfterViewInit {

  @Input() sideNavItem;
  @Input() menuExpanded;
  AccessRole: any;
  @ViewChild('menuTrigger', { static: false }) set matMenuTrigger(mt: MatMenuTrigger) {
    this.childMenuTrigger = mt;
  }
  @ViewChild('menu', { static: false }) menu: MatMenu;
  childMenuTrigger: MatMenuTrigger;
  isOpen = false;
  panelClasses = ['overlay', 'mat-elevation-z8'];
  constructor(private router: Router,private userAuthService:UserAuthService) { 
    let lvl = this.userAuthService.userAuth.securityLevel.split(',');
    this.AccessRole = lvl[lvl.length - 1];

  }

  ngAfterViewInit(): void {

  }

  ngOnInit(): void {
    this.router.events.subscribe((route => {
      if (route instanceof NavigationEnd) {
        if (this.sideNavItem.isGroup) {
          let currentbaseRoute = route.urlAfterRedirects.substring(1);
          currentbaseRoute = currentbaseRoute.substring(0, currentbaseRoute.indexOf('/'));
          this.checkActive(route.urlAfterRedirects, currentbaseRoute);
        } else {
          this.checkActive(route.urlAfterRedirects);
        }

      }
    }));

    let initialUrl = this.router.url;
    let baseRoute = initialUrl.substring(1);
    baseRoute = baseRoute.substring(0, baseRoute.indexOf('/'));
    this.checkActive(initialUrl, baseRoute);
  }

  checkActive(route, baseRoute = '') {

    if (this.sideNavItem.isGroup) {
      if (baseRoute === this.sideNavItem.baseRoute) {
        this.sideNavItem.isSelected = true;

        this.sideNavItem.children.forEach(element => {
          if (route.includes(element.route)) {
            this.sideNavItem.isOpen = true;
            element.selected = true;
          } else {
            element.selected = false;
          }
        });
      } else {
        this.sideNavItem.isSelected = false;
        this.sideNavItem.isOpen = false;
        this.sideNavItem.children.forEach(element => {
          element.selected = false;
        });
      }
    } else {
      if (route.includes(this.sideNavItem.route)) {
        this.sideNavItem.isSelected = true;
      } else {
        this.sideNavItem.isSelected = false;
      }
    }
  }

  itemClicked(): void {
    if (this.sideNavItem.isGroup) {
      if (this.menuExpanded) {
        this.sideNavItem.isOpen = !this.sideNavItem.isOpen;
      } else {
        this.childMenuTrigger.openMenu();
      }

    } else {
      this.router.navigate([this.sideNavItem.route]);
    }

  }

  childItemClicked(item) {
    if (!this.menuExpanded) {
      this.childMenuTrigger.closeMenu();
    }

    if (item.externalLink) {
      location.href = item.link;
    } else {
      this.router.navigate([this.sideNavItem.baseRoute, item.route]);
    }

  }

  getTooltip() {
    if (this.menuExpanded) {
      return ``;
    } else {
      return `${this.sideNavItem.label}`;
    }
  }

}
