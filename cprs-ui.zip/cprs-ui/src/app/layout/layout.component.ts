import { Component, OnInit, DoCheck, ChangeDetectorRef, VERSION } from '@angular/core';
import { UserService } from 'src/app/shared/service/user.service';
import { AppCommonService } from '../shared/service/app-common.service';

import { UserAuthService } from 'src/app/shared/service/user-auth.service';

@Component({
  selector: 'layout',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.scss']
})
export class LayoutComponent implements OnInit {


  isMenuOpen: boolean = false;
  isTablet: boolean = false;
  checkingAuth = true;
  accessGranted = false;
  version = VERSION.full;

  navigationOptions: any[] = [
    {
      icon: 'person_search', label: 'Common Search', route: 'dashboard', disabled: false, isOpen: false, isHidden: false, isSelected: false,securityLevel: ['1', '2', '3', '4', '5', '6', '7', '8', '9']
    },
    // {
    //   icon: 'description', label: 'List Group', baseRoute: 'bookmark', disabled: false, isGroup: true, isHidden: false, isOpen: false,
    //   children: [
    //     { label: 'My Reports', route: 'my-reports', disabled: false, selected: false }
    //   ]
    // },
    {
      icon: 'description', label: 'Customer Contract', baseRoute: 'customer-contract', disabled: false, isGroup: true, isOpen: false, isHidden: false,securityLevel: ['1', '3'],
      children: [
        { label: 'Customer Contract Maintenance', route: 'customer-contract-maintenance', disabled: false, selected: false,securityLevel: ['1', '3'] },
        { label: 'Contract Assignment', route: 'contract-assignment', disabled: false, selected: false,securityLevel: ['1', '3'] },
        { label: 'PSC Contract Service Mapping', route: 'psc-contract', disabled: false, isOpen: false, isHidden: false, isSelected: false,securityLevel: ['1', '3'] },

      ]
    },

    {
      icon: 'article', label: 'Service Mapping', baseRoute: 'service-mapping', disabled: false, isGroup: true, isOpen: false, isHidden: false,securityLevel: ['1', '3'],
      children: [
        { label: 'SVID/Enterprise Service Mapping', route: 'svid-enterprise-service-mapping', disabled: false, selected: false,securityLevel: ['1', '3'] },
        //  { label: 'Profile Management', route: 'profile-management', disabled: false, selected: false },
        //   { label: 'Contract Assignment', route: 'contract-assignment', disabled: false, selected: false },
        // { label: 'PSC Contract Service Mapping', route: 'psc-contract', disabled: false, selected: false },
        { label: 'Service Mapping Review/Approval', route: 'review-approval', disabled: false, selected: false,securityLevel: ['1', '3'] },
        { label: 'Reference Data Maintenance', route: 'reference-data', disabled: false, selected: false,securityLevel: ['1', '3'] },
        { label: 'UB Service for Standalone Commitment', route: 'standalone-commitment', disabled: false, selected: false,securityLevel: ['1', '3'] },

      ]
    }, {
      icon: 'format_list_bulleted', label: 'Review Worklist', baseRoute: 'review-work', disabled: false, isGroup: true, isOpen: false, isHidden: false,securityLevel: ['1', '3'],
      children: [
        { label: 'Contract Review Worklist', route: 'contract-review', disabled: false, selected: false,securityLevel: ['1', '3'] },
        { label: 'Contract Error Worklist', route: 'contract-error-worklist', disabled: false, selected: false,securityLevel: ['1', '3'] },
        { label: 'ICT Error Worklist', route: 'ict-error', disabled: false, selected: false,securityLevel: ['1', '3'] }
      ]
    }, {
      icon: 'equalizer', label: 'Application Reports', route: 'application-reports', disabled: false, isOpen: false, isHidden: false, isSelected: false,securityLevel: ['1', '3', '4', '5', '7', '9']
    },
    {
      icon: 'bookmarks', label: 'My Bookmarks', baseRoute: 'bookmark', disabled: false, isGroup: true, isHidden: false, isOpen: false,securityLevel: ['1', '3', '4', '5', '7', '9'],
      children: [
        { label: 'My Reports', route: 'my-reports', disabled: false, selected: false,securityLevel: ['1', '3', '4', '5', '7', '9'] }
      ]
    }, {
      icon: 'search', label: 'CPID Search', route: 'cpid-search', disabled: false, isOpen: false, isHidden: false, isSelected: false,securityLevel: ['1', '3']
    },
    //  {
    //   icon: 'format_list_bulleted', label: 'Contract Worklist', baseRoute: 'contract-worklist', disabled: false, isGroup: true, isHidden: false, isOpen: false,
    //   children: [
    //     { icon: 'quiz', label: 'Review Worklist', route: 'review', disabled: false, selected: false },
    //     { icon: 'quiz', label: 'Error Worklist', route: 'error', disabled: false, selected: false },
    //     { icon: 'quiz', label: 'ITC Worklist', route: 'itc', disabled: false, selected: false }
    //   ]
    // },
    {
      icon: 'live_help', label: 'Guides', baseRoute: 'guides', disabled: false, isGroup: true, isHidden: false, isOpen: false,securityLevel: ['1', '2', '3', '4', '5', '6', '7', '8', '9'],
      children: [
        { label: 'Help', route: 'help', disabled: false, selected: false,securityLevel: ['1', '2', '3', '4', '5', '6', '7', '8', '9'] },
        { icon: 'quiz', label: 'FAQ', route: 'faq', disabled: false, selected: false,securityLevel: ['1', '2', '3', '4', '5', '6', '7', '8', '9'] }
      ]
    }
  ];

  user: string = '';
  commonApiVersion: any;
  cprsApiVersion: any;

  constructor(private userService: UserService,
    private userAuthService: UserAuthService,
    private appCommonService: AppCommonService,
    private cdr: ChangeDetectorRef) {
    this.getVersionInfoForCommonApi();
    this.getVersionInfoForFmcApi();


    this.user = (userService.firstName + ' ' + userService.lastName).split(' ')
      .map(w => w[0].toUpperCase() + w.substr(1).toLowerCase())
      .join(' ');
  }

  ngOnInit(): void {
    UserAuthService.authCheckComplete.subscribe(val => {
      this.checkingAuth = !val;
      this.accessGranted = this.userAuthService.userAuth.accessGranted;
      this.setURLAccesss();
      document.getElementById('splash-screen').remove();
    });
  }


  setURLAccesss() {
    if (this.accessGranted) {
    }
  }

  getVersionInfoForCommonApi() {
    this.appCommonService.getVersionInfoForCommon().subscribe(resp => {
      this.commonApiVersion = resp;
    });
  }

  getVersionInfoForFmcApi() {
    this.appCommonService.getVersionInfoForCprs().subscribe(resp => {
      this.cprsApiVersion = resp;
    });
  }

  sideMenuToggle(): void {
    this.isMenuOpen = !this.isMenuOpen;
  }

  windowResized() {
    this.isTablet = this.isTabletMode() ? true : false;
  }

  isTabletMode(): boolean {
    if (window.screen.width <= 1024) {
      return true;
    }

    return false;
  }

  contentClicked() {
    this.isMenuOpen = false;
  }

  navigateToDwweb() {
    location.href = '/home';
  }

  navigateToFeedback() {
    location.href = '/feedback?from=cprs';
  }

}
