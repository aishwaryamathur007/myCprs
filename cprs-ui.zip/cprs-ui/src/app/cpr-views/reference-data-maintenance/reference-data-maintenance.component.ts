import { SelectionModel } from '@angular/cdk/collections';
import { Component, OnInit, ViewChild, OnChanges, DoCheck, ChangeDetectorRef } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSelect } from '@angular/material/select';
import { MatPaginator } from '@angular/material/paginator';
import { MatTable, MatTableDataSource } from '@angular/material/table';
import { FormBuilder, FormControl, FormGroup, Validators, FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ReferenceDataService } from '../service/reference-data.service';
import { MatSort } from '@angular/material/sort';
import { AddComponent } from './modals/add/add.component';
import { EditComponent } from './modals/edit/edit.component';
import { ConfirmComponent } from 'src/app/common/component/confirm/confirm.component';
import { ConfigType } from 'src/app/common/component/confirm/model/confirm-config';
//import { element } from 'protractor';
import { filter } from 'rxjs/operators';
import { NotificationService } from 'src/app/common/services/notification.service';
import { UserDetails, UserService } from 'src/app/shared/service/user.service';


export interface ReferenceMaintenanceDetails {
  radio?: any;
  lastUpdateDate: string;
  lastUpdateUserId: string;
  status: string;
  statusCode: string;
}

@Component({
  selector: 'reference-data-maintenance',
  templateUrl: './reference-data-maintenance.component.html',
  styleUrls: ['./reference-data-maintenance.component.scss']
})
export class ReferenceDataMaintenanceComponent implements OnInit {
  condition: any;
  select: any;
  @ViewChild(MatSelect, { static: false }) matSelect: MatSelect;
  obj: any;
  constructor(private router: Router, private referenceDataService: ReferenceDataService, private fb: FormBuilder, public dialog: MatDialog, private userService: UserService, private notifService: NotificationService, private cdr: ChangeDetectorRef) {
    this.user = this.userService.getUserDetails();
  }

  referenceForm: FormGroup;
  options = ['Adjustment Reason', 'Status', 'Activity Type'];
  option: any;
  load: boolean = false;
  mode: string = 'search';
  paginator: any;
  sort: any;
  pageSize = 100;
  reportData: any;
  isSubmitted: boolean = false;
  isSubmit: boolean = true;
  dropDownDetails: any;
  selection = new SelectionModel<ReferenceMaintenanceDetails>(true, []);
  selectedRecords: any = [];
  reportDetailsColumns: string[] = [];
  columnsData: string[] = [];
  selectedRow: any = {};
  addEditDelArray: any = [];
  addArray: any = [];
  updateArray: any = [];
  deleteArray: any = [];
  selectedArray: any = [];
  finalObject: any = {};
  result: any;
  change: boolean = false;
  filter: any;
  DateNow: any;
  user: any;
  highLevelActivityTypes = ['Commitment', 'Credit', 'Debit'];
  activitySubTypeId: any;
  highLevelActivityTypeId: any;
  activityUnitCode: any;

  reportDetailsColumnsA: string[] = [
    'action',
    'adjustmentReasonId',
    'adjustmentReasonDescription',
    'lastUpdateDate',
    'lastUpdateUserId'
  ];
  columnsDataA: string[] = [
    'Action',
    'Adjustment Reason Id',
    'Adjustment Reason Description',
    'Last Update Date',
    'Last Update User Id'
  ];

  reportDetailsColumnsB: string[] = [
    'action',
    'status',
    'lastUpdateDate',
    'lastUpdateUserId'
  ];
  columnsDataB: string[] = [
    'Action',
    'Status',
    'Last Update Date',
    'Last Update User Id'
  ];

  reportDetailsColumnsC: string[] = [
    'action',
    'activityType',
    'activityDescription',
    'highLevelActivityType',
    'activitySubType',
    'activityUnit',
    'lastUpdateDate',
    'lastUpdateUserId'
  ];
  columnsDataC: string[] = [
    'Action',
    'Activity Type',
    'Activity Description',
    'High Level Activity Type',
    'Activity Sub Type',
    'Activity Unit',
    'Last Update Date',
    'Last Update User Id'
  ];


  dataSource: MatTableDataSource<any>;

  @ViewChild('paginator', { static: false }) set matPaginator(
    mp: MatPaginator
  ) {
    this.paginator = mp;
    if (mp && this.dataSource) {
      console.log('this.dataSource', this.dataSource);
      this.dataSource.paginator = this.paginator;
    }

  }

  @ViewChild('sort', { static: false }) set matSort(ms: MatSort) {
    this.sort = ms;

    if (ms && this.dataSource) {
      this.dataSource.sort = this.sort;
    }
  }

  ngOnInit(): void {
    this.setupForm();
    this.dataSource = new MatTableDataSource();
    this.DateNow = new Date(Date.now()).toLocaleString().split(',')[0];
  }

  windowResized() {
    setTimeout(() => { }, 750);
  }

  setupForm(): void {
    this.referenceForm = this.fb.group({
      option: new FormControl(this.options[0], [Validators.required])
    });
    this.fetchDetails();
  }
  onSelect() {
    if (this.addEditDelArray.length !== 0) {
      const dialogCheck = this.dialog.open(ConfirmComponent, {
        data: {
          type: ConfigType.Confirm,
          content: `The entire changes you have made will be discarded. Do you want to continue?`
        }
      });

      dialogCheck.afterClosed().subscribe(result => {
        if (result) {
          console.log('result', result);
          this.addEditDelArray = [];
          this.fetchDetails();
        } else {
          this.change = true;
          this.clearFilters();
          this.referenceForm.controls['option'].setValue(this.option);
          // this.option = event.value;
          // this.matSelect.close();
          console.log('this.option in select', this.option);
        }
      });
    } else {
      this.clearFilters();
      this.fetchDetails();
    }

  }
  fetchDetails() {

    // this.selectedArray = [];
    // this.selectedRecords = [];
    this.finalObject = null;
    this.option = this.referenceForm.get('option').value;
    console.log('option', this.option);
    this.isSubmitted = true;
    this.referenceDataService.getReferenceTableData(this.option).subscribe((resp: any) => {
      console.log('resp', resp);
      if (resp.adjustmentReason) {
        this.reportDetailsColumns = this.reportDetailsColumnsA;
        this.columnsData = this.columnsDataA;
        this.reportData = resp.adjustmentReason;
      } else if (resp.status) {
        this.reportDetailsColumns = this.reportDetailsColumnsB;
        this.columnsData = this.columnsDataB;
        this.reportData = resp.status;
      } else {
        this.reportDetailsColumns = this.reportDetailsColumnsC;
        this.columnsData = this.columnsDataC;
        this.reportData = resp.activityType;
      }
      console.log('this.reportData', this.reportData);
      this.dataSource = new MatTableDataSource(this.reportData);
      this.isSubmitted = false;
      this.mode = 'view';
      // this.reportData = [];
      console.log('this.reportData in fetchdetails', this.reportData);
    });
    if (this.option === 'Activity Type') {

      this.referenceDataService.getDropdownDetails().subscribe((resp: any) => {
        this.dropDownDetails = resp;
        console.log('this.dropDownDetails', this.dropDownDetails);
      });
    }



  }

  addDialog() {
    this.addEditDelArray = [];
    let object: any = { option: this.option, dropDownDetails: this.dropDownDetails };

    const dialogRef = this.dialog.open(AddComponent, {
      data: object,
      minWidth: '50%'
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result != null) {
        let receivedObj = result;
        this.obj = result;
        console.log('receivedObj', receivedObj);
        // this.reportData.unshift(receivedObj);
        // this.dataSource = new MatTableDataSource(this.reportData);
        // this.dataSource.paginator = this.paginator;
        // this.dataSource.sort = this.sort;
        this.isSubmit = false;
        console.log('this.reportData', this.reportData);
        const obj = { ...receivedObj, ...{ lastUpdateDate: undefined } };
        console.log(' receivedObj after add', receivedObj);
        this.addEditDelArray.push(obj);
        console.log('this.addEditDelArray', this.addEditDelArray);
        this.submit();
        this.clearFilters();
      }

    });

  }

  editRow(ele: any) {
    this.addEditDelArray = [];
    if (this.option === 'Adjustment Reason') {
      let object: any = { option: this.option, dropDownDetails: this.dropDownDetails, values: ele };
      const dialogRef = this.dialog.open(EditComponent, {
        data: object,
        minWidth: '50%'
      });
      dialogRef.afterClosed().subscribe(result => {
        if (result != null) {
          let receivedObj = result;
          console.log('receivedObj', receivedObj);
          console.log('this.reportData in dialog', this.reportData);
          console.log('receivedObj.adjustmentReasonId', receivedObj.adjustmentReasonId);
          const obj = { ...receivedObj, ...{ lastUpdateDate: undefined } };
          console.log(' receivedObj after add', receivedObj);
          this.addEditDelArray.push(obj);
          console.log('this.addEditDelArray', this.addEditDelArray);
          // this.reportData.map(id => {
          //   if ((id.adjustmentReasonId !== undefined) && (id.adjustmentReasonId === receivedObj.adjustmentReasonId)) {

          //     console.log('receivedObj.adjustmentReasonId', receivedObj.adjustmentReasonId);
          //     const obj = { ...receivedObj, ...{ lastUpdateDate: undefined } };
          //     console.log(' receivedObj after add', receivedObj);
          //     this.addEditDelArray.push(obj);
          //     console.log('this.addEditDelArray', this.addEditDelArray);
          //     id.adjustmentReasonDescription = receivedObj.adjustmentReasonDescription;
          //     id.lastUpdateDate = receivedObj.lastUpdateDate;
          //     id.lastUpdateUserId = receivedObj.lastUpdateUserId;
          //   }

          // });
          this.submit();
        }
      });
    } else if (this.option === 'Status') {
      let object: any = { option: this.option, dropDownDetails: this.dropDownDetails, values: ele };

      const dialogRef = this.dialog.open(EditComponent, {
        data: object,
        minWidth: '50%'
      });
      dialogRef.afterClosed().subscribe(result => {
        if (result != null) {
          let receivedObj = result;
          console.log('receivedObj', receivedObj);
          console.log('this.reportData in dialog', this.reportData);
          const obj = { ...receivedObj, ...{ lastUpdateDate: undefined } };
          this.addEditDelArray.push(obj);
          console.log('this.addEditDelArray', this.addEditDelArray);
          // this.reportData.map(id => {
          //   if ((id.statusCode !== undefined) && (id.statusCode === receivedObj.statusCode)) {

          //     console.log('receivedObj.statusCode', receivedObj.statusCode);
          //     this.selectedRecords.forEach(element2 => {
          //       console.log('this.selectedRecords in edit before', this.selectedRecords);
          //       console.log('this.selectedRow', this.selectedRow);
          //       if (this.selectedRow.status === element2) {
          //         let index1 = this.selectedRecords.indexOf(element2);
          //         this.selectedRecords[index1] = receivedObj.status;
          //         console.log('this.selectedRecords in edit in con', this.selectedRecords);
          //       }

          //     });

          //     id.status = receivedObj.status;
          //     id.lastUpdateDate = receivedObj.lastUpdateDate;
          //     id.lastUpdateUserId = receivedObj.lastUpdateUserId;
          //   }
          // });
          this.submit();
        }
      });
    } else {
      let object: any = { option: this.option, dropDownDetails: this.dropDownDetails, values: ele };

      const dialogRef = this.dialog.open(EditComponent, {
        data: object,
        minWidth: '50%'
      });

      dialogRef.afterClosed().subscribe(result => {
        if (result != null) {
          let receivedObj = result;
          console.log('receivedObj', receivedObj);
          console.log('this.reportData in dialog', this.reportData);
          const obj = { ...receivedObj, ...{ lastUpdateDate: undefined } };
          this.addEditDelArray.push(obj);
          console.log('this.addEditDelArray', this.addEditDelArray);
          // this.reportData.map(id => {
          //   if ((id.activityId !== undefined) && (id.activityId === receivedObj.activityId)) {

          //     console.log('receivedObj.activityId', receivedObj.activityId);
          //     this.selectedRecords.forEach(element2 => {
          //       console.log('this.selectedRecords in edit before', this.selectedRecords);
          //       console.log('this.selectedRow', this.selectedRow);
          //       if (this.selectedRow.activityDescription === element2) {
          //         let index1 = this.selectedRecords.indexOf(element2);
          //         this.selectedRecords[index1] = receivedObj.activityDescription;
          //         console.log('this.selectedRecords in edit in con', this.selectedRecords);
          //       }

          //     });
          //     id.activityDescription = receivedObj.activityDescription;
          //     id.activityType = receivedObj.activityType;
          //     id.highLevelActivityType = receivedObj.highLevelActivityType;
          //     id.activitySubType = receivedObj.activitySubType;
          //     id.lastUpdateDate = receivedObj.lastUpdateDate;
          //     id.lastUpdateUserId = receivedObj.lastUpdateUserId;
          //   }
          // });
          this.submit();
        }
      });
    }
    this.clearFilters();
  }


  edit() {
    console.log('this.selectedRecords in edit', this.selectedRecords);
    console.log('this.this.selectedRow', this.selectedRow);
    if (this.selectedRecords.length === 0) {
      console.log('this.selectedRecords in len = 0', this.selectedRecords);
      const dialogCheck = this.dialog.open(ConfirmComponent, {
        data: {
          type: ConfigType.Confirm,
          content: `Please select one Row to edit.`
        }
      });

      dialogCheck.afterClosed().subscribe(result => {
        if (result) {
          console.log('Done');
        }
      });
    } else if (this.selectedRecords.length > 1) { // removed this.addEditDelArray.length === 0
      const dialogCheck1 = this.dialog.open(ConfirmComponent, {
        data: {
          type: ConfigType.Confirm,
          content: `Please select only one Row to edit.`
        }
      });

      dialogCheck1.afterClosed().subscribe(result => {
        if (result) {
          console.log('Done');
          console.log('this.selectedRow in simple', this.selectedRow);
        }
      });
    } else if (this.selectedRow && this.addEditDelArray.length === 0) {
      console.log('1');
      console.log('(this.selectedRow', this.selectedRow);
      if (this.option === 'Adjustment Reason') {
        console.log('2');
        let object: any = { option: this.option, dropDownDetails: this.dropDownDetails, values: this.selectedRow };

        const dialogRef = this.dialog.open(EditComponent, {
          data: object,
          minWidth: '50%'
        });
        dialogRef.afterClosed().subscribe(result => {
          if (result != null) {
            let receivedObj = result;
            console.log('receivedObj', receivedObj);
            console.log('this.reportData in dialog', this.reportData);
            this.reportData.map(id => {
              // console.log('id', id);
              // console.log('this.reportData------', this.reportData);
              if ((id.adjustmentReasonId !== undefined) && (id.adjustmentReasonId === receivedObj.adjustmentReasonId)) {

                console.log('receivedObj.adjustmentReasonId', receivedObj.adjustmentReasonId);
                // let index = this.reportData.indexOf(id);
                // console.log('index in .......', index);
                // this.reportData[index] = receivedObj;
                this.selectedRecords.forEach(element2 => {
                  console.log('this.selectedRecords in edit before', this.selectedRecords);
                  console.log('this.selectedRow', this.selectedRow);
                  if (this.selectedRow.adjustmentReasonDescription === element2) {
                    let index1 = this.selectedRecords.indexOf(element2);
                    this.selectedRecords[index1] = receivedObj.adjustmentReasonDescription;
                    console.log('this.selectedRecords in edit in con', this.selectedRecords);
                  }

                });
                // this.selectedRecords.splice(0, 1);
                console.log('this.selectedRecords in edit after', this.selectedRecords);
                const obj = { ...receivedObj, ...{ lastUpdateDate: undefined } };
                console.log(' receivedObj after add', receivedObj);
                this.addEditDelArray.push(obj);
                console.log('this.addEditDelArray', this.addEditDelArray);
                id.adjustmentReasonDescription = receivedObj.adjustmentReasonDescription;
                id.lastUpdateDate = receivedObj.lastUpdateDate;
                id.lastUpdateUserId = receivedObj.lastUpdateUserId;
                // this.dataSource = new MatTableDataSource(this.reportData);
                // this.dataSource.paginator = this.paginator;
                // this.dataSource.sort = this.sort;
                this.isSubmit = false;
                console.log('this.reportData in edit', this.reportData);
                this.selectedRecords = [];
                // if ((id.adjustmentReasonId !== undefined) && (id.adjustmentReasonId === receivedObj.adjustmentReasonId)) {
                //   id.adjustmentReasonDescription = receivedObj.adjustmentReasonDescription;
                // }
              }
            });
          }
        });
      }
      if (this.option === 'Status') {
        console.log('2');
        let object: any = { option: this.option, dropDownDetails: this.dropDownDetails, values: this.selectedRow };

        const dialogRef = this.dialog.open(EditComponent, {
          data: object,
          minWidth: '50%'
        });
        dialogRef.afterClosed().subscribe(result => {
          if (result != null) {
            let receivedObj = result;
            console.log('receivedObj', receivedObj);
            console.log('this.reportData in dialog', this.reportData);
            this.reportData.map(id => {
              // console.log('id', id);
              // console.log('this.reportData------', this.reportData);
              if ((id.statusCode !== undefined) && (id.statusCode === receivedObj.statusCode)) {

                console.log('receivedObj.statusCode', receivedObj.statusCode);
                // let index = this.reportData.indexOf(id);
                // console.log('index in .......', index);
                // this.reportData[index] = receivedObj;
                this.selectedRecords.forEach(element2 => {
                  console.log('this.selectedRecords in edit before', this.selectedRecords);
                  console.log('this.selectedRow', this.selectedRow);
                  if (this.selectedRow.status === element2) {
                    let index1 = this.selectedRecords.indexOf(element2);
                    this.selectedRecords[index1] = receivedObj.status;
                    console.log('this.selectedRecords in edit in con', this.selectedRecords);
                  }

                });
                // this.selectedRecords.splice(0, 1);
                console.log('this.selectedRecords in edit after', this.selectedRecords);
                const obj = { ...receivedObj, ...{ lastUpdateDate: undefined } };
                this.addEditDelArray.push(obj);
                console.log('this.addEditDelArray', this.addEditDelArray);
                id.status = receivedObj.status;
                id.lastUpdateDate = receivedObj.lastUpdateDate;
                id.lastUpdateUserId = receivedObj.lastUpdateUserId;
                // this.dataSource = new MatTableDataSource(this.reportData);
                // this.dataSource.paginator = this.paginator;
                // this.dataSource.sort = this.sort;
                this.isSubmit = false;
                console.log('this.reportData in edit', this.reportData);
                this.selectedRecords = [];
              }
            });
          }
        });
      }
      if (this.option === 'Activity Type') {
        console.log('2');
        let object: any = { option: this.option, dropDownDetails: this.dropDownDetails, values: this.selectedRow };

        const dialogRef = this.dialog.open(EditComponent, {
          data: object,
          minWidth: '50%'
        });
        dialogRef.afterClosed().subscribe(result => {
          if (result != null) {
            let receivedObj = result;
            console.log('receivedObj', receivedObj);
            console.log('this.reportData in dialog', this.reportData);
            this.reportData.map(id => {
              // console.log('id', id);
              // console.log('this.reportData------', this.reportData);
              if ((id.activityId !== undefined) && (id.activityId === receivedObj.activityId)) {

                console.log('receivedObj.activityId', receivedObj.activityId);
                // let index = this.reportData.indexOf(id);
                // console.log('index in .......', index);
                // this.reportData[index] = receivedObj;
                this.selectedRecords.forEach(element2 => {
                  console.log('this.selectedRecords in edit before', this.selectedRecords);
                  console.log('this.selectedRow', this.selectedRow);
                  if (this.selectedRow.activityDescription === element2) {
                    let index1 = this.selectedRecords.indexOf(element2);
                    this.selectedRecords[index1] = receivedObj.activityDescription;
                    console.log('this.selectedRecords in edit in con', this.selectedRecords);
                  }

                });
                // this.selectedRecords.splice(0, 1);
                console.log('this.selectedRecords in edit after', this.selectedRecords);
                const obj = { ...receivedObj, ...{ lastUpdateDate: undefined } };
                this.addEditDelArray.push(obj);
                console.log('this.addEditDelArray', this.addEditDelArray);
                id.activityDescription = receivedObj.activityDescription;
                id.activityType = receivedObj.activityType;
                id.highLevelActivityType = receivedObj.highLevelActivityType;
                id.activitySubType = receivedObj.activitySubType;
                id.lastUpdateDate = receivedObj.lastUpdateDate;
                id.lastUpdateUserId = receivedObj.lastUpdateUserId;
                // this.dataSource = new MatTableDataSource(this.reportData);
                // this.dataSource.paginator = this.paginator;
                // this.dataSource.sort = this.sort;
                this.isSubmit = false;
                console.log('this.reportData in edit', this.reportData);
                this.selectedRecords = [];
              }
            });
          }
        });
      }


    } else if (this.selectedRow && this.addEditDelArray.length >= 1) {
      if (this.option === 'Adjustment Reason') {
        console.log('in complex');
        let flag;
        flag = this.addEditDelArray.filter(obj => obj.adjustmentReasonDescription === this.selectedRow.adjustmentReasonDescription || obj.adjustmentReasonId === this.selectedRow.adjustmentReasonId);
        if (flag.length > 0) {
          const dialogCheck = this.dialog.open(ConfirmComponent, {
            data: {
              type: ConfigType.Confirm,
              content: `Please select another Row to edit.`
            }
          });

          dialogCheck.afterClosed().subscribe(result => {
            if (result) {
              console.log('Done');
            }
          });
        } else if (flag.length === 0) {
          let object: any = { option: this.option, dropDownDetails: this.dropDownDetails, values: this.selectedRow };

          const dialogRef = this.dialog.open(EditComponent, {
            data: object,
            minWidth: '50%'
          });
          dialogRef.afterClosed().subscribe(result => {
            if (result != null) {
              let receivedObj = result;
              console.log('receivedObj', receivedObj);
              console.log('this.reportData in dialog', this.reportData);
              this.reportData.map(id => {
                // console.log('id', id);
                // console.log('this.reportData------', this.reportData);
                if ((id.adjustmentReasonId !== undefined) && (id.adjustmentReasonId === receivedObj.adjustmentReasonId)) {

                  console.log('receivedObj.adjustmentReasonId', receivedObj.adjustmentReasonId);
                  // let index = this.reportData.indexOf(id);
                  // console.log('index in .......', index);
                  // this.reportData[index] = receivedObj;
                  this.selectedRecords.forEach(element2 => {
                    console.log('this.selectedRecords in edit before', this.selectedRecords);
                    console.log('this.selectedRow', this.selectedRow);
                    if (this.selectedRow.adjustmentReasonDescription === element2) {
                      let index1 = this.selectedRecords.indexOf(element2);
                      this.selectedRecords[index1] = receivedObj.adjustmentReasonDescription;
                      console.log('this.selectedRecords in edit in con', this.selectedRecords);
                    }

                  });
                  // this.selectedRecords.splice(0, 1);
                  console.log('this.selectedRecords in edit after', this.selectedRecords);
                  const obj = { ...receivedObj, ...{ lastUpdateDate: undefined } };
                  console.log(' receivedObj after add', receivedObj);
                  this.addEditDelArray.push(obj);
                  console.log('this.addEditDelArray', this.addEditDelArray);
                  id.adjustmentReasonDescription = receivedObj.adjustmentReasonDescription;
                  id.lastUpdateDate = receivedObj.lastUpdateDate;
                  id.lastUpdateUserId = receivedObj.lastUpdateUserId;
                  // this.dataSource = new MatTableDataSource(this.reportData);
                  // this.dataSource.paginator = this.paginator;
                  // this.dataSource.sort = this.sort;
                  this.isSubmit = false;
                  console.log('this.reportData in edit', this.reportData);
                  this.selectedRecords = [];
                }
              });
            }
          });

        }

      }
      if (this.option === 'Status') {
        console.log('in complex');
        let flag;
        flag = this.addEditDelArray.filter(obj => obj.status === this.selectedRow.status || obj.statusCode === this.selectedRow.statusCode);
        if (flag.length > 0) {
          const dialogCheck = this.dialog.open(ConfirmComponent, {
            data: {
              type: ConfigType.Confirm,
              content: `Please select another Row to edit.`
            }
          });

          dialogCheck.afterClosed().subscribe(result => {
            if (result) {
              console.log('Done');
            }
          });
        } else if (flag.length === 0) {
          let object: any = { option: this.option, dropDownDetails: this.dropDownDetails, values: this.selectedRow };

          const dialogRef = this.dialog.open(EditComponent, {
            data: object,
            minWidth: '50%'
          });
          dialogRef.afterClosed().subscribe(result => {
            if (result != null) {
              let receivedObj = result;
              console.log('receivedObj', receivedObj);
              console.log('this.reportData in dialog', this.reportData);
              this.reportData.map(id => {
                // console.log('id', id);
                // console.log('this.reportData------', this.reportData);
                if ((id.statusCode !== undefined) && (id.statusCode === receivedObj.statusCode)) {

                  console.log('receivedObj.statusCode', receivedObj.statusCode);
                  // let index = this.reportData.indexOf(id);
                  // console.log('index in .......', index);
                  // this.reportData[index] = receivedObj;
                  this.selectedRecords.forEach(element2 => {
                    console.log('this.selectedRecords in edit before', this.selectedRecords);
                    console.log('this.selectedRow', this.selectedRow);
                    if (this.selectedRow.status === element2) {
                      let index1 = this.selectedRecords.indexOf(element2);
                      this.selectedRecords[index1] = receivedObj.status;
                      console.log('this.selectedRecords in edit in con', this.selectedRecords);
                    }

                  });
                  // this.selectedRecords.splice(0, 1);
                  console.log('this.selectedRecords in edit after', this.selectedRecords);
                  const obj = { ...receivedObj, ...{ lastUpdateDate: undefined } };
                  this.addEditDelArray.push(obj);
                  console.log('this.addEditDelArray', this.addEditDelArray);
                  id.status = receivedObj.status;
                  id.lastUpdateDate = receivedObj.lastUpdateDate;
                  id.lastUpdateUserId = receivedObj.lastUpdateUserId;
                  // this.dataSource = new MatTableDataSource(this.reportData);
                  // this.dataSource.paginator = this.paginator;
                  // this.dataSource.sort = this.sort;
                  this.isSubmit = false;
                  console.log('this.reportData in edit', this.reportData);
                  this.selectedRecords = [];
                }
              });
            }
          });

        }
      }
      if (this.option === 'Activity Type') {
        console.log('in complex');
        let flag;
        flag = this.addEditDelArray.filter(obj => obj.activityDescription === this.selectedRow.activityDescription || obj.activityId === this.selectedRow.activityId);
        if (flag.length > 0) {
          const dialogCheck = this.dialog.open(ConfirmComponent, {
            data: {
              type: ConfigType.Confirm,
              content: `Please select another Row to edit.`
            }
          });

          dialogCheck.afterClosed().subscribe(result => {
            if (result) {
              console.log('Done');
            }
          });
        } else if (flag.length === 0) {
          let object: any = { option: this.option, dropDownDetails: this.dropDownDetails, values: this.selectedRow };

          const dialogRef = this.dialog.open(EditComponent, {
            data: object,
            minWidth: '50%'
          });
          dialogRef.afterClosed().subscribe(result => {
            if (result != null) {
              let receivedObj = result;
              console.log('receivedObj', receivedObj);
              console.log('this.reportData in dialog', this.reportData);
              this.reportData.map(id => {
                // console.log('id', id);
                // console.log('this.reportData------', this.reportData);
                if ((id.activityId !== undefined) && (id.activityId === receivedObj.activityId)) {

                  console.log('receivedObj.activityId', receivedObj.activityId);
                  // let index = this.reportData.indexOf(id);
                  // console.log('index in .......', index);
                  // this.reportData[index] = receivedObj;
                  this.selectedRecords.forEach(element2 => {
                    console.log('this.selectedRecords in edit before', this.selectedRecords);
                    console.log('this.selectedRow', this.selectedRow);
                    if (this.selectedRow.activityDescription === element2) {
                      let index1 = this.selectedRecords.indexOf(element2);
                      this.selectedRecords[index1] = receivedObj.activityDescription;
                      console.log('this.selectedRecords in edit in con', this.selectedRecords);
                    }

                  });
                  // this.selectedRecords.splice(0, 1);
                  console.log('this.selectedRecords in edit after', this.selectedRecords);
                  const obj = { ...receivedObj, ...{ lastUpdateDate: undefined } };
                  this.addEditDelArray.push(obj);
                  console.log('this.addEditDelArray', this.addEditDelArray);
                  id.activityDescription = receivedObj.activityDescription;
                  id.activityType = receivedObj.activityType;
                  id.highLevelActivityType = receivedObj.highLevelActivityType;
                  id.activitySubType = receivedObj.activitySubType;
                  id.lastUpdateDate = receivedObj.lastUpdateDate;
                  id.lastUpdateUserId = receivedObj.lastUpdateUserId;
                  // this.dataSource = new MatTableDataSource(this.reportData);
                  // this.dataSource.paginator = this.paginator;
                  // this.dataSource.sort = this.sort;
                  this.isSubmit = false;
                  console.log('this.reportData in edit', this.reportData);
                  this.selectedRecords = [];
                }
              });
            }
          });

        }
      }



    }

  }

  deleteRow(index: any, obj: any) {
    this.addEditDelArray = [];
    console.log('this.addEditDelArray', this.addEditDelArray);
    if (this.option === 'Adjustment Reason') {
      const dialogCheck1 = this.dialog.open(ConfirmComponent, {
        data: {
          type: ConfigType.Confirm,
          content: `Are you sure you want to delete this record ? Click OK to continue.`
        }
      });
      dialogCheck1.afterClosed().subscribe(result => {
        if (result) {
          console.log('result', result);
          let deleteObj = {
            adjustmentReasonDescription: obj.adjustmentReasonDescription,
            adjustmentReasonId: obj.adjustmentReasonId,
            mode: 'delete'
          };
          this.addEditDelArray.push(deleteObj);
          this.submit();

          console.log('this.addEditDelArray', this.addEditDelArray);
        }

      });
    } else if (this.option === 'Status') {
      const dialogCheck1 = this.dialog.open(ConfirmComponent, {
        data: {
          type: ConfigType.Confirm,
          content: `Are you sure you want to delete this record ? Click OK to continue.`
        }
      });

      dialogCheck1.afterClosed().subscribe(result => {
        if (result) {
          console.log('Done');
          let deleteObj = {
            status: obj.status,
            mode: 'delete'
          };
          this.addEditDelArray.push(deleteObj);
          this.submit();

          console.log('this.addEditDelArray', this.addEditDelArray);
        }

      });

    } else {
      const dialogCheck1 = this.dialog.open(ConfirmComponent, {
        data: {
          type: ConfigType.Confirm,
          content: `Are you sure you want to delete this record ? Click OK to continue.`
        }
      });

      dialogCheck1.afterClosed().subscribe(result => {
        if (result) {
          console.log('Done');
          let deleteObj = {
            activityDescription: obj.activityDescription,
            mode: 'delete'
          };
          this.addEditDelArray.push(deleteObj);
          this.submit();
          console.log('this.addEditDelArray', this.addEditDelArray);
        }

      });
    }
    this.clearFilters();

  }

  delete() { // to do when this.addEditDelete has data but still selected more that two rows
    console.log('this.selectedRecords in delete', this.selectedRecords);
    console.log('this.this.selectedRow', this.selectedRow);
    if (this.selectedRecords.length === 0) {
      console.log('this.selectedRecords in len = 0', this.selectedRecords);
      const dialogCheck = this.dialog.open(ConfirmComponent, {
        data: {
          type: ConfigType.Confirm,
          content: `Please select one Row to delete.`
        }
      });

      dialogCheck.afterClosed().subscribe(result => {
        if (result) {
          console.log('Done');
        }
      });
    } else if (this.selectedRecords.length > 1) {  // removed && this.addEditDelArray.length === 0
      const dialogCheck1 = this.dialog.open(ConfirmComponent, {
        data: {
          type: ConfigType.Confirm,
          content: `Please select only one Row to delete.`
        }
      });

      dialogCheck1.afterClosed().subscribe(result => {
        if (result) {
          console.log('Done');
          console.log('this.selectedRow in simple', this.selectedRow);
        }
      });
    } else if (this.selectedRow && this.addEditDelArray.length === 0) {
      console.log('1');
      console.log('(this.selectedRow', this.selectedRow);
      if (this.option === 'Adjustment Reason') {
        console.log('2');
        const dialogCheck1 = this.dialog.open(ConfirmComponent, {
          data: {
            type: ConfigType.Confirm,
            content: `Are you sure you want to delete this record ? Click OK to continue.`
          }
        });

        dialogCheck1.afterClosed().subscribe(result => {
          if (result) {
            console.log('result', result);
            let obj = {
              adjustmentReasonDescription: this.selectedRow.adjustmentReasonDescription,
              adjustmentReasonId: this.selectedRow.adjustmentReasonId,
              mode: 'delete'
            };
            this.addEditDelArray.push(obj);

            console.log('this.addEditDelArray', this.addEditDelArray);
            this.selectedRecords = [];
          }

        });

      }
      if (this.option === 'Status') {
        console.log('2');
        const dialogCheck1 = this.dialog.open(ConfirmComponent, {
          data: {
            type: ConfigType.Confirm,
            content: `Are you sure you want to delete this record ? Click OK to continue.`
          }
        });

        dialogCheck1.afterClosed().subscribe(result => {
          if (result) {
            console.log('Done');
            let obj = {
              status: this.selectedRow.status,
              mode: 'delete'
            };
            this.addEditDelArray.push(obj);

            console.log('this.addEditDelArray', this.addEditDelArray);
            this.selectedRecords = [];
          }

        });

      }
      if (this.option === 'Activity Type') {
        console.log('2');
        const dialogCheck1 = this.dialog.open(ConfirmComponent, {
          data: {
            type: ConfigType.Confirm,
            content: `Are you sure you want to delete this record ? Click OK to continue.`
          }
        });

        dialogCheck1.afterClosed().subscribe(result => {
          if (result) {
            console.log('Done');
            let obj = {
              activityDescription: this.selectedRow.activityDescription,
              mode: 'delete'
            };
            this.addEditDelArray.push(obj);

            console.log('this.addEditDelArray', this.addEditDelArray);
            this.selectedRecords = [];
          }

        });

      }


    } else if (this.selectedRow && this.addEditDelArray.length >= 1) {
      if (this.option === 'Adjustment Reason') {
        console.log('in complex');
        let flag;
        flag = this.addEditDelArray.filter(obj => obj.adjustmentReasonDescription === this.selectedRow.adjustmentReasonDescription || obj.adjustmentReasonId === this.selectedRow.adjustmentReasonId);
        console.log('flag', flag);
        if (flag.length > 0) {
          const dialogCheck = this.dialog.open(ConfirmComponent, {
            data: {
              type: ConfigType.Confirm,
              content: `Please select another Row to delete.`
            }
          });

          dialogCheck.afterClosed().subscribe(result => {
            if (result) {
              console.log('Done');
            }
          });
        } else if (flag.length === 0) {
          const dialogCheck1 = this.dialog.open(ConfirmComponent, {
            data: {
              type: ConfigType.Confirm,
              content: `Are you sure you want to delete this record ? Click OK to continue.`
            }
          });

          dialogCheck1.afterClosed().subscribe(result => {
            if (result) {
              console.log('Done');
              let obj = {
                adjustmentReasonDescription: this.selectedRow.adjustmentReasonDescription,
                adjustmentReasonId: this.selectedRow.adjustmentReasonId,
                mode: 'delete'
              };
              this.addEditDelArray.push(obj);

              console.log('this.addEditDelArray', this.addEditDelArray);
              this.selectedRecords = [];
            }

          });

        }

      }
      if (this.option === 'Status') {
        console.log('in complex');
        let flag;
        flag = this.addEditDelArray.filter(obj => obj.status === this.selectedRow.status || obj.statusCode === this.selectedRow.statusCode);
        console.log('flag', flag);
        if (flag.length > 0) {
          const dialogCheck = this.dialog.open(ConfirmComponent, {
            data: {
              type: ConfigType.Confirm,
              content: `Please select another Row to delete.`
            }
          });

          dialogCheck.afterClosed().subscribe(result => {
            if (result) {
              console.log('Done');
            }
          });
        } else if (flag.length === 0) {
          const dialogCheck1 = this.dialog.open(ConfirmComponent, {
            data: {
              type: ConfigType.Confirm,
              content: `Are you sure you want to delete this record ? Click OK to continue.`
            }
          });

          dialogCheck1.afterClosed().subscribe(result => {
            if (result) {
              console.log('Done');
              let obj = {
                status: this.selectedRow.status,
                mode: 'delete'
              };
              this.addEditDelArray.push(obj);

              console.log('this.addEditDelArray', this.addEditDelArray);
              this.selectedRecords = [];
            }

          });

        }
      }
      if (this.option === 'Activity Type') {
        console.log('in complex');
        let flag;
        flag = this.addEditDelArray.filter(obj => obj.activityDescription === this.selectedRow.activityDescription || obj.activityId === this.selectedRow.activityId);
        console.log('flag', flag);
        if (flag.length > 0) {
          const dialogCheck = this.dialog.open(ConfirmComponent, {
            data: {
              type: ConfigType.Confirm,
              content: `Please select another Row to delete.`
            }
          });

          dialogCheck.afterClosed().subscribe(result => {
            if (result) {
              console.log('Done');
            }
          });
        } else if (flag.length === 0) {
          const dialogCheck1 = this.dialog.open(ConfirmComponent, {
            data: {
              type: ConfigType.Confirm,
              content: `Are you sure you want to delete this record ? Click OK to continue.`
            }
          });

          dialogCheck1.afterClosed().subscribe(result => {
            if (result) {
              console.log('Done');
              let obj = {
                activityDescription: this.selectedRow.activityDescription,
                mode: 'delete'
              };
              this.addEditDelArray.push(obj);

              console.log('this.addEditDelArray', this.addEditDelArray);
              this.selectedRecords = [];
            }

          });

        }
      }



    }


  }

  isTablet(): boolean {
    if (window.screen.width <= 1024) {
      return true;
    }

    return false;
  }

  checkBoxSelected(ele: any, condition: any) {
    console.log('checking', ele);
    console.log('condition', condition);
    this.selectedRow = null;
    // this.selectedArray = [];
    this.condition = condition;
    if (this.option === 'Adjustment Reason') {
      if (this.selectedRecords.indexOf(ele) === -1 && condition.checked) {
        this.selectedRecords.push(ele.adjustmentReasonDescription);
        this.selectedArray.push(ele);
        console.log('this.selectedArray', this.selectedArray);
        let counter = this.selectedArray.length;
        console.log('this.selectedRow in checked', this.selectedRow);
        if (counter === 1) {
          this.selectedRow = ele;
          console.log('this.selectedRow in counrer', this.selectedRow);
        } else {
          this.selectedRow = ele;
        }

        // this.selectedArray = [];
        this.condition = null;
      } else if (!condition.checked) {
        if (this.selectedRecords.indexOf(ele.adjustmentReasonDescription) !== -1) {
          // this.selectedRow = null;  // to check
          console.log('selection', ele);
          console.log('this.selectedRecords on selection', this.selectedRecords);
          let index = this.selectedRecords.indexOf(ele.adjustmentReasonDescription);
          console.log('index', index);
          this.selectedRecords.splice(index, 1);
          console.log('this.selectedRecords on selection after', this.selectedRecords);
          console.log('this.selectedArray', this.selectedArray);
          this.selectedArray.forEach(element1 => {
            if (this.selectedRecords.indexOf(element1.adjustmentReasonDescription) !== -1) {
              let index1 = this.selectedArray.indexOf(element1.adjustmentReasonDescription);
              this.selectedRow = element1;
              console.log('this.selectedRow----', this.selectedRow);
            }
          });
          // this.selectedArray = [];
        }

      }
    }
    if (this.option === 'Status') {
      if (this.selectedRecords.indexOf(ele) === -1 && condition.checked) {
        this.selectedRecords.push(ele.status);
        this.selectedArray.push(ele);
        console.log('this.selectedArray', this.selectedArray);
        let counter = this.selectedArray.length;
        console.log('this.selectedRow in checked', this.selectedRow);
        if (counter === 1) {
          this.selectedRow = ele;
          console.log('this.selectedRow in counrer', this.selectedRow);
        } else {
          this.selectedRow = ele;
        }
        // this.selectedArray = [];
        this.condition = null;
      } else if (!condition.checked) {
        if (this.selectedRecords.indexOf(ele.status) !== -1) {
          // this.selectedRow = null;  // to check
          console.log('selection', ele);
          console.log('this.selectedRecords on selection', this.selectedRecords);
          let index = this.selectedRecords.indexOf(ele.status);
          this.selectedRecords.splice(index, 1);
          console.log('this.selectedRecords on selection after', this.selectedRecords);
          console.log('this.selectedArray', this.selectedArray);
          this.selectedArray.forEach(element1 => {
            if (this.selectedRecords.indexOf(element1.status) !== -1) {
              let index1 = this.selectedArray.indexOf(element1.status);
              this.selectedRow = element1;
              console.log('this.selectedRow----', this.selectedRow);
            }
          });
          // this.selectedArray = [];
        }

      }
    }
    if (this.option === 'Activity Type') {
      if (this.selectedRecords.indexOf(ele) === -1 && condition.checked) {
        this.selectedRecords.push(ele.activityDescription);
        this.selectedArray.push(ele);
        console.log('this.selectedArray', this.selectedArray);
        let counter = this.selectedArray.length;
        console.log('this.selectedRow in checked', this.selectedRow);
        if (counter === 1) {
          this.selectedRow = ele;
          console.log('this.selectedRow in counrer', this.selectedRow);
        } else {
          this.selectedRow = ele;
        }
        // this.selectedArray = [];
        this.condition = null;
      } else if (!condition.checked) {
        if (this.selectedRecords.indexOf(ele.activityDescription) !== -1) {
          // this.selectedRow = null;  // to check
          console.log('selection', ele);
          console.log('this.selectedRecords on selection', this.selectedRecords);
          let index = this.selectedRecords.indexOf(ele.activityDescription);
          this.selectedRecords.splice(index, 1);
          console.log('this.selectedRecords on selection after', this.selectedRecords);
          console.log('this.selectedArray', this.selectedArray);
          this.selectedArray.forEach(element1 => {
            if (this.selectedRecords.indexOf(element1.activityDescription) !== -1) {
              let index1 = this.selectedArray.indexOf(element1.activityDescription);
              this.selectedRow = element1;
              console.log('this.selectedRow----', this.selectedRow);
            }
          });
          // this.selectedArray = [];
        }

      }
    }

    this.isSubmit = this.selectedRecords.length > 0 ? false : true;  // to do

  }

  submit() {
    if (this.option === 'Adjustment Reason') {
      this.finalObject = {
        adjustmentReason: this.addEditDelArray
      };
      this.referenceDataService.sendData(this.finalObject, this.option).subscribe((resp: any) => {
        console.log('resp', resp);
        this.result = resp;
        if (resp) {
          this.reportDetailsColumns = this.reportDetailsColumnsA;
          this.columnsData = this.columnsDataA;
          this.reportData = resp.adjustmentReason;
          console.log('this.reportData', this.reportData);
          this.dataSource = new MatTableDataSource(this.reportData);
          this.isSubmitted = false;
          this.mode = 'view';
          console.log('this.reportData in fetchdetails', this.reportData);
        }
        if (resp.adjustmentReasonFailedList) {
          resp.adjustmentReasonFailedList.forEach(element1 => {
            this.notifService.showWarningNotification(element1.failureReason);
          });
          // this.selectedArray = [];
          // this.selectedRecords = [];
          this.addEditDelArray = [];
          this.finalObject = null;
        }
      }, error => {
        this.notifService.showErrorNotification(error);
      });
      this.notifService.showSuccessNotification('All changes are successfully submitted.');

    } else if (this.option === 'Status') {
      this.finalObject = {
        status: this.addEditDelArray
      };
      this.referenceDataService.sendData(this.finalObject, this.option).subscribe((resp: any) => {
        console.log('resp', resp);
        this.result = resp;
        if (resp) {
          this.reportDetailsColumns = this.reportDetailsColumnsB;
          this.columnsData = this.columnsDataB;
          this.reportData = resp.status;
          console.log('this.reportData', this.reportData);
          this.dataSource = new MatTableDataSource(this.reportData);
          this.isSubmitted = false;
          this.mode = 'view';
          console.log('this.reportData in fetchdetails', this.reportData);
        }

        if (resp.statusFailedList) {
          resp.statusFailedList.forEach(element1 => {
            this.notifService.showWarningNotification(element1.failureReason);
          });
          // this.selectedArray = [];
          // this.selectedRecords = [];
          this.addEditDelArray = [];
          this.finalObject = null;
        }
      }, error => {
        this.notifService.showErrorNotification(error);
      });
      this.notifService.showSuccessNotification('All changes are successfully submitted.');

    } else if (this.option === 'Activity Type') {
      this.finalObject = {
        activityType: this.addEditDelArray
      };
      this.referenceDataService.sendData(this.finalObject, this.option).subscribe((resp: any) => {
        console.log('resp', resp);
        this.result = resp;
        if (resp) {
          this.reportDetailsColumns = this.reportDetailsColumnsC;
          this.columnsData = this.columnsDataC;
          this.reportData = resp.activityType;
          console.log('this.reportData', this.reportData);
          this.dataSource = new MatTableDataSource(this.reportData);
          this.isSubmitted = false;
          this.mode = 'view';
          console.log('this.reportData in fetchdetails', this.reportData);
        }
        if (resp.activityTypeFailedList) {
          resp.activityTypeFailedList.forEach(element1 => {
            this.notifService.showWarningNotification(element1.failureReason);
          });
          // this.selectedArray = [];
          // this.selectedRecords = [];
          this.addEditDelArray = [];
          this.finalObject = null;
        }
      }, error => {
        this.notifService.showErrorNotification(error);
      });
      this.notifService.showSuccessNotification('All changes are successfully submitted.');
      if (this.option === 'Activity Type') {

        this.referenceDataService.getDropdownDetails().subscribe((resp: any) => {
          this.dropDownDetails = resp;
          console.log('this.dropDownDetails', this.dropDownDetails);
        });

      }

    }
    console.log('this.finalObject', this.finalObject);

  }

  cancel() {
    this.selectedArray = [];
    this.selectedRecords = [];
    this.addEditDelArray = [];
    this.finalObject = null;
    this.fetchDetails();
  }
  cancelRow(ele: any) {
    ele.isEdit = false;
    this.addEditDelArray = [];
    this.finalObject = null;
  }

  doFilter(value: string) {
    this.dataSource.filter = value.trim().toLocaleLowerCase();
  }
  clearFilters() {
    this.dataSource.filter = '';
    this.filter = '';
  }


}
