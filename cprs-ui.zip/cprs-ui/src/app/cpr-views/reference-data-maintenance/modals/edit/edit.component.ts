import { Component, OnInit, Inject, Optional } from '@angular/core';
import { Router } from '@angular/router';
import { FormControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { UserDetails, UserService } from 'src/app/shared/service/user.service';

@Component({
  selector: 'edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.scss']
})
export class EditComponent implements OnInit {
  recievedObject: any;
  dropdownData: any;
  addAppForm: FormGroup;
  load: boolean = false;
  user: any;
  DateNow: any;
  highLevelActivityTypes = ['Commitment', 'Credit', 'Debit'];
  activitySubTypeId: any;
  highLevelActivityTypeId: any;
  activityUnitCode: any;

  constructor(private fb: FormBuilder, private userService: UserService, public dialogRef: MatDialogRef<EditComponent>,
    @Optional() @Inject(MAT_DIALOG_DATA) public data: any) {
    this.recievedObject = this.data;
    this.dropdownData = this.recievedObject?.dropDownDetails;
    console.log('this.dropdownData-----', this.dropdownData);
    this.user = this.userService.getUserDetails();
    console.log('this.user', this.user);
  }

  ngOnInit(): void {
    this.setupSearchForm();
    this.editSearchForm();
    this.DateNow = new Date(Date.now()).toLocaleString().split(',')[0];
  }

  setupSearchForm(): void {
    if (this.recievedObject.option === 'Adjustment Reason') {
      this.addAppForm = this.fb.group({
        // adjustmentReasonId: new FormControl('', [Validators.required, Validators.maxLength(6), Validators.minLength(6), Validators.pattern('^[0-9]*$')]),
        adjustmentReasonDescription: new FormControl('', [Validators.required, Validators.maxLength(30)])
      });
    } else if (this.recievedObject.option === 'Status') {
      this.addAppForm = this.fb.group({
        status: new FormControl('', [Validators.required, Validators.maxLength(40)])
      });
    } else {
      this.addAppForm = this.fb.group({
        activityType: new FormControl('', [Validators.required, Validators.maxLength(50)]),
        activityDescription: new FormControl('', [Validators.required, Validators.maxLength(50)]),
        highLevelActivityType: new FormControl(this.highLevelActivityTypes[0], [Validators.required]),
        activitySubType: new FormControl(this.dropdownData.activitySubType[0].ACTN_SUB_TYPE_DESC_TX, [Validators.required]),
        activityUnit: new FormControl(this.dropdownData.activityUnit[0].CMNT_UNIT_TX, [Validators.required])
      });
    }

    this.load = true;
  }
  editSearchForm(): void {
    if (this.recievedObject.option === 'Adjustment Reason') {

      this.addAppForm.patchValue({
        adjustmentReasonDescription: this.recievedObject.values.adjustmentReasonDescription,
      });
    } else if (this.recievedObject.option === 'Status') {
      this.addAppForm.setValue({
        status: this.recievedObject.values.status,
      });
    } else {
      this.addAppForm.setValue({
        activityType: this.recievedObject.values.activityType,
        activityDescription: this.recievedObject.values.activityDescription,
        highLevelActivityType: this.recievedObject.values.highLevelActivityType,
        activitySubType: this.recievedObject.values.activitySubType,
        activityUnit: this.recievedObject.values.activityUnit
      });
    }
  }

  editAppData() {
    if (this.recievedObject.option === 'Adjustment Reason') {
      let adjustmentReasonDescription = this.addAppForm.get('adjustmentReasonDescription').value;

      let object = {
        adjustmentReasonDescription: adjustmentReasonDescription,
        adjustmentReasonId: this.recievedObject.values.adjustmentReasonId,
        lastUpdateDate: this.DateNow,
        lastUpdateUserId: this.user.attuid,
        mode: 'update'
      };
      console.log('object', object);
      this.dialogRef.close(object);

    } else if (this.recievedObject.option === 'Status') {
      let status = this.addAppForm.get('status').value;

      let object = {
        lastUpdateDate: this.DateNow,
        lastUpdateUserId: this.user.attuid,
        mode: 'update',
        status: status,
        statusCode: this.recievedObject.values.statusCode
      };
      console.log('object', object);
      this.dialogRef.close(object);

    } else {
      let activityType = this.addAppForm.get('activityType').value;
      let activityDescription = this.addAppForm.get('activityDescription').value;
      let highLevelActivityType = this.addAppForm.get('highLevelActivityType').value;
      let activitySubType = this.addAppForm.get('activitySubType').value;
      let activityUnit = this.addAppForm.get('activityUnit').value;

      if (activitySubType === 'ACCESS COMPONENTS') {
        this.activitySubTypeId = 'AC';
      }
      if (activitySubType === 'CALC CREDIT') {
        this.activitySubTypeId = 'VD';
      }
      if (activitySubType === 'FEATURES') {
        this.activitySubTypeId = 'FEA';
      }
      if (activitySubType === 'LUMP SUM CREDIT') {
        this.activitySubTypeId = 'PI';
      }
      if (activitySubType === 'MAC') {
        this.activitySubTypeId = 'VMC';
      }
      if (activitySubType === 'MAC/MARC') {
        this.activitySubTypeId = 'MAC';
      }
      if (activitySubType === 'MARC') {
        this.activitySubTypeId = 'MRC';
      }
      if (activitySubType === 'MMRC') {
        this.activitySubTypeId = 'MMR';
      }
      if (activitySubType === 'MTRC') {
        this.activitySubTypeId = 'MTC';
      }
      if (activitySubType === 'MVC') {
        this.activitySubTypeId = 'MVC';
      }
      if (activitySubType === 'NET MARC') {
        this.activitySubTypeId = 'NMC';
      }
      if (activitySubType === 'NETWORK COMPONENTS') {
        this.activitySubTypeId = 'NC';
      }
      if (activitySubType === 'NUMBER OF') {
        this.activitySubTypeId = 'NUM';
      }
      if (activitySubType === 'Net SubMARC') {
        this.activitySubTypeId = 'NSM';
      }
      if (activitySubType === 'OTHER') {
        this.activitySubTypeId = 'OTH';
      }
      if (activitySubType === 'PERCENTAGES') {
        this.activitySubTypeId = 'PER';
      }
      if (activitySubType === 'TOTAL COMPONENTS') {
        this.activitySubTypeId = 'TC';
      }

      if (highLevelActivityType === 'Commitment') {
        this.highLevelActivityTypeId = 'CM';
      }
      if (highLevelActivityType === 'Credit') {
        this.highLevelActivityTypeId = 'CR';
      }
      if (highLevelActivityType === 'Debit') {
        this.highLevelActivityTypeId = 'DR';
      }
      if (activityUnit === 'BILL GROUPS') {
        this.activityUnitCode = 'G';
      }
      if (activityUnit === 'DOLLARS') {
        this.activityUnitCode = 'D';
      }
      if (activityUnit === 'DURATION') {
        this.activityUnitCode = 'U';
      }
      if (activityUnit === 'MINUTES') {
        this.activityUnitCode = 'M';
      }
      if (activityUnit === 'NUMBER OF CALLS') {
        this.activityUnitCode = 'N';
      }
      if (activityUnit === 'PERCENTAGE') {
        this.activityUnitCode = 'P';
      }
      if (activityUnit === 'SERVICE ELEMENTS') {
        this.activityUnitCode = 'R';
      }

      let object = {
        activityDescription: activityDescription,
        activityType: activityType,
        highLevelActivityTypeId: this.highLevelActivityTypeId,
        highLevelActivityType: highLevelActivityType,
        activitySubTypeId: this.activitySubTypeId,
        activitySubType: activitySubType,
        activityUnitCode: this.activityUnitCode,
        activityUnit: activityUnit,
        lastUpdateDate: this.DateNow,
        lastUpdateUserId: this.user.attuid,
        mode: 'update',
        activityId: this.recievedObject.values.activityId
      };

      console.log('object', object);
      this.dialogRef.close(object);
    }


  }

}
