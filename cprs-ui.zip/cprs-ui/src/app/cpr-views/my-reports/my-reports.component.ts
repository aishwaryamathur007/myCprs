import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
//import { DrilldownModalComponent } from 'src/app/common/component/report-table/sub-reports/drilldown-modal/drilldown-modal.component';
//import { DrilldownModalComponent } from '@report-table-library/common-report-table';
import { UserService } from 'src/app/shared/service/user.service';

@Component({
  selector: 'ub-my-reports',
  templateUrl: './my-reports.component.html',
  styleUrls: ['./my-reports.component.scss']
})
export class MyReportsComponent implements OnInit {

  userDetails: any;
  appId = ['27'];
  constructor(private userService: UserService,
    private dialog: MatDialog,
    private router: Router) {
    this.userDetails = this.userService.getUserDetails();
  }

  ngOnInit(): void {
  }

  openSubReportEvent(event) {
    let subReportsDetails = event.subReportDetails;
    let rowData = event.rowData;

    // const dialogRef = this.dialog.open(DrilldownModalComponent, {
    //   data: {
    //     subReportsDetails: subReportsDetails
    //   },
    //   minWidth: '50%'
    // });

    // dialogRef.afterClosed().subscribe(result => {

    //   if (result != null) {
    //     let selectedSubReport = subReportsDetails[result];
    //     this.navigateToSubReport(selectedSubReport, rowData);
    //   }
    // });
  }

  navigateToSubReport(selectedSubReport, rowData) {
    let code: string = selectedSubReport.SUB_RPT_NM_TX;

    let reportUrl;
    switch (code) {
      case 'BIM Transaction Revenue Report User Summary': {
        reportUrl = this.router.serializeUrl(
          this.router.createUrlTree(['cprs', 'reports', 'bim-transaction', 'bim-user-summary'], {
            queryParams: {
              userId: rowData.Org_User_ID?.trim() ?? 'null',
              date: rowData.MO_PRD_DT.trim(),
            }
          })
        );
        break;
      }
      case 'BIM Transaction Revenue Report User Detail': {
        reportUrl = this.router.serializeUrl(
          this.router.createUrlTree(['cprs', 'reports', 'bim-transaction', 'bim-user-detail'], {
            queryParams: {
              userId: rowData.USR_ID,
              orgUserId: rowData.Org_User_ID?.trim() ?? 'null',
              date: rowData.MO_PRD_DT.trim(),
            }
          })
        );
        break;
      }
      case 'Bundle Report to Customer Detail Report': {
        reportUrl = this.router.serializeUrl(
          this.router.createUrlTree(['cprs', 'reports', 'sbs-bundle', 'sbs-bundle-customer-detail'], { queryParams: { bundleNmCod: rowData.BUNDL_NM_CD.trim() } })
        );
        break;
      }
      case 'Customer Detail Report to Service Detail Report': {
        reportUrl = this.router.serializeUrl(
          this.router.createUrlTree(['cprs', 'reports', 'sbs-bundle', 'sbs-bundle-customer-detail-service-detail'], {
            queryParams: {
              parentAcc: rowData.PARNT_ACCT_ID.trim()
            }
          })
        );
        break;
      }
      case 'HCV Service Report': {
        reportUrl = this.router.serializeUrl(
          this.router.createUrlTree(['cprs', 'reports', 'hcv-product', 'hcv-service'], { queryParams: { prodNm: rowData.PROD_NM.trim(), date: rowData.MO_PRD_JRNL_DT.trim() } })
        );
        break;
      }
      case 'HCV Customer Report': {
        reportUrl = this.router.serializeUrl(
          this.router.createUrlTree(['cprs', 'reports', 'hcv-product', 'hcv-customer'], { queryParams: { prodNm: rowData.PROD_NM.trim(), date: rowData.MO_PRD_JRNL_DT.trim() } })
        );
        break;
      }
      case 'HCV Location Report': {
        reportUrl = this.router.serializeUrl(
          this.router.createUrlTree(['cprs', 'reports', 'hcv-product', 'hcv-location'], { queryParams: { prodNm: rowData.PROD_NM.trim(), date: rowData.MO_PRD_JRNL_DT.trim() } })
        );
        break;
      }
    }
    window.open(reportUrl, '_blank');
  }

}
