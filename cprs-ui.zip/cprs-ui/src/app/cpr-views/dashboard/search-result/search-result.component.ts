import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { DomSanitizer } from '@angular/platform-browser';
import * as  FileSaver from 'file-saver';
import { ModalDropdownComponent } from 'src/app/common/component/modal-dropdown/modal-dropdown.component';
import { DashboardService } from '../../service/dashboard.service';
import { ApexAxisChartSeries, ApexChart, ChartComponent, ApexDataLabels, ApexPlotOptions, ApexYAxis, ApexLegend, ApexStroke, ApexXAxis, ApexFill, ApexTooltip } from "ng-apexcharts";
import { ComponentGroupAdminComponent } from '../component-group-admin/component-group-admin.component';
import { NotificationService } from 'src/app/common/services/notification.service';
import * as ApexCharts from 'apexcharts';
export type ChartOptions = {
  series: ApexAxisChartSeries; chart: ApexChart; dataLabels: ApexDataLabels; plotOptions: ApexPlotOptions; yaxis: ApexYAxis; xaxis: ApexXAxis; fill: ApexFill; tooltip: ApexTooltip; stroke: ApexStroke; legend: ApexLegend; colors: string[];
};
@Component({
  selector: 'search-result',
  templateUrl: './search-result.component.html',
  styleUrls: ['./search-result.component.scss']
})
export class SearchResultComponent implements OnInit {
  @ViewChild('chart') chart: ChartComponent;
  chartOptions: Partial<ChartOptions>;

  tab1: any = [
    { key: "action", label: "" },
    { key: "offrId", label: "Offer Id" },
    { key: "actnDescTx", label: "Commitment Requirement" },
    { key: "offrActnId", label: "Offer Action Id" },
    { key: "attainmentAmount", label: "Attainment Amount" },
    { key: "commitmentAmount", label: "Commitment Amount" },
    { key: "diff", label: "Difference" },
    { key: "trackingPeriod", label: "Tracking Period" },
    { key: "monthsThrough", label: "Months Through" },
    { key: "percentDiff", label: "Percent Attained" }
  ];
  tab2: any;
  tab3: any;
  dataSource: MatTableDataSource<any>;
  isDataFetched: boolean = false;
  fetchingReport: boolean = false;
  priorMonth: boolean = false;
  dc1: string[];
  dc2: string[];
  dc3: string[];
  urlData: any;
  graphData: any = [];

  constructor(private route: ActivatedRoute, private dbservice: DashboardService, private dialog: MatDialog,
    private router: Router, private _notifService: NotificationService) {
    this.route.queryParams.subscribe(val => {
      this.urlData = Object.assign({}, val);
    });
  }

  ngOnInit(): void {
    this.tab2 = [{ key: "action", label: "" },
    { key: "gpNm", label: this.urlData.rdGroupType == 0 ? "Component Group" : "Group" },
    { key: "attainmentAmount", label: "Attainment Amount" }];
    this.tab3 = [
      { key: "elem", label: this.urlData.rdGroupType == 0 ? "Component" : "Account" },
      { key: "attainmentAmount", label: "Attainment Amount" }
    ];
    this.tab1.push({ key: "group", label: "", link: this.urlData.rdGroupType == 0 ? "Component Group Administration" : "Account Group Administration" });
    this.dc2 = this.tab2.map(col => col.key);
    this.dc3 = this.tab3.map(col => col.key);
    this.dc1 = this.tab1.map(col => col.key);
    this.getDefaultData();
  }
  getPriorMonthData() {
    this.priorMonth = true;
    let obj = {
      "cntrctCustId": this.urlData.CNTRCT_CUST_ID,
      "cntrctSrceId": this.urlData.CNTRCT_SRCE_ID,
      "commType": this.urlData.rdCommType,
      "groupType": this.urlData.rdGroupType == 0 ? 'C' : 'A',
      "isParentView": this.urlData.rdTrackType == 0 ? true : false,
      "isPriorMonth": true
    };
    this.getCustomerDetails(obj);
  }
  getDefaultData() {
    this.priorMonth = false;
    let obj = {
      "cntrctCustId": this.urlData.CNTRCT_CUST_ID,
      "cntrctSrceId": this.urlData.CNTRCT_SRCE_ID,
      "commType": this.urlData.rdCommType,
      "groupType": this.urlData.rdGroupType == 0 ? 'C' : 'A',
      "isParentView": this.urlData.rdTrackType == 0 ? true : false,
      "isPriorMonth": false
    }
    this.getCustomerDetails(obj);
  }
  getCustomerDetails(obj: any) {
    this.isDataFetched = false;
    this.fetchingReport = true;
    this.dbservice.getCustomerDetails(obj).subscribe(resp => {
      if (!!resp) {
        this.fetchingReport = false;
        this.dataSource = new MatTableDataSource(resp);
        this.isDataFetched = true;
        this.getChart();
      }
    }, error => {
      this._notifService.showErrorNotification(error);
    });
  };
  rowExpand(ele: any, table: number) {
    if (table == 1) {
      ele.expand = !ele.expand;
    } else {
      ele.expand1 = !ele.expand1;
    }
  };
  getChartLabel(year: any, month: any, duration: any) {
    const months = Array.from({ length: parseInt(duration) }, (item, i) => {
      if (i >= (parseInt(month) - 1)) {
        return new Date(parseInt(year), i).toLocaleString('en-US', { month: 'long', year: 'numeric' });
      }
    });
    const results = months.filter(element => { return element !== undefined; });
    return results;
  }
  getChart() {
    this.graphData = [];
    this.dataSource.data.forEach((chart, index) => {
      let data: any = [];
      let labels: any = [];
      if (this.urlData.rdGraphType == 0) {
        let dataArray = [];
        let label = [];
        Object.keys(chart.attainmentGraph).forEach(el => {
          if (el.includes('month') && !el.includes('anniversaryMonth')) { // && data.length < parseInt(chart['customerDetails']['numberMonths'])) { //parseInt(chart['customerDetails']['numberMonths']))
            dataArray.push(chart['attainmentGraph'][el]);
          }
        });
        label = this.getChartLabel(chart['attainmentGraph']['anniversaryYear'], chart['attainmentGraph']['anniversaryMonth'], parseInt(chart['customerDetails']['numberMonths']) + parseInt(chart['attainmentGraph']['anniversaryMonth']) - 1);
        for (var i = 1; i <= parseInt(chart['customerDetails']['numberMonths']); i++) {
          if (parseInt(chart['customerDetails']['numberMonths']) > 12) {
            if (parseInt(chart['customerDetails']['monthsThrough']) <= 12 && i <= 12) {
              data.push(dataArray[i - 1]);
              labels.push(label[i - 1]);
            } else if (parseInt(chart['customerDetails']['monthsThrough']) > 12 && parseInt(chart['customerDetails']['monthsThrough']) <= 24 && i > 12 && i <= 24) {
              data.push(dataArray[i - 1]);
              labels.push(label[i - 1]);
            } else if (parseInt(chart['customerDetails']['monthsThrough']) > 24 && parseInt(chart['customerDetails']['monthsThrough']) <= 36 && i > 24 && i <= 36) {
              data.push(dataArray[i - 1]);
              labels.push(label[i - 1]);
            }
          } else {
            labels = this.getChartLabel(chart['attainmentGraph']['anniversaryYear'], chart['attainmentGraph']['anniversaryMonth'], parseInt(chart['customerDetails']['numberMonths']) + parseInt(chart['attainmentGraph']['anniversaryMonth']) - 1);
            data.push(dataArray[i - 1]);
          }
        }
      } else {
        let total = 0;
        let dataArray = [];
        let label = [];
        Object.keys(chart.attainmentGraph).forEach(el => {
          if (el.includes('month') && !el.includes('anniversaryMonth')) { // && data.length < parseInt(chart['customerDetails']['numberMonths'])) { //parseInt(chart['customerDetails']['numberMonths']))
            total += chart['attainmentGraph'][el];
            dataArray.push(total.toFixed(2));
          }
        });
        label = this.getChartLabel(chart['attainmentGraph']['anniversaryYear'], chart['attainmentGraph']['anniversaryMonth'], parseInt(chart['customerDetails']['numberMonths']) + parseInt(chart['attainmentGraph']['anniversaryMonth']) - 1);
        for (var i = 1; i <= parseInt(chart['customerDetails']['numberMonths']); i++) {
          if (parseInt(chart['customerDetails']['numberMonths']) > 12) {
            if (parseInt(chart['customerDetails']['monthsThrough']) <= 12 && i <= 12) {
              data.push(dataArray[i - 1]);
              labels.push(label[i - 1]);
            } else if (parseInt(chart['customerDetails']['monthsThrough']) > 12 && parseInt(chart['customerDetails']['monthsThrough']) <= 24 && i > 12 && i <= 24) {
              data.push(dataArray[i - 1]);
              labels.push(label[i - 1]);
            } else if (parseInt(chart['customerDetails']['monthsThrough']) > 24 && parseInt(chart['customerDetails']['monthsThrough']) <= 36 && i > 24 && i <= 36) {
              data.push(dataArray[i - 1]);
              labels.push(label[i - 1]);
            }
          } else {
            labels = this.getChartLabel(chart['attainmentGraph']['anniversaryYear'], chart['attainmentGraph']['anniversaryMonth'], parseInt(chart['customerDetails']['numberMonths']) + parseInt(chart['attainmentGraph']['anniversaryMonth']) - 1);
            data.push(dataArray[i - 1]);
          }
        }
        let ele = data;
        let dat = ele.splice(ele.length - (parseInt(chart['customerDetails']['numberMonths']) - parseInt(chart['customerDetails']['monthsThrough'])));
        const newArr = dat.map(element => { return 0; });
        data = ele.concat(newArr);
      }
      this.chartOptions = {
        series: [{ name: "", data: data }],
        chart: {
          type: "bar",
          height: 350,
          width: '100%',
          redrawOnWindowResize: true,
          toolbar: {
            show: true,
            offsetX: 0,
            offsetY: 0,
            tools: {
              download: '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#4a90e2" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="bevel"><path d="M12 5v13M5 12l7 7 7-7"/></svg>',
              selection: false,
              zoom: false,
              zoomin: false,
              zoomout: false,
              pan: false,
              reset: false,
              customIcons: []
            }
          },
        },
        plotOptions: {
          bar: {
            barHeight: "75%",
            horizontal: false, columnWidth: "55%", borderRadius: 10,
            colors: {
              ranges: [{ from: -100000, to: 0, color: '#FF0000' }, { from: 1, to: 100000, color: '#009fdb' }]
            }
          }
        },
        dataLabels: { enabled: false },
        stroke: { show: true, colors: ["transparent"], width: 2 },
        xaxis: {
          labels: { rotate: -50 }, categories: labels, tickPlacement: "on"
        },
        fill: { opacity: 1 },
        tooltip: {
          y: {
            formatter: function (val) {
              return "$ " + val.toString().replace(/\B(?<!\.\d*)(?=(\d{3})+(?!\d))/g, ",");
            }
          }
        },
        yaxis: {
          labels: {
            formatter: function (value) {
              return "$ " + value;
            }
          }
        }
      }
      this.graphData.push(this.chartOptions);

    });
  };
  getDropDown(custDetails: any) {
    let data: any = [];
    if (custDetails.exprNd == 'Y') {
      data = [
        { value: 'informational_tracking', label: 'Informational Tracking' },
        { value: 'prior_period_summary_tracking', label: 'Prior Period Summary' }
      ];
    } else {
      data = [
        { value: 'commitment_tracking', label: 'Commitment Tracking' },
        { value: 'informational_tracking', label: 'Informational Tracking' },
        { value: 'prior_period_summary_tracking', label: 'Prior Period Summary' }
      ];
      if (this.urlData.rdTrackType == 1) {
        data.splice(1, 0, { value: 'nothing_report', label: 'Child Tracking' });
      } else {
        data.splice(1, 0, { value: 'child_tracking', label: 'Child Tracking' });
      }
    }
    const dialogRef = this.dialog.open(ModalDropdownComponent, {
      data: {
        title: 'Please select the type of report you would like to drill into :',
        data: data
      }
    });

    dialogRef.afterClosed().subscribe(val => {
      if (val) {
        let dt = custDetails.blCycTx.match(/.{1,4}/g).join('-');
        let invoiceDate = dt.match(/.{1,7}/g).join('-');
        let obj = {
          "custId": this.urlData.CNTRCT_CUST_ID,
          "offrId": custDetails.offrId,
          "slcTrackingType": val.data.value,
          "srceId": this.urlData.CNTRCT_SRCE_ID,
          "custNm": this.urlData.PRFR_CUST_NM,
          "exprNd": custDetails.exprNd,
          "offrEffDt": custDetails.offrEffDt,
          "startContractPeriod": custDetails.custOffrStrtDt,
          "endContractPeriod": custDetails.custOffrEndDt,
          "offrActnId": custDetails.offrActnId,
          "contSrcTx": this.urlData.CNTRCT_SRCE_TX,
          "gpTypeNd": this.urlData.rdGroupType == 0 ? 'C' : 'A',
          "isParentView": this.urlData.rdTrackType == 0 ? true : false,
          "isPriorMonth": this.priorMonth,
          "commType": this.urlData.rdCommType,
          "commitmentAmount": custDetails.commitmentAmount,
          "pgName": val.data.label
        }
        if (val.data.value == 'child_tracking' || val.data.value == 'nothing_report') {
          let ele = {
            "actnDescTx": custDetails.actnDescTx,
            "trackingPeriod": custDetails.trackingPeriod,
            "monthsThrough": custDetails.monthsThrough,
            "attainmentAmount": custDetails.attainmentAmount,
            "percentDiff": custDetails.percentDiff + '%',
            "diff": custDetails.diff,
            "invoiceDate": invoiceDate
          }
          obj = Object.assign(obj, ele);
          this.router.navigate(['/dashboard', 'child-tracking'], { queryParams: obj });
        } else {
          this.router.navigate(['/dashboard', 'commitment-tracking'], { queryParams: obj });
        }
      }
    });
  };
  cprsDownload() {
    let bodytitles = {}, bodyData = [];
    let keys = [
      { key: "offrId", label: "Offer Id" },
      { key: "actnDescTx", label: "Commitment Requirement" },
      { key: "offrActnId", label: "Offer Action Id" },
      { key: "gpNm", label: this.urlData.rdGroupType == 0 ? "Component Group" : "Group" },
      { key: "elem", label: this.urlData.rdGroupType == 0 ? "Component" : "Account" },
      { key: "trackingPeriod", label: "Tracking Period" },
      { key: "monthsThrough", label: "Months Through" },
      { key: "attainmentAmount", label: "Attainment Amount" },
      { key: "commitmentAmount", label: "Commitment Amount" },
      { key: "diff", label: "Difference" },
      { key: "percentDiff", label: "Percent Attained" }
    ];

    keys.forEach((key, index) => {
      bodytitles[key.key] = {
        "sequenceNm": index,
        "titleName": key.label
      }
    });
    this.dataSource.data.forEach(data => {
      let tab1 = {};
      keys.forEach(el => {
        tab1[el.key] = data['customerDetails'][el.key];
      });
      bodyData.push(tab1);
      data['attainmentDetails']['attainmentComponentGroup'].forEach(dat => {
        let tab2 = {};
        keys.forEach(el => {
          tab2[el.key] = dat[el.key];
          tab2['offrId'] = data['customerDetails']['offrId']
        });
        bodyData.push(tab2);
        dat['attainmentComponents'].forEach(comp => {
          let tab3 = {};
          keys.forEach(el => {
            tab3[el.key] = comp[el.key];
          });
          bodyData.push(tab3);
        });
      });
    });
    bodyData.forEach(function (object) {
      for (let key in object) {
        if (object[key] == null)
          object[key] = '';
      }
    });
    let download = {
      "bodySection": {
        "inputValues": bodyData,
        "titles": bodytitles
      },
      "headerSection": {
        "inputValues": [],
        "titles": {}
      },
      "sheetName": 'Attainment'

    }
    this.fetchingReport = true;
    this.dbservice.cprsDownload(download).subscribe(resp => {
      this.fetchingReport = false;
      if (!!resp) {
        FileSaver.saveAs(resp, 'Attainment' + '.xlsx');
      }
    }, error => {
      this.fetchingReport = false;
      this._notifService.showErrorNotification(error);
    })
  };
  componentGroupAdmin(ele: any) {
    ele["cntrctCustId"] = this.urlData.CNTRCT_CUST_ID;
    ele["cntrctSrceId"] = this.urlData.CNTRCT_SRCE_ID;
    ele["groupType"] = this.urlData.rdGroupType == 0 ? 'C' : 'A';
    const dialogRef = this.dialog.open(ComponentGroupAdminComponent, {
      data: {
        title: (this.urlData.rdGroupType == 0 ? 'Component' : 'Account') + ' Group Administration',
        data: ele
      },
      width: '75%'
    });

    dialogRef.afterClosed().subscribe(val => {
      if (!!val) {
        let obj = {
          "cntrctCustId": this.urlData.CNTRCT_CUST_ID,
          "cntrctSrceId": this.urlData.CNTRCT_SRCE_ID,
          "commType": this.urlData.rdCommType,
          "groupType": this.urlData.rdGroupType == 0 ? 'C' : 'A',
          "isParentView": this.urlData.rdTrackType == 0 ? true : false,
          "isPriorMonth": false
        };
        this.getCustomerDetails(obj);
      }
    });
  }
  print() {
    const printContent = document.getElementById('print-section');
    const windowPrt = window.open('', '', 'left=0,top=0,width=900,height=900,toolbar=0.scrollbars=0,status=0');
    windowPrt.document.write(printContent.innerHTML);
    windowPrt.document.write('<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500&display=swap" rel="stylesheet">');
    windowPrt.document.write('<link href="https://fonts.googleapis.com/icon?family=Material+Icons|Material+Icons+Round|Material+Icons+Outlined" rel="stylesheet">');
    windowPrt.document.write('<link rel="stylesheet" type="text/css" href="/assets/styles/custom-theme.scss" />');
    windowPrt.document.write('<link rel="stylesheet" type="text/css" href="/assets/styles/variables.scss" />');
    windowPrt.document.write('<link rel="stylesheet" type="text/css" href="/assets/styles/custom-material-style.scss" />');
    windowPrt.document.write('<link rel="stylesheet" type="text/css" href="/assets/styles/customer-summary-print.scss" />');
  }
}
