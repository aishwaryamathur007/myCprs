import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { MatDialog, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import * as  FileSaver from 'file-saver';
import { ModalDropdownComponent } from 'src/app/common/component/modal-dropdown/modal-dropdown.component';
import { DashboardService } from '../../service/dashboard.service';
import { ApexAxisChartSeries, ApexChart, ChartComponent, ApexDataLabels, ApexPlotOptions, ApexYAxis, ApexLegend, ApexStroke, ApexXAxis, ApexFill, ApexTooltip } from "ng-apexcharts";
export type ChartOptions = {
  series: ApexAxisChartSeries; chart: ApexChart; dataLabels: ApexDataLabels; plotOptions: ApexPlotOptions; yaxis: ApexYAxis; xaxis: ApexXAxis; fill: ApexFill; tooltip: ApexTooltip; stroke: ApexStroke; legend: ApexLegend; colors: string[];
};
@Component({
  selector: 'prior-month',
  templateUrl: './prior-month.component.html',
  styleUrls: ['./prior-month.component.scss']
})
export class PriorMonthComponent implements OnInit {
  @ViewChild('chart') chart: ChartComponent;
  chartOptions: Partial<ChartOptions>;

  tab1 = [
    { key: "action", label: "" },
    { key: "offrId", label: "Offer Id" },
    { key: "actnDescTx", label: "Commitment Requirement" },
    { key: "offrActnId", label: "Offer Action Id" },
    { key: "attainmentAmount", label: "Attainment Amount" },
    { key: "commitmentAmount", label: "Commitment Amount" },
    { key: "diff", label: "Difference" },
    { key: "trackingPeriod", label: "Tracking Period" },
    { key: "monthsThrough", label: "Months Through" },
    { key: "percentDiff", label: "Percent Attained" },
    { key: "group", label: "", link: "Component Group Administration" }
  ];
  tab2 = [
    { key: "action", label: "" },
    { key: "gpNm", label: "Component Group" },
    { key: "attainmentAmount", label: "Attainment Amount" }
  ];
  tab3 = [
    { key: "elem", label: "Component" },
    { key: "attainmentAmount", label: "Attainment Amount" }
  ];
  dataSource: MatTableDataSource<any>;
  isDataFetched: boolean = false;
  fetchingReport: boolean = false;
  dc1: string[] = this.tab1.map(col => col.key);
  dc2: string[] = this.tab2.map(col => col.key);
  dc3: string[] = this.tab3.map(col => col.key);
  urlData: any;
  graphData: any = [];

  constructor(private route: ActivatedRoute, private dbservice: DashboardService, private dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) public modalData: any, private router: Router) {
    this.route.queryParams.subscribe(val => {
      this.urlData = Object.assign({}, val);
    });
  }

  ngOnInit(): void {
    this.getCustomerDetails(this.modalData);
  }
 
  getCustomerDetails(obj: any) {
    this.isDataFetched = false;
    this.fetchingReport = true;
    this.dbservice.getCustomerDetails(obj).subscribe(resp => {
      this.fetchingReport = false;
      this.dataSource = new MatTableDataSource(resp);
      this.isDataFetched = true;
      this.getChart();
    });
  };
  rowExpand(ele: any, table: number) {
    if (table == 1) {
      ele.expand = !ele.expand;
    } else {
      ele.expand1 = !ele.expand1;
    }
  };
  getChartLabel(year: any, month: any, duration: any) {
    const months = Array.from({ length: parseInt(duration) }, (item, i) => {
      if (i >= (parseInt(month) - 1)) {
        return new Date(parseInt(year), i).toLocaleString('en-US', { month: 'long', year: 'numeric' });
      }
    });
    const results = months.filter(element => { return element !== undefined; });
    return results;
  }
  getChart() {
    this.dataSource.data.forEach(async chart => {
      let data: any = [];
      let labels: any = [];
      Object.keys(chart.attainmentGraph).forEach(el => {
        if (el.includes('month') && !el.includes('anniversaryMonth') && data.length < parseInt(chart['customerDetails']['numberMonths'])) { //
          data.push(chart['attainmentGraph'][el]);
          // labels.push(el);
        }
      });
      labels = await this.getChartLabel(chart['attainmentGraph']['anniversaryYear'], chart['attainmentGraph']['anniversaryMonth'], parseInt(chart['customerDetails']['numberMonths']) + parseInt(chart['attainmentGraph']['anniversaryMonth']) - 1);
      this.chartOptions = {
        series: [{ name: "", data: data }],
        chart: { type: "bar", height: 350, width: '100%' },
        plotOptions: {
          bar: {
            horizontal: false, columnWidth: "55%", borderRadius: 10,
            colors: {
              ranges: [{ from: -100000, to: 0, color: '#FF0000' }, { from: 1, to: 100000, color: '#009fdb' }]
            }
          }
        },
        dataLabels: { enabled: false },
        stroke: { show: true, colors: ["transparent"] },
        xaxis: {
          labels: { rotate: -45 }, categories: labels,
        },
        fill: { opacity: 1 },
        tooltip: {
          y: {
            formatter: function (val) {
              return "$ " + val.toString().replace(/\B(?<!\.\d*)(?=(\d{3})+(?!\d))/g, ",");
            }
          }
        },
        yaxis: {
          labels: {
            formatter: function (value) {
              return "$ " + value;
            }
          }
        }
      }
      this.graphData.push(this.chartOptions);

    });
  };
  getDropDown(custDetails: any) {
    const dialogRef = this.dialog.open(ModalDropdownComponent, {
      data: {
        title: 'Please select the type of report you would like to drill into :',
        data: [{ value: 'informational_tracking', label: 'Informational Tracking' }, { value: 'prior_period_summary_tracking', label: 'Prior Period Summary' }]
      }
    });

    dialogRef.afterClosed().subscribe(val => {
      if (val) {
        console.log(val);
        let obj = {
          "custId": this.urlData.CNTRCT_CUST_ID,
          "offrId": custDetails.offrId,
          "slcTrackingType": val.value,
          "srceId": this.urlData.CNTRCT_SRCE_ID,
          "custNm": this.urlData.PRFR_CUST_NM,
          "exprNd": custDetails.exprNd,
          "offrEffDt": custDetails.offrEffDt,
          "startContractPeriod": custDetails.custOffrStrtDt,
          "endContractPeriod": custDetails.custOffrEndDt,
          "offrActnId": custDetails.offrActnId,
          "contSrcTx": this.urlData.CNTRCT_SRCE_TX
        }
        this.router.navigate(['/dashboard', 'commitment-tracking'], { queryParams: obj });
      }
    });
  };
  cprsDownload() {
    let bodytitles = {}, bodyData = [];
    let keys = [
      { key: "offrId", label: "Offer Id" },
      { key: "actnDescTx", label: "Commitment Requirement" },
      { key: "offrActnId", label: "Offer Action Id" },
      { key: "gpNm", label: "Component Group" },
      { key: "elem", label: "Component" },
      { key: "trackingPeriod", label: "Tracking Period" },
      { key: "monthsThrough", label: "Months Through" },
      { key: "attainmentAmount", label: "Attainment Amount" },
      { key: "commitmentAmount", label: "Commitment Amount" },
      { key: "diff", label: "Difference" },
      { key: "percentDiff", label: "Percent Attained" }
    ];

    keys.forEach((key, index) => {
      bodytitles[key.key] = {
        "sequenceNm": index,
        "titleName": key.label
      }
    });
    this.dataSource.data.forEach(data => {
      let tab1 = {}, tab2 = {}, tab3Arr = [];
      keys.forEach(el => {
        tab1[el.key] = data['customerDetails'][el.key];
        tab2[el.key] = data['attainmentDetails']['attainmentComponentGroup'][el.key];
      });
      data['attainmentDetails']['attainmentComponents'].forEach(dat => {
        let tab3 = {};
        keys.forEach(el => {
          tab3[el.key] = dat[el.key];
        });
        tab3Arr.push(tab3);
      });
      bodyData.push(tab1);
      bodyData.push(tab2);
      bodyData = bodyData.concat(tab3Arr);

    });
    bodyData.forEach(function (object) {
      for (let key in object) {
        if (object[key] == null)
          object[key] = '';
      }
    });
    let download = {
      "bodySection": {
        "inputValues": bodyData,
        "titles": bodytitles
      },
      "headerSection": {
        "inputValues": [],
        "titles": {}
      },
      "sheetName": (this.urlData.pgName).replace(/[^a-zA-Z0-9]/g, "")

    }
    this.dbservice.cprsDownload(download).subscribe(resp => {
      if (resp) {
        FileSaver.saveAs(resp, 'Commitment'+(this.urlData.pgName).replace(/[^a-zA-Z0-9]/g, "") + '.xlsx');
      }
    })
  };
  print() {
    const printContent = document.getElementById('print-section');
    const windowPrt = window.open('', '', 'left=0,top=0,width=900,height=900,toolbar=0.scrollbars=0,status=0');
    windowPrt.document.write(printContent.innerHTML);
    windowPrt.document.write('<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500&display=swap" rel="stylesheet">');
    windowPrt.document.write('<link href="https://fonts.googleapis.com/icon?family=Material+Icons|Material+Icons+Round|Material+Icons+Outlined" rel="stylesheet">');
    windowPrt.document.write('<link rel="stylesheet" type="text/css" href="/assets/styles/custom-theme.scss" />');
    windowPrt.document.write('<link rel="stylesheet" type="text/css" href="/assets/styles/variables.scss" />');
    windowPrt.document.write('<link rel="stylesheet" type="text/css" href="/assets/styles/custom-material-style.scss" />');
    windowPrt.document.write('<link rel="stylesheet" type="text/css" href="/assets/styles/customer-summary-print.scss" />');
  }
}

