import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PriorMonthComponent } from './prior-month.component';

describe('PriorMonthComponent', () => {
  let component: PriorMonthComponent;
  let fixture: ComponentFixture<PriorMonthComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PriorMonthComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PriorMonthComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
