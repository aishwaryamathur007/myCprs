import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ComponentGroupAdminComponent } from './component-group-admin.component';

describe('ComponentGroupAdminComponent', () => {
  let component: ComponentGroupAdminComponent;
  let fixture: ComponentFixture<ComponentGroupAdminComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ComponentGroupAdminComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ComponentGroupAdminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
