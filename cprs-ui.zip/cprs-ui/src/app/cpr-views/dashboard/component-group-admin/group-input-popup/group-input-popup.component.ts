import { Component, Inject, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
    selector: 'app-group-input-popup',
    templateUrl: './group-input-popup.component.html',
    styleUrls: ['./group-input-popup.component.scss']
})
export class GroupInputPopupComponent implements OnInit {
    groupForm: FormGroup;
    groupType: any;
    constructor(public dialogRef: MatDialogRef<any>,
        @Inject(MAT_DIALOG_DATA) public data: any, private dialog: MatDialog) {
        this.dialogRef.addPanelClass('confirm-dialog');
        this.dialogRef.disableClose = true;
    }

    ngOnInit() {
        this.groupForm = new FormGroup({
            groupName: new FormControl('', [Validators.required]),
        });
    }
    ok() {
        if (this.groupForm.valid) {
            this.dialogRef.close({groupValue:this.groupForm.value});
        }
    }

    cancel() {
        this.dialogRef.close(false);
    }
}