import { Component, Inject, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ConfirmComponent } from 'src/app/common/component/confirm/confirm.component';
import { NotificationService } from 'src/app/common/services/notification.service';
import { DashboardService } from '../../service/dashboard.service';
import { GroupInputPopupComponent } from './group-input-popup/group-input-popup.component';
import * as _ from 'lodash-es';

@Component({
  selector: 'app-component-group-admin',
  templateUrl: './component-group-admin.component.html',
  styleUrls: ['./component-group-admin.component.scss']
})
export class ComponentGroupAdminComponent implements OnInit {
  groupForm: FormGroup;
  groupType: any;
  groupValues: any = [];
  rightSection: any = [];
  leftSection: any = [];
  masterData: any = [];
  gpData: any;
  // isSubmit: boolean = false;
  dataFetched: boolean = false;
  fetchingReport: boolean = false;

  newObj: any = {};
  constructor(public dialogRef: MatDialogRef<ComponentGroupAdminComponent>, @Inject(MAT_DIALOG_DATA) public data: any,
    private dbservice: DashboardService, private dialog: MatDialog, private notifService: NotificationService) {
    this.dialogRef.addPanelClass('confirm-dialog');
    this.dialogRef.disableClose = true;
  }

  ngOnInit() {

    this.groupForm = new FormGroup({
      fileType: new FormControl('.xls', [Validators.required]),
      mailAdd: new FormControl('', [Validators.required, Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")]),
      cMailAdd: new FormControl('', [Validators.required, Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")])
    });
    this.getGroupResultList();
  }
  getGroupResultList() {
    this.fetchingReport = true;
    this.dataFetched = false;
    let obj = {
      "cntrctCustId": this.data.data.cntrctCustId,
      "cntrctSrceId": this.data.data.cntrctSrceId,
      "gpTypeNd": this.data.data.groupType,
      "offrActnId": this.data.data.offrActnId,
      "offrId": this.data.data.offrId
    };
    this.dbservice.getGroupResultList(obj).subscribe(resp => {
      if (!!resp) {
        this.leftSection = [];
        this.dataFetched = true;
        this.fetchingReport = false;
        this.masterData = Object.assign({}, resp);
        resp.forEach(el => {
          if (el.GP_ID == 0) {
            this.leftSection.push(el);
          } else {
          }
        });
        this.groupValues = [];
        let groupNames = resp.map(function (ele: any) { return { 'GP_ID': ele['GP_ID'], 'GP_NM': ele['GP_NM'] } });
        groupNames.forEach((element) => {
          let i = this.groupValues.findIndex(e => e?.GP_ID == element?.GP_ID);
          if (i == -1) {
            this.groupValues.push(element);
          }
        });
        // let ind = this.groupValues.findIndex((el) = > el['GP_ID'] == '0');
        let ind = _.findIndex(this.groupValues, { GP_ID: 0 });
        if(ind > -1) {
        this.groupValues.splice(ind, 1);
        }
        this.groupType = this.groupValues[0];
        this.selectGroupValues(this.groupType);
      }
    }, error => {
      this.dataFetched = true;
      this.fetchingReport = false;
      this.notifService.showErrorNotification(error);
    });
  }
  selectGroupValues(gp: any) {
    this.gpData = _.groupBy(this.masterData, 'GP_ID');
    this.rightSection = [];
    this.rightSection = this.gpData[gp?.GP_ID ?? gp?.value?.GP_ID];
    let ind = _.findIndex(this.rightSection, { GP_ELEM_ID: 'undefined' });
    if(ind > -1) {
    this.rightSection.splice(ind, 1);
    }
  }

  hideColumn(index: number) {
    if (this.groupType == undefined) {
      const groupDialog = this.dialog.open(ConfirmComponent, {
        data: {
          type: 2,
          content: 'Please select a group before adding or removing elements.'
        }
      });
      groupDialog.afterClosed().subscribe((val) => { });
    } else {
      this.rightSection[index]['show'] = false;
      this.rightSection[index]['GP_ID'] = 0;
      this.rightSection[index]['GP_NM'] = undefined;
      let col = this.rightSection.splice(index, 1);
      let ind = this.leftSection.findIndex(e => e.GP_ELEM_ID == col[0]['GP_ELEM_ID']);
      if (ind > -1) {
        this.leftSection[ind] = col[0];
      } else {
        this.leftSection.push(col[0]);
      }
      // let indMast = _.findIndex(this.masterData, { GP_ELEM_ID: col.GP_ELEM_ID });
      // this.masterData[indMast] = col;
      this.gpData = _.groupBy(this.masterData, 'GP_ID');
    }
  }

  showColumn(index: number) {
    if (this.groupType == undefined) {
      const groupDialog = this.dialog.open(ConfirmComponent, {
        data: {
          type: 2,
          content: 'Please select a group before adding or removing elements.'
        }
      });
      groupDialog.afterClosed().subscribe((val) => { });
    } else {
      this.leftSection[index]['show'] = true;
      this.leftSection[index]['GP_ID'] = this.groupType.GP_ID;
      this.leftSection[index]['GP_NM'] = this.groupType.GP_NM;
      let col = this.leftSection.splice(index, 1);
      let ind = this.rightSection.findIndex(e => e.GP_ELEM_ID == col[0]['GP_ELEM_ID']);
      if (ind > -1) {
        this.rightSection[ind] = col[0];
      } else {
        this.rightSection.push(col[0]);
      }
      // let indMast = _.findIndex(this.masterData, { GP_ELEM_ID: col.GP_ELEM_ID });
      // this.masterData[indMast] = col;
      this.gpData = _.groupBy(this.masterData, 'GP_ID');
    }
  }
  getSubmitAllChanges() {
    this.fetchingReport = true;
    const listGroup = _.groupBy(this.masterData, 'GP_ID');
    let gpIdGpNm = {};
    Object.keys(listGroup).forEach(el => {
      gpIdGpNm[el] = [];
      listGroup[el].forEach(item => {
        if (item.GP_ELEM_ID != undefined && item.GP_ELEM_ID != 'undefined') {
          gpIdGpNm[el].push(item.GP_ELEM_TX);
        }
      });
    });
    let groupData = {
      "cntrctCustId": this.data.data.cntrctCustId,
      "gpIdGpNm": gpIdGpNm,
      "gpTypeNd": this.data.data.groupType,
      "offrActnId": this.data.data.offrActnId,
      "offrId": this.data.data.offrId,
      "srceId": this.data.data.cntrctSrceId
    };
    this.dbservice.getSubmitAllChanges(groupData).subscribe(resp => {
      this.fetchingReport = false;
      if(!!resp){
      this.notifService.showSuccessNotification(resp);
      // this.getGroupResultList();
      this.dialogRef.close(true);
      }
    }, error => {
      this.fetchingReport = false;
      this.notifService.showErrorNotification(error);
      this.getGroupResultList();
      this.dialogRef.close(true);
    });
  };
  cancel() {
    this.dialogRef.close(false);
  }
  openDialog(eve: any) {
    let dataFecteched: boolean = false;
    let obj: any;
    if (eve == 'ADD' || eve == 'UPDATE') {
      if (eve == 'UPDATE' && this.groupType == undefined) {
        const groupDialog = this.dialog.open(ConfirmComponent, {
          data: {
            type: 2,
            content: 'Please select the group'
          }
        });
        groupDialog.afterClosed().subscribe((val) => { });
      } else {
        const groupDialog = this.dialog.open(GroupInputPopupComponent, {
          width: '450px',
          data: {
            mode: eve
          }
        });
        groupDialog.afterClosed().subscribe((val) => {
          if (!!val) {
            dataFecteched = true;
            obj = {
              "cntrctCustId": this.data.data.cntrctCustId,
              "cntrctSrceId": this.data.data.cntrctSrceId,
              "gpTypeNd": this.data.data.groupType,
              "grpId": this.groupType?.GP_ID ?? '',
              "grpNm": val.groupValue.groupName ?? this.groupType?.GP_NM,
              "mode": eve,
              "offrActnId": this.data.data.offrActnId,
              "offrEffDt": this.data.data.offrEffDt,
              "offrId": this.data.data.offrId
            }
          }
          if (dataFecteched) {
            this.addEditDeleteGroup(obj);
          }
        });
      }
    } else {
      if (this.groupType == undefined) {
        const groupDialog = this.dialog.open(ConfirmComponent, {
          data: {
            type: 2,
            content: 'Please select a group to delete.'
          }
        });
        groupDialog.afterClosed().subscribe((val) => { });
      } else {
        const groupDialog = this.dialog.open(ConfirmComponent, {
          data: {
            type: 1,
            content: 'Are you sure you want to delete the group?'
          }
        });
        groupDialog.afterClosed().subscribe((val) => {
          if (!!val) {
            dataFecteched = true;
            obj = {
              "cntrctCustId": this.data.data.cntrctCustId,
              "cntrctSrceId": this.data.data.cntrctSrceId,
              "gpTypeNd": this.data.data.groupType,
              "grpId": this.groupType?.GP_ID,
              "grpNm": this.groupType?.GP_NM,
              "mode": eve,
              "offrActnId": this.data.data.offrActnId,
              "offrEffDt": this.data.data.offrEffDt,
              "offrId": this.data.data.offrId
            }
          }
          if (dataFecteched) {
            this.addEditDeleteGroup(obj);
          }
        });
      }
    }
  }
  addEditDeleteGroup(compGroup: any) {
    this.fetchingReport = true;
    this.dbservice.addEditCompGroup(compGroup).subscribe(resp => {
      if(!!resp) {
      this.notifService.showSuccessNotification(resp);
      }
      this.fetchingReport = false;
      this.getGroupResultList();
    }, error => {
      this.fetchingReport = false;
      this.getGroupResultList();
      this.notifService.showErrorNotification(error);
    });
  }
}


