import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
import * as  FileSaver from 'file-saver';
import { ModalDropdownComponent } from 'src/app/common/component/modal-dropdown/modal-dropdown.component';
import { DashboardService } from '../../service/dashboard.service';
import { CurrencyPipe } from '@angular/common'

@Component({
  selector: 'child-tracking',
  templateUrl: './child-tracking.component.html',
  styleUrls: ['./child-tracking.component.scss']
})
export class ChildTrackingComponent implements OnInit {
  dataSource: MatTableDataSource<any>;
  isDataFetched: boolean = false;
  fetchingReport: boolean = false;
  urlData: any;
  tableData: any;
  invoiceDt: any;
  tab1 = [
    { key: "action", label: "" },
    { key: "blrId", label: "Biller" },
    { key: "cntrctCustId", label: "Customer ID" },
    { key: "cntrctCustNm", label: "Customer Name" },
    { key: 'cntryNm', label: 'Country Name' },
    { key: "attainmentAmount", label: "Attainment Amount" },
    { key: "percentDiff", label: "Percent Attained" }
  ];
  tab2:any;
  tab3:any;
  dc1: string[] = this.tab1.map(col => col.key);
  dc2: string[];
  dc3: string[];
  ma12Nd: any;
  constructor(private route: ActivatedRoute, private dbservice: DashboardService, private dialog: MatDialog, private router: Router,private cp: CurrencyPipe) {
    this.route.queryParams.subscribe(val => {
      this.urlData = val;
    });
  }

  ngOnInit() {
    this.tab2 = [{ key: "action", label: "" },
    { key: "gpNm", label: this.urlData.gpTypeNd == 'C' ? "Component Group" : "Group" },
    { key: "attainmentAmount", label: "Attainment Amount" }];
    this.tab3 = [
      { key: "elem", label: this.urlData.gpTypeNd == 'C' ? "Component" : "Account" },
      { key: "attainmentAmount", label: "Attainment Amount" }
    ];
    this.dc2 = this.tab2.map(col => col.key);
    this.dc3 = this.tab3.map(col => col.key);
    this.isDataFetched = false;
    this.fetchingReport = true;
    let obj =  {
    "cntrctCustId": this.urlData.custId,
    "cntrctSrceId": this.urlData.srceId,
    "commType": this.urlData.commType,
    "commitmentAmount": this.urlData.commitmentAmount,
    "groupType": this.urlData.gpTypeNd,
    "isPriorMonth": this.urlData.isPriorMonth,
    "offerId": this.urlData.offrId,
    "offrActnId":this.urlData.offrActnId
  };
    this.dbservice.getReportTypeChildTracking(obj).subscribe(resp => {
      if(resp.childCustomersData && resp.childCustomersData.length > 0){
      this.dataSource = new MatTableDataSource(resp.childCustomersData);
      if(resp?.invoiceData[0]?.BILLCYCLETEXT){
      let dt  = resp['invoiceData'][0]['BILLCYCLETEXT'].match(/.{1,4}/g).join('-');
      this.invoiceDt = dt.match(/.{1,7}/g).join('-');
      }
      } else {
        this.dataSource = new MatTableDataSource([]);
      }
      this.isDataFetched = true;
      this.fetchingReport = false;
      this.prepareTableData(resp);
    });
    let ma12Obj = {
      custId: this.urlData.custId,
      offerId: this.urlData.offrId,
      srceId: this.urlData.srceId
    }
    this.getMa12(ma12Obj);
  }
  goBack() {
    window.history.back();
  }
  getMa12(obj: any) {
    this.dbservice.getMa12(obj).subscribe(resp => {
      this.ma12Nd = resp;
    });
  }
  rowExpand(ele: any, table: number) {
    if (table == 1) {
      ele.expand = !ele.expand;
    } else {
      ele.expand1 = !ele.expand1;
    }
  };
  prepareTableData(obj) { 
    this.tableData = [
      { key: "Customer Name", value: this.urlData.custNm },
      { key: "Offer ID", value: this.urlData.offrId },
      { key: "Customer ID", value: this.urlData.custId },
      { key: "Offer Effective Date", value: this.urlData.offrEffDt },
      { key: "Contract Source", value: obj?.sourceText[0]?.SRCE_TX ? obj['sourceText'][0]['SRCE_TX'] : '' },
      { key: "Invoice Date", value: this.invoiceDt },
      { key: "Contract Period", value: this.urlData.startContractPeriod + ' to ' + this.urlData.endContractPeriod },
      { key: "Report Generation Date", value: moment(new Date()).format("YYYY-MM-DD") },
      { key: "Commitment Requirement", value: this.urlData.actnDescTx },
      { key: "Tracking Period", value: this.urlData.trackingPeriod },
      { key: "Offer Action ID", value: this.urlData.offrActnId },
      { key: "Months Through", value: this.urlData.monthsThrough },
      { key: "Commitment Amount", value: this.cp.transform(this.urlData.commitmentAmount,'USD') },
      { key: "Percent Attained", value: this.urlData.percentDiff },
      { key: "Attainment Amount", value: this.cp.transform(this.urlData.attainmentAmount,'USD') },
      { key: "Difference", value: this.cp.transform(this.urlData.diff, 'USD') },
      { key: "MA12 Indicator", value: this.ma12Nd },
      { key: "", value: "" }
    ];
    
  };
  getchildTrackingDownload() {
  let cDownload = {
      "attainmentAmount": this.urlData.attainmentAmount,
      "cntrctCustId": this.urlData.custId,
      "commitmentAmount": this.urlData.commitmentAmount,
      "commitmentReq": this.urlData.actnDescTx,
      "contractPeriod": this.urlData.startContractPeriod + ' to ' + this.urlData.endContractPeriod,
      "contractSource": this.urlData.contSrcTx,
      "customerName": this.urlData.custNm,
      "difference": this.urlData.diff,
      "groupType": this.urlData.gpTypeNd,
      "invoiceDate": this.invoiceDt,
      "isPriorMonth": this.urlData.isPriorMonth,
      "monthsThrough": this.urlData.monthsThrough,
      "offerEffectiveDate": this.urlData.offrEffDt,
      "offerId": this.urlData.offrId,
      "offrActnId": this.urlData.offrActnId,
      "percentAttained": this.urlData.percentDiff,
      "trackingPeriod": this.urlData.trackingPeriod
  };
    this.dbservice.childTrackingDownload(cDownload).subscribe(resp => {
      if (resp) {
        FileSaver.saveAs(resp, (this.urlData.pgName).replace(/[^a-zA-Z0-9]/g, "") + '.xlsx');
      }
    })
  }
  print() {
    const printContent = document.getElementById('print-section');
    const windowPrt = window.open('', '', 'left=0,top=0,width=900,height=900,toolbar=0.scrollbars=0,status=0');
    windowPrt.document.write(printContent.innerHTML);
    windowPrt.document.write('<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500&display=swap" rel="stylesheet">');
    windowPrt.document.write('<link href="https://fonts.googleapis.com/icon?family=Material+Icons|Material+Icons+Round|Material+Icons+Outlined" rel="stylesheet">');
    windowPrt.document.write('<link rel="stylesheet" type="text/css" href="/assets/styles/custom-theme.scss" />');
    windowPrt.document.write('<link rel="stylesheet" type="text/css" href="/assets/styles/variables.scss" />');
    windowPrt.document.write('<link rel="stylesheet" type="text/css" href="/assets/styles/custom-material-style.scss" />');
    windowPrt.document.write('<link rel="stylesheet" type="text/css" href="/assets/styles/customer-summary-print.scss" />');
  }
}

