import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChildTrackingComponent } from './child-tracking.component';

describe('ChildTrackingComponent', () => {
  let component: ChildTrackingComponent;
  let fixture: ComponentFixture<ChildTrackingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ChildTrackingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ChildTrackingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
