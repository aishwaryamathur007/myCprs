import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AeSummaryDashboardComponent } from './ae-summary-dashboard.component';

describe('AeSummaryDashboardComponent', () => {
  let component: AeSummaryDashboardComponent;
  let fixture: ComponentFixture<AeSummaryDashboardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AeSummaryDashboardComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AeSummaryDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
