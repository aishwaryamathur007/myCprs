import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { SearchService } from 'src/app/cpr-views/dashboard/search/service/search.service';
import { ActivatedRoute, Router } from '@angular/router';
import { NotificationService } from 'src/app/common/services/notification.service';
import { Subscription } from 'rxjs';
import * as  FileSaver from 'file-saver';


export interface aeSummaryDashboardTable {
  PRFR_CUST_NM: object;
  CNTRCT_CUST_ID: object;
  OFFR_ID: object;
  OFFR_ACTN_ID: object;
  ACTN_DESC_TX: object;
  ATTN_CAT_CD: object;
  MO_THRU: object;
  ATTAINMENT_AMOUNT: object;
  COMMITMENT_AMOUNT: object;
  PERCENT_DIFF: object;
  TRGT_ATTN_AT: object;
  TRGT_PC_THRU: object;
  TRGT_ATTN_ND: object;
}

@Component({
  selector: 'ae-summary-dashboard',
  templateUrl: './ae-summary-dashboard.component.html',
  styleUrls: ['./ae-summary-dashboard.component.scss']
})
export class AeSummaryDashboardComponent implements OnInit {

  aeSummaryDashboardResultDataSource: MatTableDataSource<any>;
  paginator: any;
  sort: any;
  pageSize = 100;
  load: boolean = false;
  paginatorLoaded: boolean = false;
  selectionOption: string;
  aeSummaryDashboardColumns: any[] = ['PRFR_CUST_NM', 'CNTRCT_CUST_ID', 'OFFR_ID', 'OFFR_ACTN_ID', 'ACTN_DESC_TX', 'ATTN_CAT_CD', 'MO_THRU', 'ATTAINMENT_AMOUNT', 'COMMITMENT_AMOUNT', 'PERCENT_DIFF', 'TRGT_ATTN_AT', 'TRGT_PC_THRU', 'TRGT_ATTN_ND'];
  aeSummaryDashboardHeaders: string[] = ['Customer Name', 'Customer Id', 'Offer Id', 'Action Id', 'Action Description', 'Unit', 'Months Thru', 'Attainment Amount', 'Commitment Amount', 'Percent Attained', 'Target Attainment Amount', 'Target Percent', 'Expired Contract Indicator'];
  serviceMappingRequestStatusArr: aeSummaryDashboardTable[] = [];
  isAeSummary:object;
  subscription: Subscription;
  aeDashboardData: any;

  @ViewChild('paginator', { static: false }) set matPaginator(
    mp: MatPaginator
  ) {
    this.paginator = mp;
    if (mp && this.aeSummaryDashboardResultDataSource) {
      this.aeSummaryDashboardResultDataSource.paginator = this.paginator;
      this.paginatorLoaded = true;
    }
  }
  @ViewChild('sort', { static: false }) set matSort(ms: MatSort) {
    this.sort = ms;

    if (ms && this.aeSummaryDashboardResultDataSource) {
      this.aeSummaryDashboardResultDataSource.sort = this.sort;
    }
  }


  constructor(
    private service: SearchService,  
    private router: Router,
    private activeRouter: ActivatedRoute,
    private _notifService: NotificationService
  ) { 
    this.activeRouter.queryParams.subscribe(param => {
      this.selectionOption = param.selectOption;
    });
  }

  ngOnInit(): void {
    this.subscription = this.service.currentMessage.subscribe(message => this.isAeSummary = message);
    this.getAeSummaryDashboard();
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  getAeSummaryDashboard(){
    this.load = false;
    const paramObj = {
      selectOption  : this.selectionOption,
      webUserId: 'di1218'
    };
    this.service.getAeSalesSummaryDashboard(paramObj).subscribe(resp => {
      this.aeDashboardData = resp;
      this.aeSummaryDashboardResultDataSource = new MatTableDataSource(resp);
      this.load = true;
    },
    error => {
      console.log(error);
      this._notifService.showErrorNotification(error);
    });
  }

  doFilter(value: string) {
    this.aeSummaryDashboardResultDataSource.filter = value.trim().toLocaleLowerCase();
  }

  backSearch(){
    this.router.navigate(['dashboard/search']);
  }

  getRound(val: any){
    return Math.round(val)
  }

  goDashboard(column: any, header: any){
    let searchType: string;
    switch (header) {
      case 'Customer Name':
        searchType = '1';
        break;
      case 'Customer Id':
        searchType = '2';
        break;
      case 'Offer Id':
        searchType = '3';
        break;
      default:
        break;
    }
    this.router.navigate(['dashboard/search']);
    let aeSummaryToDashboard = {
      searchType: searchType,
      searchValue: column
    }
    this.service.aeSummaryDashMessage(aeSummaryToDashboard);
  }
  cprsDownload() {
    let keyList = [{key:'PRFR_CUST_NM',label:'Customer Name'},{key:'CNTRCT_CUST_ID',label:'Customer Id'},{key:'OFFR_ID',label:'Offer Id'},{key:'OFFR_ACTN_ID',label:'Action Id'},{key:'ACTN_DESC_TX',label:'Action Description'},{key:'ATTN_CAT_CD',label:'Unit'},{key:'MO_THRU',label:'Months Thru'},{key:'ATTAINMENT_AMOUNT',label:'Attainment Amount'},
                    {key:'COMMITMENT_AMOUNT',label:'Commitment Amount'},{key:'PERCENT_DIFF',label:'Percent Attained'},{key:'TRGT_ATTN_AT',label:'Target Attainment Amount'},{key:'TRGT_PC_THRU',label:'Target Percent'},{key:'TRGT_ATTN_ND',label:'Expired Contract Indicator'}];
    let bodytitles = {}, bodyData = [];
    keyList.forEach((col, index) => {
      bodytitles[col.key] = {
        "sequenceNm": index,
        "titleName": col.label
      }
    });
    this.aeDashboardData.forEach(data => {
      let row = {};
      keyList.forEach(col => {
          row[col.key] = data[col.key];
        });
        bodyData.push(row);

      });
    let download = {
      "bodySection": {
        "inputValues": bodyData,
        "titles": bodytitles
      },
      "headerSection": {
        "inputValues": [],
        "titles": {}
      },
      "sheetName": "AeSummaryDashboard"

    }
    this.service.cprsDownload(download).subscribe(resp => {
      if (resp) {
        FileSaver.saveAs(resp, 'AeSummaryDashboard' + '.xlsx');
      }
    })
  };
}
