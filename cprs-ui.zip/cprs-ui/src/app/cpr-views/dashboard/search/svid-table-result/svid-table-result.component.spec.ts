import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SvidTableResultComponent } from './svid-table-result.component';

describe('SvidTableResultComponent', () => {
  let component: SvidTableResultComponent;
  let fixture: ComponentFixture<SvidTableResultComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SvidTableResultComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SvidTableResultComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
