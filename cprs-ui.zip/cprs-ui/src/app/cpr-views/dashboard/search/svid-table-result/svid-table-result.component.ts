import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import * as  FileSaver from 'file-saver';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { SearchService } from 'src/app/cpr-views/dashboard/search/service/search.service';
import { SvidExpendResultComponent } from 'src/app/cpr-views/dashboard/search/svid-expend-result/svid-expend-result.component';

export interface svidSearchResultColumns {
  PRFR_CUST_NM: string;
  ACCT_GP_ID: string;
  SV_SLS_POS_ID: string;
  CNTRCT_CUST_ID: string;
  OFFR_ACTN_ID: string;
  OFFR_ID: string;
  CNTRCT_SRCE_TX: string;
  ATTN_AT: number;
  CMNT_AT: number;
  DIFF: number;
  OFFR_ACTN_MSR_PRD_CD: string;
  MO_THRU: number;
  PC_THRU: number;
  PC_ATTN: number;
  CUST_SEG_CD: string;
  SLS_VP_POS_LAST_NM: string;
  SLS_VP_POS_ID: string;
  SR_SLS_MGR_POS_LAST_NM: string;
  SR_SLS_MGR_POS_FRST_NM: string;
  SR_SLS_MGR_POS_ID: string;
  BR_MGR_POS_LAST_NM: string;
  BR_MGR_POS_FRST_NM: string;
  BR_MGR_POS_ID: string;
  SLS_MGR_POS_LAST_NM: string;
  SLS_MGR_POS_FRST_NM: string;
  SLS_MGR_POS_ID: string;
  SLS_POS_FRST_NM: string;
  SLS_POS_LAST_NM: string;
  SLS_POS_ID: string;
}

@Component({
  selector: 'svid-table-result',
  templateUrl: './svid-table-result.component.html',
  styleUrls: ['./svid-table-result.component.scss'],
  providers: [DatePipe]
})
export class SvidTableResultComponent implements OnInit {
  customerId: any;
  isPid: any;
  load: boolean = false;
  donwloading: any;
  isSvid: any;
  isSalesUser: any;
  svidSearchResultDisplayedColumns: any[] = ['PRFR_CUST_NM', 'ACCT_GP_ID', 'SV_SLS_POS_ID', 'CNTRCT_CUST_ID', 'OFFR_ACTN_ID', 'OFFR_ID', 'CNTRCT_SRCE_TX', 'ATTN_AT', 'CMNT_AT', 'DIFF', 'OFFR_ACTN_MSR_PRD_CD', 'MO_THRU', 'PC_THRU', 'PC_ATTN', 'CUST_SEG_CD', 'SLS_VP_POS_LAST_NM', 'SLS_VP_POS_ID', 'SR_SLS_MGR_POS_LAST_NM', 'SR_SLS_MGR_POS_FRST_NM', 'SR_SLS_MGR_POS_ID', 'BR_MGR_POS_LAST_NM', 'BR_MGR_POS_FRST_NM', 'BR_MGR_POS_ID', 'SLS_MGR_POS_LAST_NM', 'SLS_MGR_POS_FRST_NM', 'SLS_MGR_POS_ID', 'SLS_POS_FRST_NM', 'SLS_POS_LAST_NM', 'SLS_POS_ID'];
  svidSearchResultDisplayHeaders: string[] = ['Customer Name', 'SVID', 'SVID PID', 'Customer ID', 'Offer Action Id', 'Offer Id', 'Bundled Offer', 'Attainment Amount', 'Commitment Amount', 'Difference', 'Tracking Period', 'Commitment Months Completed', '% of Committed Months Completed', 'Percent Attained', 'Segment', 'VP-Last Name', 'VP PID', 'Executive Sales Director Last Name', 'Executive Sales Director First Name', 'Executive Sales Director PID', 'Premier Client Sales Manager Last Name', 'Premier Client Sales Manager First Name', 'Premier Client Sales Manager PID', 'Strategic Account Lead Last Name', 'Strategic Account Lead First Name', 'Strategic Account Lead PID', 'Sales Executive Last Name', 'Sales Executive First Name', 'Sales Executive PID'];
  svidEnterpriseDataSource: svidSearchResultColumns[] = [];

  constructor(private router: Router, 
    private activeRouter: ActivatedRoute,
    public dialog: MatDialog,
    private datePipe: DatePipe,
    private service: SearchService) { 
      this.activeRouter.queryParams.subscribe(param => {
        this.customerId = param.customerId;
        this.isSalesUser = param.securityLevel;
        this.isPid = param.isPid;
      });
    }

  ngOnInit(): void {
    let params: any;
    if(this.isSalesUser === '2'){
      params = {
        pid: '7E27',
        svid: '',
      }
      this.svidTableApi(params);
    } else {
      if(this.isPid !== ""){
        params = {
          pid: this.isPid,
          svid: null,
        }
      } else {
        params = {
          pid: '',
          svid: this.customerId === "" ? null : this.customerId,
        }
      }
      this.svidTableApi(params);
    }
  }

  svidTableApi(params: any){
    this.service.getSvidTableReslt(params).subscribe(resp => {
      console.log(resp);
      this.load = true;
      this.svidEnterpriseDataSource = resp;
      this.isSvid = resp[0].ACCT_GP_ID;
    });
  }

  backSearch(){
    this.router.navigate(['dashboard/search']);
  }
  
  getSvidTableExpendResult(ele: any){
    console.log(ele);
    this.useDailog(ele);
  }

  useDailog(rowDataObj: any) {
    this.dialog.open(SvidExpendResultComponent, {
      width: '780px',
      disableClose: true,
      data: rowDataObj
    }).afterClosed().subscribe(result => {
      console.log(result)
    });
  }

  async download() {
    if (this.donwloading) { return; }
    this.load = false;
    this.donwloading = true;
    let offerIdDetailsObj = this.svidEnterpriseDataSource.map(v => ({ actionId: v.OFFR_ACTN_ID, customerId: v.CNTRCT_CUST_ID, offerId: v.OFFR_ID}));
    let obj = {
      offerIdDetails: offerIdDetailsObj,
      svid: this.isSvid
    };

    await this.service.downloadSvidExpandResultData(obj).toPromise().then(resp => {
      let date = this.datePipe.transform(Date.now(), 'yyyy-MM-dd');
      if (resp) {
        FileSaver.saveAs(resp, this.customerId + '_' + date + '.xlsx');
      }
      this.donwloading = false;
      this.load = true;
    });
  }

}
