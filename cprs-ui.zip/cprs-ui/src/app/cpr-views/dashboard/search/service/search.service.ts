import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class SearchService {

  private aeSummaryDashData = new BehaviorSubject({});
  currentMessage = this.aeSummaryDashData.asObservable();
  aeSummaryDashMessage(message: object) {
    this.aeSummaryDashData.next(message)
  }

  searchType: any[] = [{
    value: 1,
    display: 'Customer Name'
  }, {
    value: 2,
    display: 'Customer Id'
  }, {
    value: 3,
    display: 'Offer Id'
  }];

  graphType: any[] = [{
    value: 0,
    display: 'Monthly Values'
  }, {
    value: 1,
    display: 'Incremental Values'
  }];

  trackType: any[] = [{
    value: 0,
    display: 'Parent View'
  }, {
    value: 1,
    display: 'Child View'
  }];

  groupType: any[] = [{
    value: 0,
    display: 'Component Grouping'
  }, {
    value: 1,
    display: 'Account Grouping'
  }];

  commType: any[] = [{
    value: 0,
    display: 'Show Zero Commitment'
  }, {
    value: 1,
    display: 'Hide Zero Commitment'
  }];

  levelComm: any[] = [{
    value: 0,
    display: 'High Level Commitments'
  }, {
    value: 1,
    display: 'All Commitments'
  }];

  svidSearchType: any[] = [{
    value: 0,
    display: 'SAART PID'
  }, {
    value: 1,
    display: 'SVID'
  }, {
    value: 2,
    display: 'SVID Name'
  }];

  constructor(private http: HttpClient) { }

  getCustomers(obj:any): Observable<any> {  
     return this.http.post(environment.cprApiBaseUrl + '/reporting/getReportingSearchResults', obj);
  }

  getSvidConsResltSearch(obj:any): Observable<any> {  
     return this.http.get(environment.cprApiBaseUrl + '/reporting/svidConsResltSearch', {params:obj});
  }

  getSvidTableReslt(obj:any): Observable<any> {  
     return this.http.get(environment.cprApiBaseUrl + '/reporting/getSvidTableResult', {params:obj});
  }

  getPID(obj:any): Observable<any> {  
     return this.http.get(environment.cprApiBaseUrl + '/reporting/getPid', {params:obj});
  }

  getSvidTableExpendReslt(obj:any): Observable<any> {  
     return this.http.get(environment.cprApiBaseUrl + '/reporting/getTableExpandData', {params:obj});
  }

  getAeSalesSummaryDashboard(obj:any): Observable<any> {  
     return this.http.get(environment.cprApiBaseUrl + '/reporting/getAeSalesSummaryDashboard', {params:obj});
  }

  downloadSvidExpandResultData(obj:any): Observable<any> {  
     return this.http.post(environment.cprApiBaseUrl + '/reporting/downloadReport', obj,
     {
        responseType: 'blob'
      });
  }
  cprsDownload(download:any) : Observable<any> {
    return this.http.post(environment.cprApiBaseUrl+ '/reporting/cprsDownload', download, {responseType: 'blob'});
  };
}
