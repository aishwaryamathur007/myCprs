import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SvidExpendResultComponent } from './svid-expend-result.component';

describe('SvidExpendResultComponent', () => {
  let component: SvidExpendResultComponent;
  let fixture: ComponentFixture<SvidExpendResultComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SvidExpendResultComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SvidExpendResultComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
