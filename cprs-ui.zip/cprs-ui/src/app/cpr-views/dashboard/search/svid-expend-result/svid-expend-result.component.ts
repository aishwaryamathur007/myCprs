import { Component, OnInit, Inject, Optional } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { SearchService } from 'src/app/cpr-views/dashboard/search/service/search.service';

export interface svidExpendDataSourceColumns {
  BL_ACCT_ID: string;
  SUB_GP_DESC_TX: string;
  ATTN_AT: number;
}

@Component({
  selector: 'svid-expend-result',
  templateUrl: './svid-expend-result.component.html',
  styleUrls: ['./svid-expend-result.component.scss']
})

export class SvidExpendResultComponent implements OnInit {

  svidExpendDisplayedColumns: any[] = ['BL_ACCT_ID', 'SUB_GP_DESC_TX', 'ATTN_AT'];
  svidExpendDisplayedHeaders: string[] = ['Contributing Accounts', 'Contributing Components', 'Account Attainment Amount'];
  svidExpendDataSource: svidExpendDataSourceColumns[] = [];
  paramObj: any;
  load: boolean = false;

  constructor(public dialogRef: MatDialogRef<SvidExpendResultComponent>,
    private service: SearchService,
    @Optional() @Inject(MAT_DIALOG_DATA) public data: any) { 
    this.paramObj = {
      actionId: data.OFFR_ACTN_ID,
      custId: data.CNTRCT_CUST_ID,
      offerId: data.OFFR_ID,
    }
  }

  ngOnInit(): void {
    this.getSvidTableExpandResult();
  }

  getSvidTableExpandResult(){
    this.service.getSvidTableExpendReslt(this.paramObj).subscribe(resp => {
      this.svidExpendDataSource = resp;
      this.load = true;
    });
  }

}
