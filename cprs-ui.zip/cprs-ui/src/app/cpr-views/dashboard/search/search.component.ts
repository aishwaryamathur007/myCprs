import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { SearchService } from 'src/app/cpr-views/dashboard/search/service/search.service';

export class UserAuth {
  userId: string = '';
  app: string = '';
  appId: number;
  orgCode: string = '';
  whl: string = '';
  indKy: string = '';
  govRestNd: string = '';
  aebm: string = '';
  securityLevel: string = null;
  accessGranted: boolean = null;
  userVars: any[] = [];
}

@Component({
  selector: 'search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss']
})
export class SearchComponent implements OnInit {
  searchingCustomer: boolean;
  customerResult: string[] = null;
  isSvidConsolidation: boolean = false;
  customerDataLoading: boolean = false;
  mode = 'search';
  searchForm: FormGroup;
  svidSearchForm: FormGroup;
  searchTypes: any[];
  groupTypes: any[];
  graphTypes: any[];
  commTypes: any[];
  levelComms: any[];
  trackTypes: any[];
  svidSearchTypes: any[];
  userAuth: UserAuth = new UserAuth();
  isSalesUser: boolean;
  localCookie: UserAuth = new UserAuth();
  saveDetails:any;
  isAeSummary:any;
  subscription: Subscription;


  constructor(private fb: FormBuilder,
    private router: Router,
    private service: SearchService) {
    this.searchTypes = this.service.searchType;
    this.groupTypes = this.service.groupType;
    this.graphTypes = this.service.graphType;
    this.commTypes = this.service.commType;
    this.levelComms = this.service.levelComm;
    this.trackTypes = this.service.trackType;
    this.svidSearchTypes = this.service.svidSearchType;
    let cookies: Array<string> = document.cookie.split(';');
    cookies.forEach(c => {
      let values = c.trim().split('=');
      if (this.userAuth.hasOwnProperty(values[0])) {
        this.localCookie[values[0]] = values[1];
      }
    });
  }

  ngOnInit(): void {

    this.subscription = this.service.currentMessage.subscribe(message => this.isAeSummary = message)

    this.setupSearchForm();
    this.setupSvidSearchForm();
    if(this.localCookie.securityLevel === '2'){
      this.searchCustomer();
    }
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
  
  setupSearchForm(): void {
    this.searchForm = this.fb.group({
      searchText: [],
      searchType: [1, [Validators.required]],
      graphType: [0, [Validators.required]],
      trackType: [0, [Validators.required]],
      groupType: [0, [Validators.required]],
      commType: [0, [Validators.required]],
      levelComm: [0, [Validators.required]]
    });
  }
  setupSvidSearchForm(): void {
    this.svidSearchForm = this.fb.group({
      svidSearchText: [null, [Validators.required]],
      svidSearchType: ['SAART PID', [Validators.required]]
    });
  }

  svidSearchView(){
    if(this.localCookie.securityLevel === '2'){
      let param = {
        webUserId: this.localCookie.userId
      }
      this.service.getPID(param).subscribe(resp => {
        let custDetails = {
          customerId: resp ?? '',
          securityLevel: this.localCookie.securityLevel
        }
        this.router.navigate(['dashboard/search/svid-result'], { queryParams: custDetails });
      });
    } else {
      this.isSvidConsolidation = true;
      this.customerDataLoading = false;
      this.customerResult = [];
    }
  }

  getPid(obj: any){
    let param = {
      webUserId: obj
    }
    this.service.getPID(param).subscribe(resp => {
      return resp;
    });
  }

  svidServiceMapView(){
    let custDetails = {
      dashboard: true,
      webUserId: this.localCookie.userId
    }
    this.router.navigate(['dashboard/search/svid-enterprise-service-mapping'], { queryParams: custDetails });
  }

  aeSummaryDashboardView(){
    let custDetails = {
      dashboard: true,
      selectOption: String(this.searchForm.get('levelComm').value)
    }
    this.router.navigate(['dashboard/search/ae-summary-dashboard'], { queryParams: custDetails });
  }

  backSearch(){
    this.isSvidConsolidation = false;
    this.customerDataLoading = false;
    this.customerResult = [];
    this.setupSvidSearchForm();
    this.setupSearchForm();
  }

  cancel() {
    this.setupSearchForm();
    this.customerResult = [];
    
  }

  searchCustomer() {
    this.searchingCustomer = true;
    if(this.localCookie.securityLevel === '2'){
      let obj: object = {};
      if(this.isAeSummary.hasOwnProperty('searchType')){
        obj = {
          cookieWHL: this.localCookie.whl,
          commType: String(this.searchForm.get('commType').value),
          rdGraphType: String(this.searchForm.get('graphType').value),
          rdGroupType: String(this.searchForm.get('groupType').value),
          rdTrackType: String(this.searchForm.get('trackType').value),
          searchType: this.isAeSummary.searchType,
          searchValue: this.isAeSummary.searchValue,
          securityLevel: this.localCookie.securityLevel,
          webUserId: this.localCookie.userId
        }
        this.service.aeSummaryDashMessage({})
      } else {
        obj = {
          cookieWHL: this.localCookie.whl,
          rdCommType: String(this.searchForm.get('commType').value),
          rdGraphType: String(this.searchForm.get('graphType').value),
          rdGroupType: String(this.searchForm.get('groupType').value),
          rdTrackType: String(this.searchForm.get('trackType').value),
          searchType: '',
          searchValue: '',
          securityLevel: this.localCookie.securityLevel,
          webUserId: this.localCookie.userId
        }
      }
      
      this.landingScreenSearch(obj);
    } else {
      //this.searchingCustomer = true;
      let obj = {
        cookieWHL: this.localCookie.whl,
        rdCommType: String(this.searchForm.get('commType').value),
        rdGraphType: String(this.searchForm.get('graphType').value),
        rdGroupType: String(this.searchForm.get('groupType').value),
        rdTrackType: String(this.searchForm.get('trackType').value),
        searchType: String(this.searchForm.get('searchType').value),
        searchValue: this.searchForm.get('searchText').value ?? '',
        securityLevel: this.localCookie.securityLevel,
        webUserId: this.localCookie.userId
        //webUserId: "hb163t"
      }
      this.landingScreenSearch(obj);
      this.saveDetails =obj;
    }
  }

  landingScreenSearch(obj: any){
    this.service.getCustomers(obj).subscribe(resp => {
      this.customerResult = resp;
      this.searchingCustomer = false;
      this.customerDataLoading = true;
    });
  }

  svidSearchCustomer(){
    this.searchingCustomer = true;
    let rplChar = /\*/g;
    let rplWith = '%';
    let checkSearchText = this.svidSearchForm.get('svidSearchText').value;
    let fnlChar = checkSearchText.includes('*') ? checkSearchText.replace(rplChar, rplWith) : '%'+checkSearchText+'%';
    let params = {
      searchText: fnlChar,
      searchType: this.svidSearchForm.get('svidSearchType').value.toLowerCase()
    }
    this.service.getSvidConsResltSearch(params).subscribe(resp => {
      this.customerResult = resp;
      this.searchingCustomer = false;
      this.customerDataLoading = true;
    });
  }

  getSvidTableResult(ele: any) {
    let custDetails = {
      customerId: ele.ACCT_GP_ID ? ele.ACCT_GP_ID : ele.SLS_POS_ID,
      securityLevel: this.localCookie.securityLevel,
      isPid: ele.SLS_POS_ID ?? ''
    }
    this.router.navigate(['dashboard/search/svid-result'], { queryParams: custDetails });
  }
  
  navigateTo(ele:any) {
    let obj = Object.assign({},ele,this.saveDetails);      
    this.router.navigate(['/dashboard','search-result'], { queryParams: obj });
  }

  searchChange(val: any){
    if(this.localCookie.securityLevel === '2'){
      this.searchingCustomer = true;
      let obj = {
        cookieWHL: this.localCookie.whl,
        rdCommType: String(this.searchForm.get('commType').value),
        rdGraphType: String(this.searchForm.get('graphType').value),
        rdGroupType: String(this.searchForm.get('groupType').value),
        rdTrackType: String(this.searchForm.get('trackType').value),
        searchType: '',
        searchValue: '',
        securityLevel: this.localCookie.securityLevel,
        webUserId: "hb163t"
      }
      this.landingScreenSearch(obj);
    }
  }

}
