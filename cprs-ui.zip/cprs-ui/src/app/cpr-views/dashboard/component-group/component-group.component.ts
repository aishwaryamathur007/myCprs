import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
import * as  FileSaver from 'file-saver';
import { DashboardService } from '../../service/dashboard.service';
import { NotificationService } from 'src/app/common/services/notification.service';

@Component({
  selector: 'component-group',
  templateUrl: './component-group.component.html',
  styleUrls: ['./component-group.component.scss']
})
export class ComponentGroupComponent implements OnInit {
  dataSource: MatTableDataSource<any>;
  isDataFetched: boolean = false;
  fetchingReport: boolean = false;
  urlData: any;
  tableData: any = [];
  invoiceDt: any;
  tab1 = [];
  dc1: string[];
  constructor(private route: ActivatedRoute, private dbservice: DashboardService, private dialog: MatDialog,
     private router: Router, private notifService:NotificationService) {
    this.route.queryParams.subscribe(val => {
      this.urlData = val;
    });
  }
  goBack() {
    window.history.back();
  }
  ngOnInit() {
    if (this.urlData.slcTrackingType != "prior_period_component_trending" && this.urlData.slcTrackingType != "prior_period_account_trending") {
      let obj = [
        { key: "Measurement Displayed", value: this.urlData.msgrDis },
        { key: this.urlData.gpTypeNd == 'C' ? "Component Group" : "Account Group", value: this.urlData.gpNm }];
      this.tableData = this.tableData.concat(obj);
    }
   
      if(this.urlData.gpTypeNd == 'C') {
        this.tab1.push({ key: "SUB_GP_DESC_TX", label: "Component" });
      } else {
        this.tab1.push({ key: "BL_ACCT_ID", label: "Account" });
      }
      if(this.urlData.slcTrackingType == 'group_tracking') {
        this.tab1.push({ key: "ATTAINMENT_AMOUNT", label: "Attainment Amount" });
      }
    this.isDataFetched = false;
    this.fetchingReport = true;
    let obj = {
      "actnId": this.urlData.actnId,
      "annivDt": this.urlData.annivDt,
      "custId": this.urlData.custId,
      "expiryNd": '',
      "exprNd": this.urlData.exprNd,
      "gpId": this.urlData.gpId,
      "gpNm": this.urlData.gpNm,
      "gpTypeNd": this.urlData.gpTypeNd,
      "igChoice": this.urlData.igChoice,
      "offrActnId": this.urlData.offrActnId,
      "offrEffDt": this.urlData.offrEffDt,
      "offrId": this.urlData.offrId,
      "slcTrackingType": this.urlData.slcTrackingType,
      "srceId": this.urlData.srceId,
      "isParentView": this.urlData.isParentView
    };
    let sName:any;
    if(this.urlData.slcTrackingType == 'account_group_trending'|| this.urlData.slcTrackingType == 'group_tracking' ||
     this.urlData.slcTrackingType == 'component_group_trending' || this.urlData.slcTrackingType == 'prior_period_account_trending' ||
     this.urlData.slcTrackingType == 'group_trending') {
      sName = 'commitmentRequirement';
    } else {
      sName = 'getDataComponentTrading';
    }
    this.dbservice[sName](obj).subscribe(resp => {
      this.prepareTableData(resp);
      if (!!resp && resp?.qCommitments?.length > 0) {
        // this.dataSource = new MatTableDataSource(resp.qCommitments);
        // resp.qCommitments.forEach(data => {
        //   this.tab1 = this.tab1.concat(this.getTableLabel(data.ANNIVERSARY_YEAR, data.ANNIVERSARY_MONTH, data.OFFR_DUR + data.ANNIVERSARY_MONTH - 1));
        //   this.dc1 = this.tab1.map(col => col.key);
        // Object.keys(resp.qCommitments[0]).forEach(el => {
        //   if (el.includes('MONTH') && !el.includes('ANNIVERSARY_MONTH')) {
        //     // this.tab1.push({ key: el, label: el });
        //     keyArr.push({key:el,value:data['qCommitments'][el]})            
        //   }
        // });
        // });
        if(this.urlData.slcTrackingType != 'group_tracking' && this.urlData.slcTrackingType != 'component_trending'){
        this.tab1 = this.tab1.concat(this.getTableLabel(resp.qCommitments[0].ANNIVERSARY_YEAR, resp.qCommitments[0].ANNIVERSARY_MONTH, resp.qCommitments[0].OFFR_DUR + resp.qCommitments[0].ANNIVERSARY_MONTH - 1));
        this.dc1 = this.tab1.map(col => col.key);
        const updatedarry = this.RenameallKeys(resp.qCommitments, this.dc1);
        this.dataSource = new MatTableDataSource(updatedarry);
        } else {
          this.dc1 = this.tab1.map(col => col.key);
          this.dataSource = new MatTableDataSource(resp.qCommitments);
        }
        this.isDataFetched = true;
        this.fetchingReport = false;
      } else {
        this.dataSource = new MatTableDataSource([]);
        this.isDataFetched = true;
        this.fetchingReport = false;
      }
    }, error => {
      this.isDataFetched = true;
      this.fetchingReport = false;
      this.notifService.showErrorNotification(error);
    });
  }
  RenameallKeys = (emparr, replaceKeys) => {
    const ele = [];
    emparr.map(emp => {
      const renameObj = {};
      Object.keys(emp).forEach((key, i) => {
        if ((key.includes('MONTH') && !key.includes('ANNIVERSARY_MONTH')) || key.includes('SUB_GP_DESC_TX') || key.includes('BL_ACCT_ID')) {
          for (let j = 0; j < replaceKeys.length; j++) {
            if (Object.keys(renameObj).indexOf(replaceKeys[j]) == -1) {
              renameObj[replaceKeys[j]] = emp[key];
              break;
            }
          }
        }
      });
      renameObj['ATTN_CAT_CD'] = emp['ATTN_CAT_CD'];
      renameObj['ATTN_DSPL_CD'] = emp ['ATTN_DSPL_CD'];
      ele.push(renameObj);
    });
    return ele;
  };
  getTableLabel(year, month, duration) {
    const months = Array.from({ length: parseInt(duration) }, (item, i) => {
      if (i >= (parseInt(month) - 1)) {
        return { key: new Date(parseInt(year), i).toLocaleString('en-US', { month: 'long', year: 'numeric' }), label: new Date(parseInt(year), i).toLocaleString('en-US', { month: 'long', year: 'numeric' }) };
      }
    });
    const results = months.filter(element => { return element !== undefined; });
    return results;
  }
  prepareTableData(resp) {
    let columnData = [
      { key: "Customer Name", value: this.urlData.custNm },
      { key: "Offer ID", value: this.urlData.offrId },
      { key: "Customer ID", value: this.urlData.custId },
      { key: "Offer Effective Date", value: this.urlData.offrEffDt },
      { key: "Contract Source", value: this.urlData.contSrcTx },
      { key: "Invoice Date", value: this.urlData.invoiceDt },
      { key: "Contract Period", value: this.urlData.startContractPeriod + " to " + this.urlData.endContractPeriod },
      { key: "Report Generation Date", value: moment(new Date()).format("YYYY-MM-DD") },
      { key: 'Commitment Requirement', value: this.urlData.commitReq },
      { key: 'Offer Action ID', value: this.urlData.offrActnId },
      { key: "MA12 Indicator", value: this.urlData.ma12Nd },
      { key: "Contract Admin Date", value: this.urlData.cntAdminDt }
    ];
    this.tableData = columnData.concat(this.tableData);
  };
  cprsDownload() {
    let headerData = [], headerobj = {}, headertitles = {};
    this.tableData.forEach((td, index) => {
      if (td.key != "") {
        headerobj[td.key] = td.value;
        headertitles[td.key] = {
          "sequenceNm": index,
          "titleName": td.key
        }
      }
    });
    let bodytitles = {}, bodyData = [];
    headerData.push(headerobj);
    this.dataSource.data.forEach(data => {
      let bodyObj = {};
      this.tab1.forEach((ele, index) => {
        if (ele.key != "") {
          bodyObj[ele.key] = data[ele.key];
          bodytitles[ele.key] = {
            "sequenceNm": index,
            "titleName": ele.label
          }
        }
      });
      bodyData.push(bodyObj);
    });
    let download = {
      "bodySection": {
        "inputValues": bodyData,
        "titles": bodytitles
      },
      "headerSection": {
        "inputValues": headerData,
        "titles": headertitles
      },
      "sheetName": (this.urlData.pgName).replace(/[^a-zA-Z0-9]/g, "")

    }
    this.fetchingReport = true;
    this.dbservice.cprsDownload(download).subscribe(resp => {
      this.fetchingReport = false;
      if (!!resp) {
        FileSaver.saveAs(resp, 'Commitment' + (this.urlData.pgName).replace(/[^a-zA-Z0-9]/g, "") + '.xlsx');
      }
    },error => {
      this.fetchingReport = false;
      this.notifService.showErrorNotification(error);
    })
  };
  print() {
    const printContent = document.getElementById('print-section');
    const windowPrt = window.open('', '', 'left=0,top=0,width=900,height=900,toolbar=0.scrollbars=0,status=0');
    windowPrt.document.write(printContent.innerHTML);
    windowPrt.document.write('<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500&display=swap" rel="stylesheet">');
    windowPrt.document.write('<link href="https://fonts.googleapis.com/icon?family=Material+Icons|Material+Icons+Round|Material+Icons+Outlined" rel="stylesheet">');
    windowPrt.document.write('<link rel="stylesheet" type="text/css" href="/assets/styles/custom-theme.scss" />');
    windowPrt.document.write('<link rel="stylesheet" type="text/css" href="/assets/styles/variables.scss" />');
    windowPrt.document.write('<link rel="stylesheet" type="text/css" href="/assets/styles/custom-material-style.scss" />');
    windowPrt.document.write('<link rel="stylesheet" type="text/css" href="/assets/styles/customer-summary-print.scss" />');
  }
}
