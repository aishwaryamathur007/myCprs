import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CommitmentTrackingComponent } from './commitment-tracking.component';

describe('CommitmentTrackingComponent', () => {
  let component: CommitmentTrackingComponent;
  let fixture: ComponentFixture<CommitmentTrackingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CommitmentTrackingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CommitmentTrackingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
