import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
import * as  FileSaver from 'file-saver';
import { ModalDropdownComponent } from 'src/app/common/component/modal-dropdown/modal-dropdown.component';
import { DashboardService } from '../../service/dashboard.service';
import { NotificationService } from 'src/app/common/services/notification.service';
import { UserAuthService } from 'src/app/shared/service/user-auth.service';

@Component({
  selector: 'commitment-tracking',
  templateUrl: './commitment-tracking.component.html',
  styleUrls: ['./commitment-tracking.component.scss']
})
export class CommitmentTrackingComponent implements OnInit {
  dataSource: MatTableDataSource<any>;
  isDataFetched: boolean = false;
  fetchingReport: boolean = false;
  urlData: any;
  tableData: any;
  invoiceDt: any;
  tab1 = [
    { key: "ACTN_DESC_TX", label: "Commitment Requirement" },
    { key: "OFFR_ACTN_ID", label: "Offer Action ID" },
    { key: "TRACKING_PERIOD", label: "Tracking Period" },
    { key: 'ATTN_CAT_CD', label: 'Measurement' },
    { key: "CNTRCT_ADMIN_DT", label: "Contract Admin Date" },
    { key: "ANNIV_DT", label: "Anniversary Date" },
    { key: "ATTAINMENT_AMOUNT", label: "Attainment Amount" },
    { key: "COMMITMENT_AMOUNT", label: "Commitment Amount" },
    { key: "DIFF", label: "Difference" },
    { key: "PERCENT_DIFF", label: "Percent Attained" },
    { key: "TARF_REF_NM", label: "Contract Reference" }
  ];
  tab2 = [
    { key: "ACTN_DESC_TX", label: "Commitment Requirement" },
    { key: "OFFR_ACTN_ID", label: "Offer Action ID" },
    { key: "TRACKING_PERIOD", label: "Tracking Period" },
    { key: "TRK_RVNU_TYPE_CD", label: "Measurement" },
    { key: "CURR_RVNU", label: "Revenue Amount" },
    { key: "CURR_USG_MI_ET", label: "Minutes" },
    { key: "CURR_USG_MSG_CT", label: "Messages" },
    { key: "EXPR_ND", label: "Expired Contract Indicator" }
  ];
  dc1: string[] = this.tab1.map(col => col.key);
  dc2: string[] = this.tab2.map(col => col.key);
  ma12Nd: any;
  AccessRole:any;
  constructor(private route: ActivatedRoute, private dbservice: DashboardService, private userAuthService:UserAuthService,
     private dialog: MatDialog, private router: Router, private notification:NotificationService) {
    this.route.queryParams.subscribe(val => {
      this.urlData = val;
    });
  }
  goBack() {
    window.history.back();
  }
  ngOnInit() {
    let lvl = this.userAuthService.userAuth.securityLevel.split(',');
    this.AccessRole = lvl[lvl.length - 1];
    this.isDataFetched = false;
    this.fetchingReport = true;
    let obj = {
        "cntrctCustId": this.urlData.custId,
        "cntrctSrceId": this.urlData.srceId,
        "commType": this.urlData.commType,
        "commitmentAmount": this.urlData.commitmentAmount,
        "exprNd": this.urlData.exprNd,
        "groupType": this.urlData.groupType,
        "isParentView": this.urlData.isParentView,
        "isPriorMonth": this.urlData.isPriorMonth,
        "offerId": this.urlData.offrId,
        "offrActnId":this.urlData.offrActnId 
    }
    this.dbservice.getReportingTypeInfo(obj,this.urlData.slcTrackingType).subscribe(resp => {
      this.prepareTableData(resp);
      this.isDataFetched = true;
      this.fetchingReport = false;
      if(!!resp && resp?.qCommitments?.length > 0){
      this.dataSource = new MatTableDataSource(resp.qCommitments);
      if(this.urlData.slcTrackingType == 'commitment_tracking') {
        let dt = resp.qCommitments[0]['CURR_YEAR_MONTH_31'].match(/.{1,4}/g).join('/');
        let key = moment(new Date(dt+'/01')).subtract(0, 'months').format('MMMM');
        this.tab1.splice(6,0,{ key: "CURR_ATTAINMENT_AMOUNT", label: key });
        this.dc1 = this.tab1.map(col => col.key);
      }
      } else {
      this.dataSource = new MatTableDataSource([]);
      }
    }, error => {
      this.isDataFetched = true;
      this.fetchingReport = false;
      this.notification.showErrorNotification(error);
    });
    let ma12Obj = {
      custId: this.urlData.custId,
      offerId: this.urlData.offrId,
      srceId: this.urlData.srceId
    }
    this.getMa12(ma12Obj);
  }
  getMa12(obj: any) {
    this.dbservice.getMa12(obj).subscribe(resp => {
      if(!!resp){
      this.ma12Nd = resp;
      }
    },error => {
      this.notification.showErrorNotification(error);
    });
  }
  prepareTableData(obj) {
    if(!!obj && obj?.qMaxInvcDt[0]?.BILLCYCLETEXT){
    let dt  = obj['qMaxInvcDt'][0]['BILLCYCLETEXT'].match(/.{1,4}/g).join('-');
    this.invoiceDt = dt.match(/.{1,7}/g).join('-');
    }
    this.tableData = [
      { key: "Customer Name", value: this.urlData.custNm },
      { key: "Offer ID", value: this.urlData.offrId },
      { key: "Customer ID", value: this.urlData.custId },
      { key: "Offer Effective Date", value: this.urlData.offrEffDt },
      { key: "Contract Source", value: obj?.qSrceTxt[0]?.SRCE_TX ? obj['qSrceTxt'][0]['SRCE_TX'] : '' },
      { key: "Invoice Date", value: this.invoiceDt },
      { key: "Contract Period", value: this.urlData.startContractPeriod + ' to ' + this.urlData.endContractPeriod },
      { key: "Report Generation Date", value: moment(new Date()).format("YYYY-MM-DD") },
      { key: "MA12 Indicator", value: this.ma12Nd },
      { key: "", value: "" }
    ];
    
  };
  getDropDown(ele: any, key: any) {
    let dropDownData: any;
    let choice: any;
    if (this.urlData.slcTrackingType == 'informational_tracking') {
      dropDownData = [
        { value: 'informational_group_trending', label: 'Group Trending' }
      ];
      choice = key == 'CURR_RVNU' ? 'rvn' : key == 'CURR_USG_MI_ET' ? 'min' : 'msg';
    } else if(this.urlData.slcTrackingType == 'prior_period_summary_tracking') {
      if(['1','3','7','8','9'].indexOf(this.AccessRole) != -1) {
      dropDownData = [
        { value: 'prior_period_group_trending', label: 'Prior Period Group Trending' },
        { value: 'prior_period_cbl_trending', label: 'Prior Period CBL Trending' },
        { value: 'prior_period_account_component_cross_reference_tracking', label: 'Prior Period Account/Component Cross Reference Tracking' },
        { value: 'prior_period_account_component_cross_reference_trending', label: 'Prior Period Account/Component Cross Reference Trending' }
      ];
    } else if(['2','4','6'].indexOf(this.AccessRole) != -1) {
      dropDownData = [
        { value: 'prior_period_group_trending', label: 'Prior Period Group Trending' },
        { value: 'prior_period_account_component_cross_reference_tracking', label: 'Prior Period Account/Component Cross Reference Tracking' },
        { value: 'prior_period_account_component_cross_reference_trending', label: 'Prior Period Account/Component Cross Reference Trending' }
      ];
    }
      choice = '';
    }
    else if(this.urlData.slcTrackingType == 'commitment_tracking') {
      if(['1','3','7','8','9'].indexOf(this.AccessRole) != -1) {
      dropDownData = [
        { value: 'group_tracking', label: 'Revenue Tracking' },
        { value: 'group_trending', label: 'Revenue by Month' },
        { value: 'acct_comp_cross_ref_tracking', label: 'Revenue with Product and Account #s' },
        { value: 'acct_comp_cross_ref_trending', label: 'Revenue with Product, Account # by month' },
        { value: 'cbl_rpt', label: 'CBL Report' },
      ];
    } else if(['2','4','5','6'].indexOf(this.AccessRole) != -1) {
      dropDownData = [
        { value: 'group_tracking', label: 'Revenue Tracking' },
        { value: 'group_trending', label: 'Revenue by Month' },
        { value: 'acct_comp_cross_ref_tracking', label: 'Revenue with Product and Account #s' },
        { value: 'acct_comp_cross_ref_trending', label: 'Revenue with Product, Account # by month' }
      ];
    }
      choice = '';
    }
    const dialogRef = this.dialog.open(ModalDropdownComponent, {
      data: {
        title: 'Please select the type of report you would like to drill into :',
        data: dropDownData
      }
    });

    dialogRef.afterClosed().subscribe(val => {
      if (val) {
        let msgrDis = choice == 'rvn' ? (['Y','N'].includes(ele['TRK_RVNU_TYPE_CD']) ? 'PRE-DISCOUNT' : ['A'].includes(ele['TRK_RVNU_TYPE_CD']) ? 'POST-DISCOUNT': '')  + ' Revenue' : choice == 'msg' ? 'Messages' : choice == 'min'? 'Minutes' : "";
        let obj = {
          "custNm": this.urlData.custNm,
          "contSrc": this.urlData.CNTRCT_SRCE_TX,
          "actnId": ele.ACTN_ID,
          "annivDt": ele.ANNIV_DT ?? "",
          "custId": this.urlData.custId,
          "expiryNd": this.urlData.exprNd,
          "exprNd": this.urlData.exprNd,
          "gpTypeNd": this.urlData.gpTypeNd,
          "groupType":ele.ATTN_DSPL_CD,
          "igChoice": choice,
          "offrActnId": ele.OFFR_ACTN_ID,
          "offrEffDt": this.urlData.offrEffDt,
          "offrId": this.urlData.offrId,
          "slcTrackingType": val.data.value,
          "srceId": this.urlData.srceId,
          "ma12Nd": this.ma12Nd,
          "startContractPeriod": this.urlData.startContractPeriod,
          "endContractPeriod": this.urlData.endContractPeriod,
          "contSrcTx": this.urlData.contSrcTx,
          "invoiceDt": this.invoiceDt,
          "commitReq": ele.ACTN_DESC_TX,
          "msgrDis": msgrDis,
          "isParentView": this.urlData.isParentView,
          "measurement": ['Y','N'].includes(ele['TRK_RVNU_TYPE_CD']) ? 'PRE-DISCOUNT' : ['A'].includes(ele['TRK_RVNU_TYPE_CD']) ? 'POST-DISCOUNT': '',
          "previousSlcTrackingType": this.urlData.slcTrackingType,
          "cntAdminDt": ele.CNTRCT_ADMIN_DT,
          "pgName":val.data.label
        }
        this.router.navigate(['/dashboard', 'commitment-group'], { queryParams: obj });
      }
    });
  };
  cprsDownload() {
    let headerData = [], headerobj = {}, headertitles = {};
    this.tableData.forEach((td, index) => {
      if (td.key != "") {
        headerobj[td.key] = td.value;
        headertitles[td.key] = {
          "sequenceNm": index,
          "titleName": td.key
        }
      }
    });
    let bodytitles = {}, bodyData = [], tabData: any;
    tabData = this.urlData.slcTrackingType == 'informational_tracking' ? this.tab2 : this.tab1;
    headerData.push(headerobj);
    this.dataSource.data.forEach(data => {
      let bodyObj = {};
      tabData.forEach((ele, index) => {
        if (ele.key != "") {
          bodyObj[ele.key] = data[ele.key];
          bodytitles[ele.key] = {
            "sequenceNm": index,
            "titleName": ele.label
          }
        }
      });
      bodyData.push(bodyObj);
    });
    let download = {
      "bodySection": {
        "inputValues": bodyData,
        "titles": bodytitles
      },
      "headerSection": {
        "inputValues": headerData,
        "titles": headertitles
      },
      "sheetName": (this.urlData.pgName).replace(/[^a-zA-Z0-9]/g, "")

    }
    this.fetchingReport = true;
    this.dbservice.cprsDownload(download).subscribe(resp => {
      this.fetchingReport = false;
      if (!!resp) {
        FileSaver.saveAs(resp, 'Commitment' + (this.urlData.pgName).replace(/[^a-zA-Z0-9]/g, "") + '.xlsx');
      }
    }, error => {
      this.fetchingReport = false;
      this.notification.showErrorNotification(error);
    })
  }
  print() {
    const printContent = document.getElementById('print-section');
    const windowPrt = window.open('', '', 'left=0,top=0,width=900,height=900,toolbar=0.scrollbars=0,status=0');
    windowPrt.document.write(printContent.innerHTML);
    windowPrt.document.write('<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500&display=swap" rel="stylesheet">');
    windowPrt.document.write('<link href="https://fonts.googleapis.com/icon?family=Material+Icons|Material+Icons+Round|Material+Icons+Outlined" rel="stylesheet">');
    windowPrt.document.write('<link rel="stylesheet" type="text/css" href="/assets/styles/custom-theme.scss" />');
    windowPrt.document.write('<link rel="stylesheet" type="text/css" href="/assets/styles/variables.scss" />');
    windowPrt.document.write('<link rel="stylesheet" type="text/css" href="/assets/styles/custom-material-style.scss" />');
    windowPrt.document.write('<link rel="stylesheet" type="text/css" href="/assets/styles/customer-summary-print.scss" />');
  }
}
