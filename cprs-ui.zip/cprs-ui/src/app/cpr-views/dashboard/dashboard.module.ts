import { NgModule } from '@angular/core';
import { CommonModule, CurrencyPipe } from '@angular/common';
import { DashboardRoutingModule } from './dashboard-routing.module';
import { AppCommonModule } from 'src/app/common/app-common.module';
import { SharedModule } from 'src/app/shared/root-material/shared.module';
import { FlexLayoutModule } from '@angular/flex-layout';
import { SearchComponent } from './search/search.component';
import { SvidTableResultComponent } from './search/svid-table-result/svid-table-result.component';
import { SvidExpendResultComponent } from './search/svid-expend-result/svid-expend-result.component';
//import { SvidEnterpriceServiceMappingComponent } from '../svid-enterprice-service-mapping/svid-enterprice-service-mapping.component';
import { NgApexchartsModule } from "ng-apexcharts";

import { SearchResultComponent } from './search-result/search-result.component';
import { CommitmentTrackingComponent } from './commitment-tracking/commitment-tracking.component';
import { CommitmentTrackingGroupComponent } from './commitment-tracking-group/commitment-tracking-group.component';
import { ComponentGroupComponent } from './component-group/component-group.component';
import { AeSummaryDashboardComponent } from './search/ae-summary-dashboard/ae-summary-dashboard.component';
import { CprViewsModule } from '../cpr-views.module';
import { PriorMonthComponent } from './prior-month/prior-month.component';
import { ChildTrackingComponent } from './child-tracking/child-tracking.component';
import { ComponentGroupAdminComponent } from './component-group-admin/component-group-admin.component';
import { GroupInputPopupComponent } from './component-group-admin/group-input-popup/group-input-popup.component';

@NgModule({
  declarations: [SearchComponent, SvidTableResultComponent, SvidExpendResultComponent, AeSummaryDashboardComponent,SearchComponent, SvidTableResultComponent, SvidExpendResultComponent, SearchResultComponent, CommitmentTrackingComponent, CommitmentTrackingGroupComponent, ComponentGroupComponent, PriorMonthComponent, ChildTrackingComponent, ComponentGroupAdminComponent,GroupInputPopupComponent],
  imports: [
    CommonModule,
    DashboardRoutingModule,
    SharedModule,
    FlexLayoutModule,
    AppCommonModule,
    NgApexchartsModule,
    CprViewsModule
  ],
  providers: [CurrencyPipe]
})
export class DashboardModule { }
