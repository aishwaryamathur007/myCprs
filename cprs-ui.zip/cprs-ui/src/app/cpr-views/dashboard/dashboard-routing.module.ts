import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from 'src/app/shared/guards/auth.guard';
import { CommitmentTrackingGroupComponent } from './commitment-tracking-group/commitment-tracking-group.component';
import { CommitmentTrackingComponent } from './commitment-tracking/commitment-tracking.component';
import { SearchResultComponent } from './search-result/search-result.component';
import { SearchComponent } from './search/search.component';
import { SvidTableResultComponent } from './search/svid-table-result/svid-table-result.component';
import { AeSummaryDashboardComponent } from './search/ae-summary-dashboard/ae-summary-dashboard.component';
import { SvidEnterpriceServiceMappingComponent } from '../svid-enterprice-service-mapping/svid-enterprice-service-mapping.component';
import { ComponentGroupComponent } from './component-group/component-group.component';
import { ChildTrackingComponent } from './child-tracking/child-tracking.component';

const routes: Routes = [
  {
    path: '', redirectTo: 'search', pathMatch: 'full'
  }, {
    path: 'search', component: SearchComponent
  },{
    path: 'search-result', component: SearchResultComponent
  },{
    path: 'commitment-tracking', component: CommitmentTrackingComponent
  },{
    path: 'commitment-group', component: CommitmentTrackingGroupComponent
  },{
    path: 'component-group', component: ComponentGroupComponent
  },{
    path:'child-tracking', component: ChildTrackingComponent
  },{
    path: 'search/svid-result', component: SvidTableResultComponent, canActivate: [AuthGuard]
  },{
    path: 'search/svid-enterprise-service-mapping', component: SvidEnterpriceServiceMappingComponent, canActivate: [AuthGuard],
  },{
    path: 'search/ae-summary-dashboard', component: AeSummaryDashboardComponent, canActivate: [AuthGuard]
  },{
    path: '**', redirectTo: 'dashboard'
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DashboardRoutingModule { }
