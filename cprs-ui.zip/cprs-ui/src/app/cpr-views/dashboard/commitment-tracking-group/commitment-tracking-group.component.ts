import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
import * as  FileSaver from 'file-saver';
import { ModalDropdownComponent } from 'src/app/common/component/modal-dropdown/modal-dropdown.component';
import { DashboardService } from '../../service/dashboard.service';
import { MailAttachementComponent } from 'src/app/common/component/mail-attachement/mail-attachement.component';
import { NotificationService } from 'src/app/common/services/notification.service';

@Component({
  selector: 'commitment-tracking-group',
  templateUrl: './commitment-tracking-group.component.html',
  styleUrls: ['./commitment-tracking-group.component.scss']
})
export class CommitmentTrackingGroupComponent implements OnInit {
  dataSource: MatTableDataSource<any>;
  isDataFetched: boolean = false;
  fetchingReport: boolean = false;
  urlData: any = {};
  tableData: any = [];
  msgrDis: any;
  tab1 = [];
  dc1: string[];
  constructor(private route: ActivatedRoute, private dbservice: DashboardService, private dialog: MatDialog,
     private router: Router,private notifService:NotificationService) {
    this.route.queryParams.subscribe(val => {
      this.urlData = val;
    });
  }
  goBack() {
    window.history.back();
  }
  ngOnInit() {
    this.isDataFetched = false;
    this.fetchingReport = true;
    let obj = {
      "actnId": this.urlData.actnId,
      "annivDt": this.urlData.annivDt.trim(),
      "custId": this.urlData.custId,
      "expiryNd": this.urlData.expiryNd,
      "exprNd": this.urlData.exprNd,
      "gpTypeNd": this.urlData.gpTypeNd,
      "groupType": this.urlData.groupType,
      "igChoice": this.urlData.igChoice,
      "offrActnId": this.urlData.offrActnId,
      "offrEffDt": this.urlData.offrEffDt,
      "offrId": this.urlData.offrId,
      "slcTrackingType": this.urlData.slcTrackingType,
      "srceId": this.urlData.srceId,
      "isOuterLayer": true,
      "isParentView": this.urlData.isParentView,
      "isPriorMonth": this.urlData.isPriorMonth
    }
    this.dbservice.commitmentRequirement(obj).subscribe(resp => {
      this.prepareTableData(resp);
      if (!!resp && resp?.qCommitments?.length > 0) {
        if (!this.urlData.igChoice) {
          this.tableData = this.tableData.map(x => {
            if (x.key == 'Measurement Displayed') {
              return { key: x.key, value: resp.qCommitments[0].ATTN_CAT_CD };
            } else {
              return x
            };
          });
        }
        if (this.urlData.slcTrackingType == 'prior_period_group_trending' || this.urlData.slcTrackingType == 'group_trending' || this.urlData.slcTrackingType == 'prior_period_account_component_cross_reference_trending' || this.urlData.slcTrackingType == 'informational_group_trending' || this.urlData.slcTrackingType == 'acct_comp_cross_ref_trending') {
          this.tab1 = this.tab1.concat(this.getTableLabel(resp.qCommitments[0].ANNIVERSARY_YEAR, resp.qCommitments[0].ANNIVERSARY_MONTH, resp.qCommitments[0].OFFR_DUR + resp.qCommitments[0].ANNIVERSARY_MONTH - 1));
          this.dc1 = this.tab1.map(col => col.key);
          const updatedarry = this.RenameallKeys(resp.qCommitments, this.dc1);
          this.dataSource = new MatTableDataSource(updatedarry);
        } else {
          this.dataSource = new MatTableDataSource(resp.qCommitments || resp.groupTracking);
        }
        this.isDataFetched = true;
        this.fetchingReport = false;
      } else {
        this.dataSource = new MatTableDataSource([]);
        this.isDataFetched = true;
        this.fetchingReport = false;
      }
    }, error => {
      this.isDataFetched = true;
      this.fetchingReport = false;
      this.notifService.showErrorNotification(error);
    });
    if (this.urlData.slcTrackingType == "prior_period_account_component_cross_reference_tracking" || this.urlData.slcTrackingType == "acct_comp_cross_ref_tracking") {
      this.tab1.push({ key: "SUB_GP_DESC_TX", label: "Component" });
      this.tab1.push({ key: "BL_ACCT_ID", label: "Account" });
      this.tab1.push({ key: "ATTAINMENT_AMOUNT", label: "Attainment Amount" });
      this.tableData.push({ key: "Measurement Displayed", value: this.msgrDis });
      this.tableData.push({ key: "", value: "" });
    } else if (this.urlData.slcTrackingType == 'prior_period_cbl_trending' || this.urlData.slcTrackingType == 'cbl_rpt') {

    } else if (this.urlData.slcTrackingType == 'prior_period_group_trending') {
      this.tab1.push({ key: "GP_NM", label: this.urlData.gpTypeNd == 'C' ? "Prior Period Component Group" : "Prior Period Account Group" });
    } else if (this.urlData.slcTrackingType == 'prior_period_account_component_cross_reference_trending' || this.urlData.slcTrackingType == "acct_comp_cross_ref_trending") {
      this.tab1.push({ key: "SUB_GP_DESC_TX", label: this.urlData.gpTypeNd == 'C' ? "Component" : "Account" });
      this.tab1.push({ key: "BL_ACCT_ID", label: "Account" });
      this.tableData.push({ key: "Measurement Displayed", value: this.msgrDis });
      this.tableData.push({ key: "", value: "" });
    } else if (this.urlData.slcTrackingType == 'informational_group_trending' || this.urlData.slcTrackingType == 'group_trending') {
      this.tab1.push({ key: "GP_NM", label: this.urlData.gpTypeNd == 'C' ? "Component Group" : "Account Group" });
      this.tableData.push({ key: "Measurement Displayed", value: this.urlData.msgrDis });
      this.tableData.push({ key: "", value: "" });
    } else if (this.urlData.slcTrackingType == 'group_tracking') {
      this.tab1.push({ key: "GP_NM", label: "Component Group" });
      this.tab1.push({ key: "ATTAINMENT_AMOUNT", label: "Attainment Amount" });
      this.tableData.push({ key: "Measurement Displayed", value: this.urlData.msgrDis });
      this.tableData.push({ key: "", value: "" });
    };
    this.dc1 = this.tab1.map(col => col.key);

  }
  RenameallKeys = (emparr, replaceKeys) => {
    const ele = [];
    emparr.map(emp => {
      const renameObj = {};
      Object.keys(emp).forEach((key, i) => {
        if ((key.includes('MONTH') && !key.includes('ANNIVERSARY_MONTH')) || key.includes('GP_NM') || key.includes('BL_ACCT_ID') || key.includes('SUB_GP_DESC_TX') || key.includes('ATTAINMENT_AMOUNT')) {
          for (let j = 0; j < replaceKeys.length; j++) {
            if (Object.keys(renameObj).indexOf(replaceKeys[j]) == -1) {
              renameObj[replaceKeys[j]] = emp[key];
              break;
            }
          }
        }
      });
      renameObj['ATTN_CAT_CD'] = emp['ATTN_CAT_CD'];
      renameObj['ATTN_DSPL_CD'] = emp['ATTN_DSPL_CD'];
      renameObj['GP_ID'] = emp['GP_ID'];
      ele.push(renameObj);
    });
    return ele;
  };
  getTableLabel(year, month, duration) {
    const months = Array.from({ length: parseInt(duration) }, (item, i) => {
      if (i >= (parseInt(month) - 1)) {
        return { key: new Date(parseInt(year), i).toLocaleString('en-US', { month: 'long', year: 'numeric' }), label: new Date(parseInt(year), i).toLocaleString('en-US', { month: 'long', year: 'numeric' }) };
      }
    });
    const results = months.filter(element => { return element !== undefined; });
    return results;
  }
  prepareTableData(obj: any) {
    let columnData = [
      { key: "Customer Name", value: this.urlData.custNm },
      { key: "Offer ID", value: this.urlData.offrId },
      { key: "Customer ID", value: this.urlData.custId },
      { key: "Offer Effective Date", value: this.urlData.offrEffDt },
      { key: "Contract Source", value: this.urlData.contSrcTx },
      { key: "Invoice Date", value: this.urlData.invoiceDt },
      { key: "Contract Period", value: this.urlData.startContractPeriod + " to " + this.urlData.endContractPeriod },
      { key: "Report Generation Date", value: moment(new Date()).format("YYYY-MM-DD") },
      { key: 'Commitment Requirement', value: this.urlData.commitReq },
      { key: 'Offer Action ID', value: this.urlData.offrActnId },
      { key: "MA12 Indicator", value: this.urlData.ma12Nd },
      { key: "Contract Admin Date", value: this.urlData.cntAdminDt }
    ];
    this.tableData = columnData.concat(this.tableData);
  };
  getDropDown(custDetails: any) {
    let dropDownData: any;
    if (this.urlData.previousSlcTrackingType == 'informational_tracking') {
      if (this.urlData.gpTypeNd == 'C') {
        if (this.urlData.igChoice == 'rvn') {
          dropDownData = [{ value: 'component_group_trending', label: 'Component Group Revenue Trending' }];
        }
        if (this.urlData.igChoice == 'msg') {
          dropDownData = [{ value: 'component_group_trending', label: 'Component Group Messages Trending' }];
        }
        if (this.urlData.igChoice == 'min') {
          dropDownData = [{ value: 'component_group_trending', label: 'Component Group Minutes Trending' }];
        }
      } else {
        if (this.urlData.igChoice == 'rvn') {
          dropDownData = [{ value: 'account_group_trending', label: 'Account Group Revenue Trending' }];
        }
        if (this.urlData.igChoice == 'msg') {
          dropDownData = [{ value: 'account_group_trending', label: 'Account Group Messages Trending' }];
        }
        if (this.urlData.igChoice == 'min') {
          dropDownData = [{ value: 'account_group_trending', label: 'Account Group Minutes Trending' }];
        }
      }
    } else if (this.urlData.previousSlcTrackingType == 'prior_period_summary_tracking') {
      if (this.urlData.gpTypeNd == 'C') {
        dropDownData = [
          { value: 'prior_period_component_trending', label: 'Prior Period Component Trending' }
        ];
      } else {
        dropDownData = [
          { value: 'prior_period_account_trending', label: 'Prior Period Account Trending' }
        ];
      }
    } else if (this.urlData.slcTrackingType == 'group_tracking') {
      if (this.urlData.gpTypeNd == 'C') {
        dropDownData = [
          { value: 'group_tracking', label: 'Component Tracking' }
        ];
      } else {
        dropDownData = [
          { value: 'group_tracking', label: 'Account Tracking' }
        ];
      }
    } else if (this.urlData.slcTrackingType == 'group_trending') {
      if (this.urlData.gpTypeNd == 'C') {
        dropDownData = [
          { value: 'group_trending', label: 'Component Trending' }
        ];
      } else {
        dropDownData = [
          { value: 'group_trending', label: 'Account Trending' }
        ];
      }
    }
    const dialogRef = this.dialog.open(ModalDropdownComponent, {
      data: {
        title: 'Please select the type of report you would like to drill into :',
        data: dropDownData
      }
    });

    dialogRef.afterClosed().subscribe(val => {
      if (val) {
        console.log(val);
        let obj = {
          "custNm": this.urlData.custNm,
          "contSrc": this.urlData.contSrc,
          "actnId": this.urlData.actnId,
          "annivDt": this.urlData.annivDt,
          "custId": this.urlData.custId,
          "expiryNd": this.urlData.exprNd,
          "exprNd": this.urlData.exprNd,
          "gpTypeNd": this.urlData.gpTypeNd,
          "groupType": this.urlData.groupType,
          "igChoice": this.urlData.igChoice,
          "offrActnId": this.urlData.offrActnId,
          "offrEffDt": this.urlData.offrEffDt,
          "offrId": this.urlData.offrId,
          "slcTrackingType": val.data.value,
          "srceId": this.urlData.srceId,
          "ma12Nd": this.urlData.ma12Nd,
          "startContractPeriod": this.urlData.startContractPeriod,
          "endContractPeriod": this.urlData.endContractPeriod,
          "contSrcTx": this.urlData.contSrcTx,
          "invoiceDt": this.urlData.invoiceDt,
          "commitReq": this.urlData.commitReq,
          "previousSlcTrackingType": this.urlData.slcTrackingType,
          "currentSlcTrackingType": this.urlData.slcTrackingType,
          "msgrDis": this.urlData.msgrDis,
          "cntAdminDt": this.urlData.cntAdminDt,
          "pgName": val.data.label,
          "gpId": custDetails.GP_ID,
          "gpNm": custDetails.GP_NM,
          "isParentView": this.urlData.isParentView
        };
        console.log(custDetails);
        this.router.navigate(['/dashboard', 'component-group'], { queryParams: obj });
      }
    });
  };
  cprsDownload() {
    let headerData = [], headerobj = {}, headertitles = {};
    this.tableData.forEach((td, index) => {
      if (td.key != "") {
        headerobj[td.key] = td.value;
        headertitles[td.key] = {
          "sequenceNm": index,
          "titleName": td.key
        }
      }
    });
    let bodytitles = {}, bodyData = [];
    headerData.push(headerobj);
    this.dataSource.data.forEach(data => {
      let bodyObj = {};
      this.tab1.forEach((ele, index) => {
        if (ele.key != "") {
          bodyObj[ele.key] = data[ele.key];
          bodytitles[ele.key] = {
            "sequenceNm": index,
            "titleName": ele.label
          }
        }
      });
      bodyData.push(bodyObj);
    });
    let download = {
      "bodySection": {
        "inputValues": bodyData,
        "titles": bodytitles
      },
      "headerSection": {
        "inputValues": headerData,
        "titles": headertitles
      },
      "sheetName": (this.urlData.pgName).replace(/[^a-zA-Z0-9]/g, "")

    }
    this.fetchingReport = true;
    this.dbservice.cprsDownload(download).subscribe(resp => {
      this.fetchingReport = false;
      if (!!resp) {
        FileSaver.saveAs(resp, 'Commitment' + (this.urlData.pgName).replace(/[^a-zA-Z0-9]/g, "") + '.xlsx');
      }
    }, error => {
      this.fetchingReport = false;
      this.notifService.showErrorNotification(error);
    })
  }
  sendMail() {
    // const dialogRef = this.dialog.open(MailAttachementComponent, {
    //   data:{
    //     "custId": this.urlData.custId,
    //     "offrActnId": this.urlData.offrActnId,
    //     "offrEffDt": this.urlData.offrEffDt,
    //     "offrId": this.urlData.offrId,
    //     "srceId": this.urlData.srceId,
    //     "annivDt": this.urlData.annivDt.trim(),
    //     "reportType": this.urlData.slcTrackingType == 'cbl_rpt' ? 'CBL_REPORT' : 'PRIOR_PERIOD_CBL'
    //   },
    //   width: '30%',
    //    height:'90%'
    // });

    // dialogRef.afterClosed().subscribe(val => {
    //   if (val) {
    //     console.log(val);
    //   }
    // });
    let content = {
      "cntrctCustId": this.urlData.custId,
      "cntrctSrceId": this.urlData.srceId,
      "reportType": this.urlData.slcTrackingType == 'cbl_rpt' ? "CURR" : "PRIOR",
      "contractPeriod": this.urlData.startContractPeriod +' to ' + this.urlData.endContractPeriod,
      "contractSource": this.urlData.contSrcTx,
      "customerName": this.urlData.custNm,
      "invoiceDate": this.urlData.invoiceDt,
      "maIndicator": this.urlData.ma12Nd,
      "offerEffectiveDate": this.urlData.offrEffDt,
      "offerId": this.urlData.offrId,
      "commitmentReq": this.urlData.commitReq,
      "offrActnId": this.urlData.offrActnId
    };
    this.fetchingReport = true;
    this.dbservice.downloadContent(content).subscribe(resp => {
      this.fetchingReport = false;
      if (!!resp) {
        FileSaver.saveAs(resp, 'Commitment' + (this.urlData.pgName).replace(/ +/g, "") + '.xlsx');
      }
    },error => {
      this.notifService.showErrorNotification(error);
      this.fetchingReport = false;
    })
  }
  print() {
    const printContent = document.getElementById('print-section');
    const windowPrt = window.open('', '', 'left=0,top=0,width=900,height=900,toolbar=0.scrollbars=0,status=0');
    windowPrt.document.write(printContent.innerHTML);
    windowPrt.document.write('<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500&display=swap" rel="stylesheet">');
    windowPrt.document.write('<link href="https://fonts.googleapis.com/icon?family=Material+Icons|Material+Icons+Round|Material+Icons+Outlined" rel="stylesheet">');
    windowPrt.document.write('<link rel="stylesheet" type="text/css" href="/assets/styles/custom-theme.scss" />');
    windowPrt.document.write('<link rel="stylesheet" type="text/css" href="/assets/styles/variables.scss" />');
    windowPrt.document.write('<link rel="stylesheet" type="text/css" href="/assets/styles/custom-material-style.scss" />');
    windowPrt.document.write('<link rel="stylesheet" type="text/css" href="/assets/styles/customer-summary-print.scss" />');
  }
}

