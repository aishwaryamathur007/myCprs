import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CommitmentTrackingGroupComponent } from './commitment-tracking-group.component';

describe('CommitmentTrackingGroupComponent', () => {
  let component: CommitmentTrackingGroupComponent;
  let fixture: ComponentFixture<CommitmentTrackingGroupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CommitmentTrackingGroupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CommitmentTrackingGroupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
