import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserAuthService } from 'src/app/shared/service/user-auth.service';

@Component({
  selector: 'cprs-reporting',
  templateUrl: './cprs-reporting.component.html',
  styleUrls: ['./cprs-reporting.component.scss']
})
export class CprsReportingComponent implements OnInit {
  accessRole: any;
  constructor(private router: Router, private userAuthService: UserAuthService) {
    this.accessRole = this.userAuthService.userAuth.securityLevel.split(',')[0];
  }
  ngOnInit(): void {
  }

  routeToReports(reportName: string) {
    this.router.navigate(['reports', reportName]);
  }

}
