import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CprsReportingComponent } from './cprs-reporting.component';

describe('CprsReportingComponent', () => {
  let component: CprsReportingComponent;
  let fixture: ComponentFixture<CprsReportingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CprsReportingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CprsReportingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
