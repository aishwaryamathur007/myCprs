import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { BehaviorSubject } from "rxjs";

@Injectable({
  providedIn: 'root',
})
export class CustomerContractMaintenanceService {
  private customerData = new BehaviorSubject<any>([]);
  readonly customerArray = this.customerData.asObservable();

  constructor(private http: HttpClient) { }
  baseURL = environment.cprApiBaseUrl + '/cprs';

  loadAll(arr: any) {
    this.customerData.next(arr);
  }
  getCustomerData(obj: any): Observable<any> {
    return this.http.get(this.baseURL + '/customerSearch', { params: obj });
  }
  getcustomerService(serviceObj: any): Observable<any> {
    return this.http.get(this.baseURL + '/customerService', { params: serviceObj });
  }
  getActivityTypeDropdown(): Observable<any> {
    return this.http.get(this.baseURL + '/getActivityTypeDropdown');
  }
  getUnitCode(type: any): Observable<any> {
    return this.http.get(this.baseURL + '/getUnitCode?activityType=' + type.activityType + '&activityDesc=' + encodeURIComponent(type.activityDesc));
  }
  getserviceMapping(map: any): Observable<any> {
    return this.http.get(this.baseURL + '/getServiceMapping', { params: map });
  }
  getUnitCodePrePostDiscount(): Observable<any> {
    return this.http.get(this.baseURL + '/getUnitCodePrePostDiscount');
  }
  getActivityDescDropdown(desc: any): Observable<any> {
    return this.http.get(this.baseURL + '/getActivityDescDropdown', { params: desc });
  }
  getServiceDropdown(): Observable<any> {
    return this.http.get(this.baseURL + '/getServiceDropdown');
  }
  customerServiceEdit(service: any): Observable<any> {
    return this.http.post(this.baseURL + '/customerServiceEdit', service, { responseType: 'text' as 'json' });
  }
  getServiceMappingApplyToActivity(mapAct: any): Observable<any> {
    return this.http.get(this.baseURL + '/getServiceMappingApplyToActivity', { params: mapAct });
  }
  getServiceBuckets(): Observable<any> {
    return this.http.get(this.baseURL + '/getServiceBuckets');
  }
  addOrUpdateServiceMapping(mapObj: any): Observable<any> {
    return this.http.post(this.baseURL + '/copyOrEditServiceMapping', mapObj, { responseType: 'text' as 'json' });
  }
  terminateUntermService(term: any): Observable<any> {
    return this.http.post(this.baseURL + '/terminateUntermService', term);
  }
  downloadReport(obj: any): Observable<any> {
    return this.http.post(environment.commonApiBaseUrl + '/reports/downloadReport', obj, { responseType: 'blob' });
  }
  //charges
  getStatus(): Observable<any> {
    return this.http.get(environment.cprApiBaseUrl + '/charges/getStatus');
  };
  getCharges(charges: any): Observable<any> {
    return this.http.post(environment.cprApiBaseUrl + '/charges/getCharges', charges);
  };
  getAdjustmentReason(): Observable<any> {
    return this.http.get(environment.cprApiBaseUrl + '/charges/getAdjustmentReason');
  };
  getAdjustmentData(adjData: any): Observable<any> {
    return this.http.get(environment.cprApiBaseUrl + '/charges/getAdjustmentData', { params: adjData });
  };
  updateCharges(charges:any): Observable<any> {
    return this.http.post(environment.cprApiBaseUrl + '/charges/updateCharges', charges, { responseType: 'text' as 'json' });
  };
  addDeleteAdjustments(obj:any): Observable<any> {
    return this.http.post(environment.cprApiBaseUrl + '/charges/addDeleteAdjustments', obj, { responseType: 'text' as 'json' });
  };
}
