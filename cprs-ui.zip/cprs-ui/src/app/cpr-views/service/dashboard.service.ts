import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class DashboardService {
  constructor(private http: HttpClient) {}
  baseURL = environment.cprApiBaseUrl + '/reporting';

  getCustomerDetails(obj: any): Observable<any> {
    return this.http.post(this.baseURL + '/getCustomerDetails', obj );
  }
  getReportingTypeInfo(obj:any,trackingType:any): Observable<any> {
    return this.http.post(this.baseURL + '/getReportingTypeInfo',obj, { params: {slcTrackingType:trackingType} });
  }
  commitmentRequirement(obj:any): Observable<any> {
    return this.http.post(environment.cprApiBaseUrl + '/commitmentTracking' + '/commitmentRequirement', obj);
  }
  getDataComponentTrading(obj:any): Observable<any> {
    return this.http.post(environment.cprApiBaseUrl + '/commitmentTracking' + '/getDataComponentTrading', obj);
  }
  getReportTypeChildTracking(obj:any): Observable<any> {
    return this.http.post(this.baseURL + '/getReportTypeChildTracking', obj);
  }
  getMa12(obj:any): Observable<any> {
    return this.http.get(this.baseURL + '/getMa12', { params: obj });
  };
  childTrackingDownload(download:any) : Observable<any> {
    return this.http.post(this.baseURL + '/childTrackingDownload', download, {responseType: 'blob'});
  };
  cprsDownload(download:any) : Observable<any> {
    return this.http.post(this.baseURL + '/cprsDownload', download, {responseType: 'blob'});
  };

  //component group
  getGroupResultList(obj:any) : Observable<any> {
    return this.http.post(this.baseURL +'/getGroupResultList', obj);
  };
  addEditCompGroup(obj:any) : Observable<any> {
    return this.http.post(this.baseURL +'/addEditCompGroup', obj);
  };
  getSubmitAllChanges(obj:any) : Observable<any> {
    return this.http.post(this.baseURL +'/getSubmitAllChanges', obj);
  };

  //email 
  emailOptions(obj:any,reportType) : Observable<any> {
    return this.http.post(this.baseURL +'/emailOptions', obj ,{params:{reportType:reportType}});
  };
  downloadContent(obj:any) : Observable<any> {
    return this.http.post(environment.cprApiBaseUrl +'/commitmentTracking/cblDownload', obj , {responseType: 'blob'});
  };
}
