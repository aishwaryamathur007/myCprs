import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
//import { AnyMxRecord } from 'dns';
import { Observable, of } from 'rxjs';
import { environment } from 'src/environments/environment';
import { AssignDetails, SearchAssignDetails } from '../contract-assignment/administration-assignment/administration-assignment.component';

@Injectable({
  providedIn: 'root',
})
export class ReportsDataService {
  constructor(private http: HttpClient) {}
  getProfileManagementData(): Observable<any> {
    // return this.http.get(environment.dolarsApiBaseUrl + '/search/getSBSBundlePrintRptOptions');
    return this.http.get('assets/json/report-details.json');
  }
  getContractData(payload: any): Observable<any> {
    return this.http.post(environment.cprApiBaseUrl + '/cntrctAssignment/getSearchData', payload);
  }

  getAssignDetails(userID): Observable<AssignDetails[]> {
    const params = {
      userID : userID
    };
    return this.http.get<AssignDetails[]>(environment.cprApiBaseUrl + '/cntrctAssignment/getAssignDetails', { params: params });
  }

  addAssignDetails(payload: any[]): Observable<any> {
    if (payload.length > 0) {
      const URL =
        environment.cprApiBaseUrl + '/cntrctAssignment/addAdminAssignment';
      return this.http.post<any>(URL, payload);
    } else {
      return of({});
    }
  }

  deleteAssignDetails(userID, assignment: AssignDetails): Observable<any> {
    const URL = environment.cprApiBaseUrl + `/cntrctAssignment/deleteMapping?cntrctCustId =${assignment.CNTRCT_CUST_ID}&cntrctId=${userID}&srcId=${assignment.CNTRCT_SRCE_ID}`;
    return this.http.delete<any>(URL);
  }

  // 	New UB Service for Standalone Commitment
  getStandaloneCommitmentData(): Observable<any> {
    return this.http.get(
      environment.cprApiBaseUrl + '/newUbService/getTableData'
    );
  }
  getContractLevelsData(): Observable<any> {
    return this.http.get(
      environment.cprApiBaseUrl + '/newUbService/getContractLevels'
    );
  }
  getContractTypeData(): Observable<any> {
    return this.http.get(
      environment.cprApiBaseUrl + '/newUbService/getContractTypes'
    );
  }
  getPrimaryBucketsData(): Observable<any> {
    return this.http.get(
    environment.cprApiBaseUrl + '/newUbService/getPrimaryBucket'
    );
  }
  addRecord(obj): Observable<any> {
    return this.http.post(environment.cprApiBaseUrl + '/newUbService/submit', obj,
{ responseType: 'text' as 'json' }
    );
  }

  // 	Contract Error WorkList
  getAssignSearchData(params): Observable<SearchAssignDetails[]> {
    return this.http.post<SearchAssignDetails[]>(
      environment.cprApiBaseUrl + '/cntrctAssignment/getAddAdminSearchData', params
    );
  }

  getContractErrorWorklistData(): Observable<any> {
    return this.http.get(
      environment.cprApiBaseUrl + '/cntrctErrWrkList/getTableData'
    );
  }
  getContractErrorData(errorId: any): Observable<any> {
    return this.http.get(
      environment.cprApiBaseUrl + '/cntrctErrWrkList/getErrorDetail',
      { params: errorId }
    );
  }
  deleteApplication(obj): Observable<any> {
    console.log('in service');

    return this.http.post(
      environment.cprApiBaseUrl + '/cntrctErrWrkList/updateTableData',
      obj,
      { responseType: 'text' as 'json' }
    );
  }

  getServiceMappingReviewApproval(): Observable<any> {
    return this.http.get<any>(
      environment.cprApiBaseUrl + '/cprs/getServiceMappingReviewApproval'
    );
  }
}
