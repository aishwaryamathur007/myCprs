import { TestBed } from '@angular/core/testing';

import { CpidSearchService } from './cpid-search.service';

describe('CpidSearchService', () => {
  let service: CpidSearchService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CpidSearchService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
