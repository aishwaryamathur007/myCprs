import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
   providedIn: 'root'
})
export class SvidEnterpriseService {

   constructor(private http: HttpClient) { }

   getSvidEnterpriseCustomerData(obj: any): Observable<any> {
      return this.http.get(environment.cprApiBaseUrl + '/svidEnterprise/getCustomerSearch', { params: obj });
   }
   getSvidEnterpriseResultData(obj: any): Observable<any> {
      return this.http.post(environment.cprApiBaseUrl + '/svidEnterprise/getPotentialService', obj);
   }
   getServiceMappingRequestStatusData(obj: any): Observable<any> {
     return this.http.get(environment.cprApiBaseUrl + '/reporting/checkMappingRequest', { params: obj });
   }
   // downloadSvidEnterpriseResultData(obj: any): Observable<any> {
   //    return this.http.post(environment.commonApiBaseUrl + '/reports/downloadReport', obj,
   //       {
   //          responseType: 'blob'
   //       });
   // }
   downloadSvidEnterpriseResultData(obj: any): Observable<any> {
      return this.http.post(environment.cprApiBaseUrl + '/svidEnterprise/downloadReport', obj,
         {
            responseType: 'blob'
         });
   }

   getSvidIncludeRemoveList (obj: any): Observable<any> {
      return this.http.post(environment.cprApiBaseUrl + '/svidEnterprise/submitPotentialAccount', obj);
   }
}
