import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class PscContractService {
  environmentDetails = environment;

  constructor(private http: HttpClient) { }

  retrieveData(obj?): Observable<any> {
    return this.http.post(environment.cprApiBaseUrl + '/pscCntctSvcMap/retrieveRecords', obj);
  }

  deleteAssignDetails(assignment: any): Observable<any> {
    return this.http.delete(environment.cprApiBaseUrl + '/pscCntctSvcMap/deleteServiceMapping', { params: assignment, responseType: 'text' as 'json' })
  }

  newServiceMapping(obj?): Observable<any> {
    return this.http.post(environment.cprApiBaseUrl + '/pscCntctSvcMap/addNewServiceMapping', obj);
  }

  saveDetails(details: any): Observable<any> {
    return this.http.post(environment.cprApiBaseUrl + '/pscCntctSvcMap/updateServiceMapping', details, { responseType: 'text' as 'json' });
  }

  updateNameDesc(update: any): Observable<any> {
    console.log("update", update);
    return this.http.post(environment.cprApiBaseUrl + '/pscCntctSvcMap/updateNameDescription', update);
  }


}


