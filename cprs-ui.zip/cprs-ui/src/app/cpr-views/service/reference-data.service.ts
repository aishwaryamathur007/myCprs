import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})
export class ReferenceDataService {

  constructor(private http: HttpClient) { }

  getReferenceTableData(option): Observable<any> {
    return this.http.get(environment.cprApiBaseUrl + '/referenceDataMaintenance/getReferenceData', {
      params: {
        referenceType: option
      }
    });
  }

  getDropdownDetails(): Observable<any> {
    return this.http.get(environment.cprApiBaseUrl + '/referenceDataMaintenance/getActivityTypeOptions'
    );
  }

  sendData(data: any, option): Observable<any> {
    return this.http.post(environment.cprApiBaseUrl + '/referenceDataMaintenance/referenceDataOperation', data, {
      params: {
        referenceType: option
      }
    });
  }
}
