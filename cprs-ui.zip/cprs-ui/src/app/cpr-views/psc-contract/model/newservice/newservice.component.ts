import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { NotificationService } from 'src/app/common/services/notification.service';
import { PscContractService } from 'src/app/cpr-views/service/psc-contract.service';
import { UserService } from 'src/app/shared/service/user.service';

export interface PeriodicElement {

  cntrctSvcSeqNo: string,
  prdctSvcCode: string,
  billerId: string,
  jurisdiction: string,
  rvnuTypeCode: string,
  vtnsRteSchdleCode: string,
  cntrctSvcNm: string,
  cntrctSvcDesc: string,
  webUserId: string
}

@Component({
  selector: 'newservice',
  templateUrl: './newservice.component.html',
  styleUrls: ['./newservice.component.scss']
})
export class NewserviceComponent implements OnInit {
  ELE_DATA: [];
  ELEMENT_DATA: PeriodicElement[] = [
    { cntrctSvcSeqNo: '', prdctSvcCode: '', billerId: '', jurisdiction: '', rvnuTypeCode: '', vtnsRteSchdleCode: '', cntrctSvcNm: '', cntrctSvcDesc: '', webUserId: '' },
    { cntrctSvcSeqNo: '', prdctSvcCode: '', billerId: '', jurisdiction: '', rvnuTypeCode: '', vtnsRteSchdleCode: '', cntrctSvcNm: '', cntrctSvcDesc: '', webUserId: '' },
    { cntrctSvcSeqNo: '', prdctSvcCode: '', billerId: '', jurisdiction: '', rvnuTypeCode: '', vtnsRteSchdleCode: '', cntrctSvcNm: '', cntrctSvcDesc: '', webUserId: '' },
    { cntrctSvcSeqNo: '', prdctSvcCode: '', billerId: '', jurisdiction: '', rvnuTypeCode: '', vtnsRteSchdleCode: '', cntrctSvcNm: '', cntrctSvcDesc: '', webUserId: '' },
    { cntrctSvcSeqNo: '', prdctSvcCode: '', billerId: '', jurisdiction: '', rvnuTypeCode: '', vtnsRteSchdleCode: '', cntrctSvcNm: '', cntrctSvcDesc: '', webUserId: '' },
    { cntrctSvcSeqNo: '', prdctSvcCode: '', billerId: '', jurisdiction: '', rvnuTypeCode: '', vtnsRteSchdleCode: '', cntrctSvcNm: '', cntrctSvcDesc: '', webUserId: '' },
    { cntrctSvcSeqNo: '', prdctSvcCode: '', billerId: '', jurisdiction: '', rvnuTypeCode: '', vtnsRteSchdleCode: '', cntrctSvcNm: '', cntrctSvcDesc: '', webUserId: '' },
    { cntrctSvcSeqNo: '', prdctSvcCode: '', billerId: '', jurisdiction: '', rvnuTypeCode: '', vtnsRteSchdleCode: '', cntrctSvcNm: '', cntrctSvcDesc: '', webUserId: '' },
    { cntrctSvcSeqNo: '', prdctSvcCode: '', billerId: '', jurisdiction: '', rvnuTypeCode: '', vtnsRteSchdleCode: '', cntrctSvcNm: '', cntrctSvcDesc: '', webUserId: '' },
    { cntrctSvcSeqNo: '', prdctSvcCode: '', billerId: '', jurisdiction: '', rvnuTypeCode: '', vtnsRteSchdleCode: '', cntrctSvcNm: '', cntrctSvcDesc: '', webUserId: '' }
  ];

  ngOnInit() {
    this.AssignValue();
  }

  AssignValue() {
    this.ELE_DATA = JSON.parse(JSON.stringify(this.ELEMENT_DATA));
    console.log(this.ELE_DATA);
  }

  displayedColumns: string[] = ['cntrctSvcSeqNo', 'prdctSvcCode', 'billerId', 'jurisdiction', 'rvnuTypeCode', 'vtnsRteSchdleCode', 'cntrctSvcNm', 'cntrctSvcDesc'];
  dataSource = this.ELEMENT_DATA;

  constructor(private router: Router, private fb: FormBuilder,
    private userService: UserService,
    private _notifService: NotificationService,
    private pscContractService: PscContractService,) {

  }
  submit() {
    let callApi = true;
    let filteredElements: any = [];
    let keys = ['cntrctSvcSeqNo', 'prdctSvcCode', 'billerId', 'jurisdiction', 'rvnuTypeCode', 'vtnsRteSchdleCode', 'cntrctSvcNm', 'cntrctSvcDesc'];

    for (let i = 0; i < this.dataSource.length; i++) {
      for (let j = 0; j < keys.length; j++) {
        if (this.dataSource[i][keys[j]].length > 0) {
          if (this.dataSource[i].cntrctSvcSeqNo !== '' && this.dataSource[i].prdctSvcCode !== '' && this.dataSource[i].billerId !== '' && callApi) {
            if (filteredElements.indexOf(this.dataSource[i]) == -1) {
              filteredElements.push(this.dataSource[i]);
            }
            callApi = true;
          }
          else if ((this.dataSource[i].cntrctSvcSeqNo === '' || this.dataSource[i].prdctSvcCode === '' || this.dataSource[i].billerId === '') && callApi) {
            callApi = false;
            alert("Please fill the mandatory fields i.e Contract Service Sequence Number , Product Service Code and Biller ID");
            break;
          }
        }
      }
    }
    if (filteredElements.length == 0 && callApi) {
      alert('Please fill the data!!!');
      callApi = false;
      return;
    }

    if (callApi && filteredElements.length > 0) {
      this.dataSource.forEach((el, index) => {
        let i = index + 1

        if (el.cntrctSvcSeqNo != "" && el.cntrctSvcSeqNo.length != 2) {
          alert('Contract Service Sequence Number should have 2 characters.\n ' + 'Contract Service Sequence Number value in row ' + i + ' is wrong!!!');
          callApi = false;
        }

        if (el.prdctSvcCode != "" && el.prdctSvcCode.length != 10) {
          alert('Product Service Code should have 10 characters.\n ' + 'Product Service Code value in row ' + i + ' is wrong!!!');
          callApi = false;
        }

        if (el.billerId != "" && el.billerId.length != 2) {
          alert('Biller ID should have 2 characters \n ' + 'Biller ID  value in row ' + i + ' is wrong !!!');
          callApi = false;
        }

        if (el.billerId == "ON" || el.billerId == "on" || el.billerId == "MD" || el.billerId == "md") {

          if (el.vtnsRteSchdleCode !== "") {
            alert('The VTNS Rate Schedule  field  is not applicable for this biller' + i + '!!!');
            callApi = false;
          }
          if (el.rvnuTypeCode == '') {
            alert('The Revenue type field is mandatory, when the biller id value is ' + el.billerId + ' in row' + i + '!!!');
            callApi = false;
          }

          if (el.jurisdiction == '') {
            alert('The Jurisdiction field is mandatory , when the biller id value is ' + el.billerId + ' in row' + i + '!!!');
            callApi = false;
          }

        }

        else if (el.billerId == "FC" || el.billerId == "fc") {

          if (el.vtnsRteSchdleCode == "") {
            var r = confirm('The VTNS Rate Schedule  field is preferred for the BILLER FC  in row ' + i + '!!!');
            callApi = false;
          }

          if (el.jurisdiction != "" || el.rvnuTypeCode != "") {
            alert('The Jurisdiction and Revenue Type Code is not applicable for this biller MD or ON in row ' + i + '!!!');
            callApi = false;
          }
        }
        else {
          if (el.jurisdiction != "" || el.rvnuTypeCode != "" || el.vtnsRteSchdleCode != "") {
            alert('The Jurisdiction and Revenue Type Code is not applicable when the BILLER ID is not MD or ON in row ' + i + ' and The VTNS Rate Schedule  is not applicable when the BILLER ID is not FC ');
            callApi = false;
          }

        }
      })
    }

    if (callApi && filteredElements.length > 0) {
      this.pscContractService.newServiceMapping(filteredElements).subscribe(resp => {
        this._notifService.showSuccessNotification(resp);
        this.router.navigateByUrl('/customer-contract/psc-contract');

      }, error => {
        this._notifService.showErrorNotification(error);
      });
    }
  };
  goPrevious() {
    this.router.navigateByUrl('/customer-contract/psc-contract');
  }

  reset() {

    console.log(this.ELE_DATA);
    this.ELEMENT_DATA = this.ELE_DATA;
    console.log(this.ELEMENT_DATA);
    this.dataSource = Object.assign([], this.ELEMENT_DATA);
    this.AssignValue();
  }
}
