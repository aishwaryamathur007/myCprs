import { Component, OnInit, Inject, Optional } from '@angular/core';
import { FormControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { PscContractService } from 'src/app/cpr-views/service/psc-contract.service';


@Component({
  selector: 'update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.scss']
})
export class UpdateComponent implements OnInit {

  appData: any;
  serviceSequence: any;
  serviceDescription: any;
  serviceName: any;
  addAppForm: FormGroup;
  load: boolean = false;
  fetchingReport: boolean;
  isSubmitted: boolean = false;
  isSubmit: boolean = true;
  dataSource: any;
  constructor(private fb: FormBuilder, private reportService: PscContractService, public dialogRef: MatDialogRef<UpdateComponent>,
    @Optional() @Inject(MAT_DIALOG_DATA) public data: any) {
  }

  ngOnInit(): void {
    this.setupSearchForm();
  }

  update() {
    // let callApi = true;
    this.dialogRef.close({ data: this.addAppForm.value });
  }

  setupSearchForm(): void {
    this.addAppForm = this.fb.group({
      serviceSequence: new FormControl(null, [Validators.required]),
      serviceDescription: new FormControl(null, [Validators.required]),
      serviceName: new FormControl(null, [Validators.required])
    });
    this.load = true;
  }

  async fetchReport() {
    this.fetchingReport = true;
    let serviceSequence = this.addAppForm.get('serviceSequence').value;
    let serviceDescription = this.addAppForm.get('serviceDescription').value;
    let serviceName = this.addAppForm.get('serviceName').value;
    this.isSubmit = true;
  }

  onClose(): void {
    console.log('hey');
    this.dialogRef.close({});
  }

}
