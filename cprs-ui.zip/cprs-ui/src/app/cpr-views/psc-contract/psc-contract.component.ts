import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { FormBuilder, FormControl, FormGroup, SelectControlValueAccessor, Validators } from '@angular/forms';
import { UserDetails, UserService } from 'src/app/shared/service/user.service';
import { MatPaginator } from '@angular/material/paginator';
import { PscContractService } from '../service/psc-contract.service';
import { UpdateComponent } from './model/update/update.component';
import { NotificationService } from 'src/app/common/services/notification.service';
import { ConfirmComponent } from 'src/app/common/component/confirm/confirm.component';
import { MatSort } from '@angular/material/sort';

@Component({
  selector: 'psc-contract',
  templateUrl: './psc-contract.component.html',
  styleUrls: ['./psc-contract.component.scss']
})

export class PscContractComponent implements OnInit {
  businessForm: FormGroup;
  noCancel: any;
  fetchData: boolean = false;
  billerId: any;
  contractDescription: any;
  contractName: any;
  vtnsCode: any;
  contractNo: any;
  productCode: any;
  revenueCode: any;
  jurisdiction: any;
  load: boolean = false;
  isTabletMode: boolean = false;
  isSubmitted: boolean = false;
  mode: string = 'search'; // used to toggle between search and report view
  paginator: any;
  pageSize = 100;
  fetchingReport: boolean;
  dataFetched: boolean;

  displayedColumns: string[] = ['action', 'CNTRCT_SVC_SEQ_NB', 'PROD_SVC_CD', 'BLR_ID', 'WH_JURIS_CD', 'FNCL_RVNU_TYPE_CD', 'VTNS_RT_SCHED_ID', 'CNTRCT_SVC_NM', 'CNTRCT_SVC_DESC_TX'];
  dataSource: MatTableDataSource<any>;
  reportData: any;
  data: any;
  user: any;
  searchText: any;
  sort: any;
  isSubmit: boolean;

  @ViewChild('paginator', { static: false }) set matPaginator(
    mp: MatPaginator
  ) {
    this.paginator = mp;
    if (mp && this.dataSource) {
      this.dataSource.paginator = this.paginator;
    }
  }

  @ViewChild('sort', { static: false }) set matSort(ms: MatSort) {
    this.sort = ms;
    if (ms && this.dataSource) {
      this.dataSource.sort = this.sort;
    }
  }

  constructor(private fb: FormBuilder, public dialog: MatDialog,
    private pscContractService: PscContractService,
    private _notifService: NotificationService,
    private router: Router, private userService: UserService) { this.user = this.userService.getUserDetails(); }

  ngOnInit(): void {
    this.setupForm();
    this.dataSource = new MatTableDataSource();
  }

  windowResized() {
    this.isTabletMode = this.isTablet() ? true : false;
  }

  setupForm(): void {
    this.businessForm = this.fb.group({
      contractNo: new FormControl(),
      productCode: new FormControl(),
      billerId: new FormControl(),
      jurisdiction: new FormControl(),
      revenueCode: new FormControl(),
      vtnsCode: new FormControl(),
      contractName: new FormControl(),
      contractDescription: new FormControl(),
    });
  }

  retrieveData() {
    let billerId = this.businessForm.get('billerId').value;
    let contractDescription = this.businessForm.get('contractDescription').value;
    let contractName = this.businessForm.get('contractName').value;
    let contractNo = this.businessForm.get('contractNo').value;
    let jurisdiction = this.businessForm.get('jurisdiction').value;
    let productCode = this.businessForm.get('productCode').value;
    let revenueCode = this.businessForm.get('revenueCode').value;
    let vtnsCode = this.businessForm.get('vtnsCode').value;
    this.isSubmitted = true;
    this.billerId = billerId;
    this.isSubmit = true;
    this.searchText = '';
   // this.mode = 'search';
    let obj = {

      "billerId": billerId ?? '',
      "cntrctSvcDesc": contractDescription ?? '',
      "cntrctSvcNm": contractName ?? '',
      "cntrctSvcSeqNo": contractNo ?? '',
      "jurisdiction": jurisdiction ?? '',
      "prdctSvcCode": productCode ?? '',
      "rvnuTypeCode": revenueCode ?? '',
      "vtnsRteSchdleCode": vtnsCode ?? '',
      "webUserId": this.user.attuid

    }

    // setTimeout(() => {
    this.pscContractService.retrieveData(obj).subscribe((resp) => {
      this.noCancel = JSON.parse(JSON.stringify(resp));
      this.reportData = resp;
      this.dataSource = new MatTableDataSource(resp);
      this.isSubmitted = false;
      this.dataSource.sort = this.sort;
      this.mode = 'view';
  
    });
    // }, 500);

    this.businessForm.disable();
  }

  cancel() {
    this.businessForm.enable();
    this.mode = 'search';
    this.businessForm.reset();
    this.searchText = '';
  }

  isTablet(): boolean {
    if (window.screen.width <= 1024) {
      return true;
    }

    return false;
  }
  editRow(ele: any) {
    ele.isEdit = true;
  }

  updateRow(ele: any) {
    ele.isEdit = false;
    let obj = {
      "billerId": ele.BLR_ID,
      "cntrctSvcDesc": ele.CNTRCT_SVC_DESC_TX,
      "cntrctSvcNm": ele.CNTRCT_SVC_NM,
      "cntrctSvcSeqNo": ele.CNTRCT_SVC_SEQ_NB,
      "jurisdiction": ele.WH_JURIS_CD,
      "prdctSvcCode": ele.PROD_SVC_CD,
      "rvnuTypeCode": ele.FNCL_RVNU_TYPE_CD,
      "vtnsRteSchdleCode": ele.VTNS_RT_SCHED_ID,
      "webUserId": this.user.attuid
    }
    this.pscContractService.saveDetails(obj).subscribe(resp => {
      if(!!resp) {
      this._notifService.showSuccessNotification(resp);
      // this.retrieveData();
      }
    }, error => {
      this._notifService.showErrorNotification(error);
    });
  }

  deleteRow(index: any, obj: any) {
    let confirmObj = { type: 1, content: 'Are you sure want to delete?' };
    let deleteObj = {
      'Contract Service Sequence Number': obj.CNTRCT_SVC_SEQ_NB,
      'Biller Id': obj.BLR_ID,
      'Product Service Code': obj.PROD_SVC_CD
    };
    this.dialog.open(ConfirmComponent, { data: confirmObj }).afterClosed().subscribe(result => {
      if (result) {
        this.fetchData = true;
        this.isSubmitted = true;
        this.pscContractService.deleteAssignDetails(deleteObj).subscribe(resp => {
          this.isSubmitted = false;
          this.fetchData = false;
          if (!!resp) {
            this._notifService.showSuccessNotification(resp);
            this.dataSource.data.splice(index, 1);
            this.dataSource = new MatTableDataSource(this.dataSource.data);
            this.dataSource.paginator = this.paginator;
            this.searchText = '';
          }
        }, error => {
          this.isSubmitted = false;
          this.fetchData = false;
          this._notifService.showErrorNotification(error);
        });
      }
    });
  }

  cancelRow(i, ele: any) {
    ele.isEdit = false;
    let ind = this.noCancel.findIndex(function (item) { return item['PROD_SVC_CD'] == ele['PROD_SVC_CD'] });
    // this.dataSource.data[i]['CNTRCT_SVC_NM'] = this.noCancel[ind]['CNTRCT_SVC_NM'];
    // this.dataSource.data[i]['CNTRCT_SVC_DESC_TX'] = this.noCancel[ind]['CNTRCT_SVC_DESC_TX'];
    ele['CNTRCT_SVC_NM'] = this.noCancel[ind]['CNTRCT_SVC_NM'];
    ele['CNTRCT_SVC_DESC_TX'] = this.noCancel[ind]['CNTRCT_SVC_DESC_TX'];
    console.log(this.noCancel);

  }

  updateNameDesc(): void {
    let dialogRef = this.dialog.open(UpdateComponent, {
      width: '600px'
    });
    dialogRef.afterClosed().subscribe(result => {

      if (result?.data) {

        this.fetchData = true;
        this.isSubmitted = true;
        let obj = {

          "billerId": this.businessForm.get('billerId').value ?? '',
          "cntrctSvcDesc": this.businessForm.get('contractDescription').value ?? '',
          "cntrctSvcNm": this.businessForm.get('contractName').value ?? '',
          "cntrctSvcSeqNo": this.businessForm.get('contractNo').value ?? '',
          "jurisdiction": this.businessForm.get('jurisdiction').value ?? '',
          "newCntrctSvcDesc": result.data.serviceDescription,
          "newCntrctSvcNm": result.data.serviceName,
          "newCntrctSvcSeqNo": result.data.serviceSequence,
          "prdctSvcCode": this.businessForm.get('productCode').value ?? '',
          "rvnuTypeCode": this.businessForm.get('revenueCode').value ?? '',
          "vtnsRteSchdleCode": this.businessForm.get('vtnsCode').value ?? '',
          "webUserId": this.user.attuid

        }
        this.pscContractService.updateNameDesc(obj).subscribe(resp => {

          if (!!resp && resp !== 504) {
            this._notifService.showSuccessNotification('Data Updated Successfully!');
            //  this._notifService.showSuccessNotification(resp);
            this.reportData = resp;
            this.dataSource = new MatTableDataSource(this.reportData);
            this.dataSource.sort = this.sort;
          } else {
            this._notifService.showErrorNotification('Sorry, an error occurred! Please refresh the page and narrow down the search criteria.');
          }
            this.mode = 'view';
            this.isSubmitted = false;
            this.searchText = '';
            this.fetchData = false;
        }, error => {
          this._notifService.showErrorNotification('Sorry, an error occurred! Please refresh the page and narrow down the search criteria.');
        });
      }
    });
  }

  addNewServiceMapping(ele: any) {
    ele.isEdit = false;
    let obj = {
      "billerId": ele.BLR_ID,
      "cntrctSvcDesc": ele.CNTRCT_SVC_DESC_TX,
      "cntrctSvcNm": ele.CNTRCT_SVC_NM,
      "cntrctSvcSeqNo": ele.CNTRCT_SVC_SEQ_NB,
      "jurisdiction": ele.WH_JURIS_CD,
      "prdctSvcCode": ele.PROD_SVC_CD,
      "rvnuTypeCode": ele.FNCL_RVNU_TYPE_CD,
      "vtnsRteSchdleCode": ele.VTNS_RT_SCHED_ID,
      "webUserId": ''
    }
    this.pscContractService.newServiceMapping(obj).subscribe(resp => {
      if (!!resp) {
        this._notifService.showSuccessNotification(resp);
        this.searchText = '';
      }
    }, error => {
      this._notifService.showErrorNotification(error);
    });
  }

  doFilter(value: string) {
    this.dataSource.filter = value.trim().toLocaleLowerCase();
    this.searchText = value;
  }
}


