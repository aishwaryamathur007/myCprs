import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'application-reports',
  templateUrl: './application-reports.component.html',
  styleUrls: ['./application-reports.component.scss']
})
export class ApplicationReportsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
