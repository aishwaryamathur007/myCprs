import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import * as moment from 'moment';
import { MappingModalComponent } from '../customer-contract-maintenance/mapping-modal/mapping-modal.component';
import { ReportsDataService } from '../service/reports-data.service';

@Component({
  selector: 'service-mapping',
  templateUrl: './service-mapping.component.html',
  styleUrls: ['./service-mapping.component.scss']
})
export class ServiceMappingComponent implements OnInit {
  fetchingData:boolean;
  reportData: any[] = [];
  paginator: any;
  @ViewChild('paginator', { static: false }) set matPaginator(
    mp: MatPaginator
  ) {
    this.paginator = mp;
    if (mp && this.reportDataSource) {
      this.reportDataSource.paginator = this.paginator;
    }
  }
  
  dataColumns: string[] = [
    'select',
    'PRFR_CUST_NM',
    'CNTRCT_CUST_ID',
    'OFFR_ID',
    'OFFR_EFF_DT',
    'CUST_OFFR_STRT_DT',
  ];
  reportDataSource: MatTableDataSource<any>;
  selectedMapping: any;
  constructor(private reportsService: ReportsDataService, private dialog: MatDialog) { }

  ngOnInit(): void {
    this.getData();
  }

  async getData() {
    this.fetchingData = true;
    this.reportsService.getServiceMappingReviewApproval().subscribe((resp) => {
      this.reportData = resp;
      this.reportDataSource = new MatTableDataSource(this.reportData);
      this.fetchingData = false;
    });
  }

  select($event, element) {
    this.selectedMapping = element;
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.reportDataSource.filter = filterValue.trim().toLowerCase();

    if (this.reportDataSource.paginator) {
      this.reportDataSource.paginator.firstPage();
    }
  }

  submit() {
    const dialogRef = this.dialog.open(MappingModalComponent, {
      data: {
        customerId: this.selectedMapping.CNTRCT_CUST_ID,
        offerActnId: ' ',
        offerEffDate:moment(this.selectedMapping.OFFR_EFF_DT).format('MM/DD/YYYY'),
        offerId: this.selectedMapping.OFFR_ID,
        offerStartDate: moment(this.selectedMapping.CUST_OFFR_STRT_DT).format('MM/DD/YYYY'),
        sourceId: this.selectedMapping.CNTRCT_SRCE_ID
      },
      width: '95%',
      disableClose: true,
      maxWidth:'100vw',
      maxHeight:'95vh',
      panelClass: 'resize-modalbox'
      // height:'90%'
    });

    dialogRef.afterClosed().subscribe(val => {
      if (val) {

      }
    });
  }
}
