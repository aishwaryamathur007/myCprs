import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerContractMaintenanceComponent } from './customer-contract-maintenance.component';

describe('CustomerContractMaintenanceComponent', () => {
  let component: CustomerContractMaintenanceComponent;
  let fixture: ComponentFixture<CustomerContractMaintenanceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerContractMaintenanceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerContractMaintenanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
