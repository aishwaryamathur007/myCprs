import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { NotificationService } from 'src/app/common/services/notification.service';
import { CustomerContractMaintenanceService } from '../../service/customer-contract-maintenance.service';

export interface UserData {
  CNTRCT_SRCE_TX: string,
  CNTRCT_SRCE_ID: number,
  CNTRCT_CUST_ID: number,
  PRFR_CUST_NM: string,
  OFFR_TYPE_DESC_TX: string,
  OFFR_ID: string,
  OFFR_EFF_DT1: string
}
@Component({
  selector: 'customer-contract-maintenance',
  templateUrl: './customer-contract-maintenance.component.html',
  styleUrls: ['./customer-contract-maintenance.component.scss']
})
export class CustomerContractMaintenanceComponent implements OnInit {
  displayedColumns: string[] = ['CNTRCT_SRCE_TX', 'CNTRCT_CUST_ID', 'PRFR_CUST_NM', 'OFFR_TYPE_DESC_TX', 'OFFR_ID', 'OFFR_EFF_DT1'];
  dataSource: MatTableDataSource<UserData>;
  isDataFetched:boolean = false;
  fetchingReport: boolean = false;
  pageSize = 100;
  initialValue:any;
  paginator:any;
  sort:any;
  @ViewChild('paginator', { static: false }) set matPaginator(mp: MatPaginator) {
    this.paginator = mp;
    if (mp && this.dataSource) {
      this.dataSource.paginator = this.paginator;
    }
  }
  @ViewChild('sort', { static: false }) set matSort(ms: MatSort) {
    this.sort = ms;
    if (ms && this.dataSource) {
      this.dataSource.sort = this.sort;
    }
  }
  constructor(private ccntmain: CustomerContractMaintenanceService, private router: Router, private notifService:NotificationService) { 
      // this.initialValue = this.ccntmain.customerArray.subscribe(resp => {
      //   if(resp.length !=0) {
      //   this.dataSource = new MatTableDataSource(resp);
      //   this.isDataFetched = true;
      //   }
      // });
  }
  ngOnInit(): void {  }
  ngDestory(){
    this.initialValue.unsubscribe();
  }
  customerData(evnt:any) {
    if (!evnt.searchTypeValue) {
      delete evnt.searchTypeValue;
    }
    this.fetchingReport = true;
    this.ccntmain.getCustomerData(evnt).subscribe(resp => {
      this.fetchingReport = false;
      if (!!resp) {
        this.dataSource = new MatTableDataSource(resp);
        this.ccntmain.loadAll(resp);
        this.isDataFetched = true;
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
      }
    }, error=> {
      this.notifService.showErrorNotification(error);
    })
  }
  doFilter(value: string) {
    this.dataSource.filter = value.trim().toLocaleLowerCase();
  }
  addCustomer() {
    this.router.navigate(['/customer-contract/customer-contract-maintenance/edit'], { queryParams: { mode: 'add' } });
  }
  getCustomerDetails(ele: any) {
    let custDetails = {
      mode: 'edit',
      customerId: ele.CNTRCT_CUST_ID ? ele.CNTRCT_CUST_ID :'' ,
      offerDate: ele.OFFR_EFF_DT1 ? ele.OFFR_EFF_DT1 :'',
      offerId: ele.OFFR_ID ? ele.OFFR_ID :'',
      sourceId: ele.CNTRCT_SRCE_ID ? ele.CNTRCT_SRCE_ID :''
    }
    this.router.navigate(['/customer-contract/customer-contract-maintenance/edit'], { queryParams: custDetails });
  }
  // code added
}