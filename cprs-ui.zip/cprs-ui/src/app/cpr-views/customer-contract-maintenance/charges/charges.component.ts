import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import * as moment from 'moment';
import { NotificationService } from 'src/app/common/services/notification.service';
import { UserService } from 'src/app/shared/service/user.service';
import { CustomerContractMaintenanceService } from '../../service/customer-contract-maintenance.service';
import { AdjustmentComponent } from '../adjustment/adjustment.component';

@Component({
  selector: 'charges',
  templateUrl: './charges.component.html',
  styleUrls: ['./charges.component.scss']
})
export class ChargesComponent implements OnInit {
  columnsSchema = [
    {
      key: "INVC_DT",
      type: "",
      label: "INVOICE DATE"
    },
    {
      key: "ACTN_DESC_SHRT_TX",
      type: "",
      label: "ACTIVITY TYPE"
    },
    {
      key: "ADJMT_AT",
      type: "text",
      label: "AMOUNT"
    },
    {
      key: "STAT_DESC_TX",
      type: "select",
      label: "STATUS"
    },
    {
      key: "ADJMT_RSN_DESC_TX",
      type: "select",
      label: "ADJUSTMENT REASON"
    },
    {
      key: "NOTES_TX",
      type: "text",
      label: "TEXT NOTES"
    },
    {
      key: "Adjustment",
      type: "link",
      label: "VTNS Adjustment"
    }
  ];
  displayedColumns: string[];
  chargesForm: FormGroup;
  dataSource: MatTableDataSource<any>;
  isDataFetched: boolean = false;
  fetchingReport: boolean = false;
  statusDropDown: any;
  adjReasonDropDown: any;
  isSubmit: boolean = false;
  isUpdated: boolean = false;
  constructor(private ccntmain: CustomerContractMaintenanceService, private notifService: NotificationService,
    @Inject(MAT_DIALOG_DATA) public modalData: any, private dialog: MatDialog, private fb: FormBuilder, private dialogRef: MatDialogRef<ChargesComponent>, private user: UserService) { }

  ngOnInit(): void {
    this.chargesForm = this.fb.group({
      INVC_DT: [''], ACTN_DESC_SHRT_TX: [''], ADJMT_AT: ['', Validators.required], STAT_DESC_TX: ['', Validators.required], ADJMT_RSN_DESC_TX: ['', Validators.required], NOTES_TX: ['', Validators.required]
    });
    this.getStatus();
    this.getAdjustmentReason();
    this.getCharges();
    if(this.modalData.topGrid.CNTRCT_SRCE_ID != 'V') {
    let temArr = this.columnsSchema.map((col) => col.key);
    this.displayedColumns = temArr.slice(0,temArr.length-1);
    } else {
      this.displayedColumns = this.columnsSchema.map((col) => col.key);
    }
  }
  getStatus() {
    this.fetchingReport = true;
    this.ccntmain.getStatus().subscribe(resp => {
      this.fetchingReport = false;
      this.statusDropDown = resp;
    }, error => {
      this.fetchingReport = false;
      this.notifService.showErrorNotification(error);
    });
  };
  getAdjustmentReason() {
    this.fetchingReport = true;
    this.ccntmain.getAdjustmentReason().subscribe(resp => {
      this.fetchingReport = false;
      this.adjReasonDropDown = resp;
    }, error => {
      this.fetchingReport = false;
      this.notifService.showErrorNotification(error);
    });
  };
  getCharges() {
    this.fetchingReport = true;
    this.isDataFetched = false;
    let obj = {
      "customerId": this.modalData.topGrid.CNTRCT_CUST_ID,
      "offerActnId": this.modalData.actGrid.OFFR_ACTN_ID ??  this.modalData.actGrid.OFF_ACT_ID,
      "offerId": this.modalData.topGrid.OFFR_ID,
      "offerSchedDate": this.modalData.actGrid.ACTN_SCHED_DT ?? this.modalData.actGrid.ACTN_SCHED_DT_COPY,
      "sourceId": this.modalData.custData.sourceId
    };   
    this.ccntmain.getCharges(obj).subscribe(resp => {
      this.dataSource = new MatTableDataSource(resp);
      if(!!resp) {
      if((['O','S'].includes(this.modalData.topGrid.CNTRCT_SRCE_ID)) && (['Accepted','Sent','Billed','CT Additional Accounts'].includes(resp[0]?.STAT_DESC_TX))) {
        this.chargesForm.disable();
      } else {
        this.chargesForm.enable();
      }
      this.chargesForm.patchValue(resp[0]);
    }
      this.changesDetect();
      this.fetchingReport = false;
      this.isDataFetched = true;
    }, error => {
      this.fetchingReport = false;
      this.isDataFetched = true;
      this.notifService.showErrorNotification(error);
    });
  };
  changesDetect() {
    this.chargesForm.valueChanges.subscribe(newValues => {
      this.isUpdated = true;
    });
  }
  getAdjustments(adj: any) {
    const dialogRef = this.dialog.open(AdjustmentComponent, {
      data: {
        charges: adj,
        custData:this.modalData.custData
      },
      width: '70%',
      disableClose: true,
      panelClass: 'resize-modalbox'
    });
  };
  saveCharges() {
    this.isSubmit = true;
    if (this.chargesForm.valid) {
      this.fetchingReport = true;
      let obj = {    
        "customerId": this.modalData.topGrid.CNTRCT_CUST_ID,
        "offerActnId": this.modalData.actGrid.OFFR_ACTN_ID ?? this.modalData.actGrid.OFF_ACT_ID,
        "offerId": this.modalData.topGrid.OFFR_ID,
        "offerSchedDate": this.modalData.actGrid.ACTN_SCHED_DT ?? this.modalData.actGrid.ACTN_SCHED_DT_COPY, 
        "sourceId": this.modalData.custData.sourceId,
        "adjAmount": this.chargesForm.value.ADJMT_AT,
        "adjReason": this.chargesForm.value.ADJMT_RSN_DESC_TX,
        "offEffDate": moment(new Date(this.modalData.topGrid.OFFR_EFF_DT)).format('MM/DD/YYYY'),                
        "status": this.chargesForm.value.STAT_DESC_TX,
        "txtNotes": this.chargesForm.value.NOTES_TX,
        "webUserId": this.user.attuid        
      };
      this.ccntmain.updateCharges(obj).subscribe(resp => {
        this.fetchingReport = false;
        if(!!resp) {
          this.notifService.showSuccessNotification(resp);
        }
      }, error => {
        this.fetchingReport = false;
        this.notifService.showErrorNotification(error);
      })
    }
  };
  // Only Numbers with Decimals
keyPressNumbersDecimal(event) {
  var charCode = (event.which) ? event.which : event.keyCode;
  if (charCode != 46 && charCode > 31
    && (charCode < 48 || charCode > 57)) {
    event.preventDefault();
    return false;
  }
  return true;
}
  close() {
    this.dialogRef.close();
  }
}
