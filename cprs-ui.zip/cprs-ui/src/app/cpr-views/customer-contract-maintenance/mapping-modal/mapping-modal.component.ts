import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSelectChange } from '@angular/material/select';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import * as moment from 'moment';
import { NotificationService } from 'src/app/common/services/notification.service';
import { UserService } from 'src/app/shared/service/user.service';
import { CustomerContractMaintenanceService } from '../../service/customer-contract-maintenance.service';
import * as  FileSaver from 'file-saver';

@Component({
  selector: 'mapping-modal',
  templateUrl: './mapping-modal.component.html',
  styleUrls: ['./mapping-modal.component.scss']
})
export class MappingModalComponent implements OnInit {
  COLUMNS_SCHEMA = [
    {
      key: "isEdit",
      type: "isEdit",
      label: "Call To Action"
    },
    {
      key: "MAP_RQST_STAT_CD",
      type: "select",
      label: "Status",
      options: [{ value: 'A', label: 'Approved' }, { value: 'P', label: 'Pending' }, { value: 'R', label: 'Reject' }]
    },
    {
      key: "MAP_RQST_TYPE_CD",
      type: "select",
      label: "Action Requested",
      options: [{ value: 'include', label: 'Include' }, { value: 'Remove', label: 'Remove' }]
    },
    {
      key: "SUB_GP_DESC_TX",
      type: "select",
      label: "Service (Bucket)",
      options: []
    },
    {
      key: "ACCT_ID",
      type: "text",
      label: "Account Number"
    },
    {
      key: "CNTRCT_CUST_ID",
      type: "text",
      label: "Customer Id"
    },
    {
      key: "OFFR_ID",
      type: "text",
      label: "Offer Id"
    },
    {
      key: "PRFR_CUST_NM",
      type: "text",
      label: "Customer Name"
    },
    {
      key: "OFFR_EFF_DT",
      type: "date",
      label: "Start Date"
    },
    {
      key: "ROW_CREAT_USR_ID",
      type: "text",
      label: "Requestor ATTUID"
    }
  ];
  newMapRow = { MAP_RQST_STAT_CD: '', MAP_RQST_TYPE_CD: '', SUB_GP_DESC_TX: '', BLR_ID: '', ACCT_ID: '', CNTRCT_CUST_ID: '', OFFR_ID: '', PRFR_CUST_NM: '', OFFR_EFF_DT: '', ROW_CREAT_USR_ID: '', ORDER_IND: '', SUB_GP_CD: '' };
  displayedColumns: string[] = this.COLUMNS_SCHEMA.map((col) => col.key);
  columnsSchema: any = this.COLUMNS_SCHEMA;
  mappingdata: MatTableDataSource<any>;
  copyData: boolean = false;
  serviceBucket: any;
  paginator: any;
  sort: any;
  pageSize = 100;
  incRemove: any;
  loading: boolean = true;
  downloading: boolean = false;
  isUpdated: boolean;
  applyToActivityOptions: any;
  applyToActDrop:any = [];
  isModified:boolean = false;
  @ViewChild('paginator', { static: false }) set matPaginator(mp: MatPaginator) {
    this.paginator = mp;
    if (mp && this.mappingdata) {
      this.mappingdata.paginator = this.paginator;
    }
  }
  @ViewChild('sort', { static: false }) set matSort(ms: MatSort) {
    this.sort = ms;
    if (ms && this.mappingdata) {
      this.mappingdata.sort = this.sort;
    }
  }
  constructor(private ccntmain: CustomerContractMaintenanceService, private notifService: NotificationService,
    @Inject(MAT_DIALOG_DATA) public data: any, private user: UserService) { }

  ngOnInit(): void {
    this.isModified = false;
    if(!!this.data.offerActnId && this.data.offerActnId != " ") {
    this.applyToActDrop = [this.data.offerActnId];
    }
    let activity = {
      actnTypeId: 'CM',
      cntrctCustId: this.data.customerId,
      offerEffDate: this.data.offerEffDate,
      offerId: this.data.offerId
    };
    this.ccntmain.getServiceMappingApplyToActivity(activity).subscribe(mapAct => {
      this.applyToActivityOptions = mapAct;
    }, error => {
      this.notifService.showErrorNotification(error);
    });
    this.ccntmain.getServiceBuckets().subscribe(service => {
      this.loading = true;
      this.serviceBucket = new Array(service);
      this.getserviceMapping();
    }, error => {
      this.loading = false;
      this.notifService.showErrorNotification(error);
    });
  }
  getserviceMapping() {
    let activity = {
      customerId: this.data.customerId,
      offerActnId: this.data.offerActnId,
      offerId: this.data.offerId,
      sourceId: this.data.sourceId,
      offerEffDate: this.data.offerEffDate ?? '',
      offerStartDate: this.data.offerStartDate ?? '',
    };
    this.ccntmain.getserviceMapping(activity).subscribe((mapData: any) => {
      this.mappingdata = new MatTableDataSource(mapData);
      this.mappingdata.sort = this.sort;
      this.mappingdata.paginator = this.paginator;
      this.loading = false;
    }, error => {
      this.loading = false;
      this.notifService.showErrorNotification(error);
    });
  };
  editTable(ele: any, i: any) {
    ele['isEdit'] = true;
    ele['copyData'] = false;
    this.isModified = true;
    this.incRemove = ele['MAP_RQST_TYPE_CD'];
    this.openClick();
  }
  selectRow(ele: any, evnt: any) {
    ele.checked = evnt.target.children[0].checked;
  }
  copyRow(ele: any) {
    let obj = Object.assign({}, ele);
    obj['checked'] = true;
    obj['isEdit'] = true;
    obj['copyData'] = true;
    obj['options'] = this.serviceBucket[0];
    this.incRemove = obj['MAP_RQST_TYPE_CD'];
    this.isModified = true;
    this.mappingdata.data = [...this.mappingdata.data, obj];
    this.openClick();
  };
  openClick() {
    if(this.applyToActDrop.length > 0 && this.isModified) {
      this.isUpdated = true;
    } else {
      this.isUpdated = false;
    }
  }
  setOldaValue(ele: any, event: MatSelectChange, key?) {
    if (key == 'MAP_RQST_STAT_CD')
      ele['old'] = event.source.ngControl['model'];
  }
  doFilter(value: string) {
    this.mappingdata.filter = value.trim().toLocaleLowerCase();
  }
  saveMappingEdit() {
    let mapObj = [];
    let editObj = this.mappingdata.data.filter((item) => {
      return item.isEdit == true;
    });
    const editObjKeys = editObj.map((item) => {
      return item.SUB_GP_DESC_TX + item.OFFR_ID;
    });
    var isDuplicate = editObjKeys.some((item, idx) => {
      return editObjKeys.indexOf(item) != idx;
    });
    if (isDuplicate) {
      this.notifService.showErrorNotification(
        'Duplicate mapping requests submitted. Please correct and submit again'
      );
    } else {
      editObj.forEach((obj) => {
        mapObj.push({
          acntNo: obj.ACCT_ID,
          cntrctCutsId: this.data.customerId,
          cntrctSrcId: this.data.sourceId,
          cntrtServcNm: obj.SUB_GP_DESC_TX,
          custOffrStrtDt: this.data.offerStartDate,
          newActionRequested: obj.MAP_RQST_TYPE_CD ?? '',
          newStatus: obj.MAP_RQST_STAT_CD,
          offrActnId: this.applyToActDrop, //this.data.offerActnId,
          offrEffDt: this.data.offerEffDate,
          offrId: obj.OFFR_ID,
          oldStatus: obj.old,
          subGrpCode: obj.SUB_GP_CD,
          startDt: moment(obj.OFFR_EFF_DT).format('MM/DD/YYYY'),
          webUid: this.user.attuid,
        });
      });

      this.ccntmain.addOrUpdateServiceMapping(mapObj).subscribe(
        (resp) => {
          if (!!resp) {
            if (resp.includes('Updated Successfully')){
              this.notifService.showSuccessNotification(resp);
            } else {
              this.notifService.showErrorNotification(resp);
            }
            this.getserviceMapping();
          }
        },
        (error) => {
          this.notifService.showErrorNotification(error);
        }
      );
    }
  }

  async download() {
    if (this.downloading) { return; }
    this.downloading = true;
    let obj = {
      input: this.mappingdata.data,
      colTitles: {
        MAP_RQST_STAT_CD: 'Status',
        MAP_RQST_TYPE_CD: 'Action Required',
        SUB_GP_DESC_TX: 'Service (Bucket)',
        ACCT_ID: 'Account Number',
        CNTRCT_CUST_ID: 'Customer Id',
        OFFR_ID: 'Offer ID',
        PRFR_CUST_NM: 'Customer Name',
        OFFR_EFF_DT: 'Start Date',
        ROW_CREAT_USR_ID: 'Requestor ATTUID',
        BLR_ID: 'Biller Id',
        SUB_GP_CD: 'Sub Group'
      },

    };

    await this.ccntmain.downloadReport(obj).toPromise().then(resp => {
      let date = moment(Date.now()).format('yyyy-MM-dd');
      if (resp) {
        FileSaver.saveAs(resp, this.data.customerId + '_' + date + '.xlsx');
      }
      this.downloading = false;
    });
  }
}
