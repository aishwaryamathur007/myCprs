import { Component, Inject, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import * as moment from 'moment';
import { ConfirmComponent } from 'src/app/common/component/confirm/confirm.component';
import { NotificationService } from 'src/app/common/services/notification.service';
import { UserService } from 'src/app/shared/service/user.service';
import { CustomerContractMaintenanceService } from '../../service/customer-contract-maintenance.service';

@Component({
  selector: 'adjustment',
  templateUrl: './adjustment.component.html',
  styleUrls: ['./adjustment.component.scss']
})
export class AdjustmentComponent implements OnInit {
  topcolumnsSchema = [
    { key: "ADJMT_AT", label: "AMOUNT" },
    { key: "ACTN_DESC_SHRT_TX", label: "ACTIVITY TYPE" },
    { key: "ADJMT_RSN_DESC_TX", label: "ADJUSTMENT REASON" },
    { key: "STAT_DESC_TX", label: "STATUS" },
    { key: "ctRefrnceSction", label: "CT Reference section" }
  ]
  columnsSchema = [
    { key: "invoiceDate", type: "date", label: "Invoice Date" },
    { key: "mcn", type: "text", label: "MCN" },
    { key: "billGroup", type: "text", label: "Bill Group" },
    { key: "totalAmt", type: "text", label: "Total Amount" },
    { key: "inboundDmstcAmt", type: "text", label: "Inbound Domestic Amount" },
    { key: "inboundIntrnlAmt", type: "text", label: "Inbound Int'l Amount" },
    { key: "outboundDmstcAmt", type: "text", label: "Outbound Domestice Amount" },
    { key: "outboundIntrnlAmt", type: "text", label: "Outbound Int'l Amount" },
    { key: "dcsAmt", type: "text", label: "DCS Amount" }
  ];
  topdisplayedColumns: string[] = this.topcolumnsSchema.map((col) => col.key);
  displayedColumns: string[] = this.columnsSchema.map((col) => col.key);
  adjForm: FormGroup;
  dataSource: MatTableDataSource<any>;
  isDataFetched: boolean = false;
  fetchingReport: boolean = false;
  isSubmit: boolean = false;
  isUpdated: boolean = false;
  selectedFunction: any = '0';
  topdataSource: any;
  constructor(private ccntmain: CustomerContractMaintenanceService, private notifService: NotificationService, private user: UserService,
    @Inject(MAT_DIALOG_DATA) public modalData: any, private dialog: MatDialog, private fb: FormBuilder, private dialogRef: MatDialogRef<AdjustmentComponent>,) { }

  ngOnInit(): void {
    this.topdataSource = new MatTableDataSource([this.modalData.charges]);
    this.getAdjustmentData();
    this.adjForm = this.fb.group({
      rowData: this.fb.array([])
    });
  }
  rowData(): FormArray {
    return this.adjForm.get('rowData') as FormArray;
  };
  newRowData(): FormGroup {
    return this.fb.group({
      isEdit: '', mode: '', invoiceDate: ['', Validators.required], mcn: ['', Validators.required], billGroup: ['', Validators.required],
      totalAmt: ['', Validators.required], inboundDmstcAmt: [''], inboundIntrnlAmt: [''], outboundDmstcAmt: [''], outboundIntrnlAmt: [''],
      dcsAmt: ['']
    });
  };
  addRowData() {
    let obj = this.newRowData();
    obj['isEdit'] = true;
    obj['mode'] = 'ADD';
    this.rowData().push(obj);
  };
  getAdjustmentData() {
    this.fetchingReport = true;
    this.isDataFetched = false;
    let obj = {
      "custId": this.modalData.charges.CNTRCT_CUST_ID,
      "offrActnId": this.modalData.charges.OFFR_ACTN_ID,
      "offrId": this.modalData.charges.OFFR_ID,
      "offrEffDt": moment(this.modalData.charges.OFFR_EFF_DT).format('MM/DD/YYYY')
    };
    this.ccntmain.getAdjustmentData(obj).subscribe(resp => {
      this.rowData().clear();
      this.fetchingReport = false;
      this.isDataFetched = true;
      let topData = Object.assign({}, this.modalData.charges);
        topData['ctRefrnceSction'] = resp['ctRefrnceSction'];
        topData['adjmtId'] = resp['adjmtId'];
        this.topdataSource = new MatTableDataSource([topData]);
      if (!!resp && resp?.vTNSAdjustmnetnsModel?.length) {
        resp.vTNSAdjustmnetnsModel.forEach(row => {
          let obj = this.newRowData() as FormGroup;
          obj['edit'] = false;
          obj.patchValue(row);
          this.rowData().push(obj);
        });
      }
      this.dataSource = new MatTableDataSource(resp.vTNSAdjustmnetnsModel);
      this.changesDetect();
    }, error => {
      this.dataSource = new MatTableDataSource([]);
      this.fetchingReport = false;
      this.isDataFetched = true;
      this.notifService.showErrorNotification(error);
    });
  };
  changesDetect() {
    this.adjForm.valueChanges.subscribe(newValues => {
      this.isUpdated = true;
    });
  };
  selectFunc(value: any) {
    if (value.value == 0) {
      const dialogRef = this.dialog.open(ConfirmComponent, {
        data: {
          type: 2,
          content: 'Please select functionality to proceed'
        }
      });
      dialogRef.afterClosed().subscribe(result => { });
    }
    if (value.value == 1) {
      if (!this.dataSource.data || this.dataSource?.data?.length == 0) {
        this.addRowData();
      } else {
        const dialogRef = this.dialog.open(ConfirmComponent, {
          data: {
            type: 2,
            content: 'Adding a new blank row is not possible'
          }
        });
        dialogRef.afterClosed().subscribe(result => { });
      }
    } else if (value.value == 2) {
      if (!this.dataSource.data || this.dataSource?.data?.length == 0) {
        const dialogRef = this.dialog.open(ConfirmComponent, {
          data: {
            type: 2,
            content: 'Delete is not possible as no entries for this adjustment'
          }
        });
        dialogRef.afterClosed().subscribe(result => { });
      } else {
        const dialogRef = this.dialog.open(ConfirmComponent, {
          data: {
            type: 1,
            content: 'Are you sure you want to delete the entries for this adjustment?'
          }
        });
        dialogRef.afterClosed().subscribe(result => {
          if (result) {
            let tabData = [];
            this.adjForm.controls['rowData']['controls'].map((row, index) => {
              let rowData = row.controls as FormGroup;
              let obj = {
                "adjId": this.topdataSource.data[0]['adjmtId'],
                "billGroup": rowData['billGroup'].value,
                "dcsAmount": rowData['dcsAmt'].value,
                "inDomAmount": rowData['inboundDmstcAmt'].value,
                "inIntrAmount": rowData['inboundIntrnlAmt'].value,
                "invoiceDate": rowData['invoiceDate'].value,
                "mcn": rowData['mcn'].value,
                "mode": "DELETE",
                "outDomAmount": rowData['outboundDmstcAmt'].value,
                "outIntrAmount": rowData['outboundIntrnlAmt'].value,
                "totAmount": rowData['totalAmt'].value
              };
              tabData.push(obj);
            });
            let obj = {
              "customerId": this.modalData.charges.CNTRCT_CUST_ID,
              "offerActnId": this.modalData.charges.OFFR_ACTN_ID,
              "offerEffDate": moment(this.modalData.charges.OFFR_EFF_DT).format('MM/DD/YYYY'),
              "offerId": this.modalData.charges.OFFR_ID,
              "sourceId": this.modalData.custData.sourceId,
              "vtnsEntity": tabData,
              "webUserId": this.user.attuid
            }
            this.addDeleteAdjustments(obj);
          }
        });
      }
    }
  };

  saveAdjustment() {
    this.isSubmit = true;
    let tot_amnt = 0;
    let tot_amnt_1 = 0;
    let top_grid_amnt = this.modalData.charges.ADJMT_AT;
    let row_sum=0;
    for(let i=0; i<this.adjForm.controls['rowData']['controls'].length; i++){
      let rowData = this.adjForm.controls['rowData']['controls'][i].controls as FormGroup;
      let row_tot_amount = 0;
      tot_amnt = tot_amnt + parseInt(rowData['totalAmt'].value);
      row_tot_amount = parseInt(rowData['inboundDmstcAmt'].value == '' ? 0:rowData['inboundDmstcAmt'].value)+
                        parseInt(rowData['inboundIntrnlAmt'].value == '' ? 0:rowData['inboundIntrnlAmt'].value)+
                        parseInt(rowData['outboundDmstcAmt'].value == '' ? 0:rowData['outboundDmstcAmt'].value)+
                        parseInt(rowData['outboundIntrnlAmt'].value == '' ? 0:rowData['outboundIntrnlAmt'].value)+
                        parseInt(rowData['dcsAmt'].value == '' ? 0:rowData['dcsAmt'].value);
      row_sum = row_sum+row_tot_amount;
      if(row_tot_amount != parseInt(rowData['totalAmt'].value == '' ? 0:rowData['totalAmt'].value)) {
      alert("Total Amount does not equal Adjustment Breakout and should be a Numeric field");
       return false;
       break;
    } else if(tot_amnt == 0 || isNaN(tot_amnt)) {
      alert("Please enter a valid data for Total Amount");
        return false;
        break;
    }
    else if(isNaN(tot_amnt) || tot_amnt!=row_sum){
        alert("Total Amount does not equal Adjustment Breakout and should be a Numeric field");
        return false;
        break;
      }
      else {        
    Object.keys(rowData).forEach(key => {
      if (['dcsAmt', 'inboundDmstcAmt', 'inboundIntrnlAmt', 'outboundDmstcAmt', 'outboundIntrnlAmt'].includes(key) && rowData[key].value == "") {
        rowData[key].value = 0;
      }
    });
     
  }
  };
  if(tot_amnt!=top_grid_amnt){
    alert("Sum of Total Amounts do not equal Amount");
    return false;   
  } else {
    let tabData = [];
            this.adjForm.controls['rowData']['controls'].map((row, index) => {
              let rowData = row.controls as FormGroup;
              let obj = {
                "adjId": this.topdataSource.data[0]['adjmtId'],
                "billGroup": rowData['billGroup'].value,
                "dcsAmount": rowData['dcsAmt'].value,
                "inDomAmount": rowData['inboundDmstcAmt'].value,
                "inIntrAmount": rowData['inboundIntrnlAmt'].value,
                "invoiceDate": moment(rowData['invoiceDate'].value).format('MM/DD/YYYY'),
                "mcn": rowData['mcn'].value,
                "mode": "ADD",
                "outDomAmount": rowData['outboundDmstcAmt'].value,
                "outIntrAmount": rowData['outboundIntrnlAmt'].value,
                "totAmount": rowData['totalAmt'].value
              };
              tabData.push(obj);
            });
            let obj = {
              "customerId": this.modalData.charges.CNTRCT_CUST_ID,
              "offerActnId": this.modalData.charges.OFFR_ACTN_ID,
              "offerEffDate": moment(this.modalData.charges.OFFR_EFF_DT).format('MM/DD/YYYY'),
              "offerId": this.modalData.charges.OFFR_ID,
              "sourceId": this.modalData.custData.sourceId,
              "vtnsEntity": tabData,
              "webUserId": this.user.attuid
            }
            this.addDeleteAdjustments(obj);
  }
  
  };
  addDeleteAdjustments(obj: any) {
    this.fetchingReport = true;
    this.ccntmain.addDeleteAdjustments(obj).subscribe(resp => {
      this.fetchingReport = false;
      this.getAdjustmentData();
      if(!!resp){
        this.notifService.showSuccessNotification(resp);
      }
    }, error => {
      this.fetchingReport = false;
      this.notifService.showErrorNotification(error);
    });
  }
  // Only Numbers with Decimals
  keyPressNumbersDecimal(event) {
    var charCode = (event.which) ? event.which : event.keyCode;
    if (charCode != 46 && charCode > 31
      && (charCode < 48 || charCode > 57)) {
      event.preventDefault();
      return false;
    }
    return true;
  }
  close() {
    this.dialogRef.close();
  }
}

