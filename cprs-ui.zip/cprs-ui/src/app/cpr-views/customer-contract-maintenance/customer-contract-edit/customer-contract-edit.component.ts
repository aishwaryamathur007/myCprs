import { SelectionModel } from '@angular/cdk/collections';
import { ChangeDetectorRef, Component, ElementRef, OnInit, Renderer2 } from '@angular/core';
import { FormArray, FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import * as moment from 'moment'
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { CustomerContractMaintenanceService } from '../../service/customer-contract-maintenance.service';
import { MappingModalComponent } from '../mapping-modal/mapping-modal.component';
import { ConfirmComponent } from 'src/app/common/component/confirm/confirm.component';
import { UserService } from '../../../shared/service/user.service';
import { NotificationService } from 'src/app/common/services/notification.service';
import { ChargesComponent } from '../charges/charges.component';

@Component({
  selector: 'customer-contract-edit',
  templateUrl: './customer-contract-edit.component.html',
  styleUrls: ['./customer-contract-edit.component.scss']
})
export class CustomerContractEditComponent implements OnInit {
  fetchingReport: boolean = false;
  taskChange: boolean = false;
  terminateMode: any;
  terminatedDate: any;
  selectedTask = "1";
  customerInputs: any;
  activityTpe: any;
  unitCode: any;
  activityTypeDesc: any;
  prePostDiscount: any;
  newTopGridTask: boolean = false;
  newActGridTask: boolean = false;
  copyCustomer: boolean = false;
  copyActivity: boolean = false;
  terminate: boolean = false;
  unTerminate: boolean = false;
  inEdit: boolean = false;
  inEditable: boolean = false
  topGridObj: any = {};
  actGridObj: any = {};
  billCycle: any = [];
  services: any;
  selectedtaskValue: any;
  topGrid: MatTableDataSource<any>;
  actGrid: MatTableDataSource<any>;
  topGridForm: FormGroup;
  actGridForm: FormGroup;
  serviceMode: any;
  pageName:any;
  isUpdated: boolean = false;
  actGrid1: MatTableDataSource<any>;
  actGridColumns: string[] = ['actionsColumn', 'mapping', 'charges', 'OFFR_ACTN_ID', 'ACTN_DESC_SHRT_TX', 'ACTN_DESC_TX', 'CMNT_AT', 'CMNT_UNIT_TX', 'TRK_RVNU_TYPE_TX', 'OFFR_ACTN_STRT_MO', 'OFFR_ACTN_SCHED_STRT_MO', 'OFFR_ACTN_MSR_PRD_CD', "ACTN_SCHED_DT", "OFFR_ACTN_EXP_STRT_DT", "OFFR_ACTN_EXP_END_DT", 'TARF_REF_NM', 'TARF_REF_PG_NB']
  COLUMNS_SCHEMA = [
    {
      key: "isEdit",
      type: "isEdit",
      label: "Call To Action"
    },
    {
      key: "PRFR_CUST_NM",
      type: "text",
      label: "Customer Name",
      maxLength:100,
      method:this.keyPressAlphaNumeric
    },
    {
      key: "CNTRCT_CUST_ID",
      type: "text",
      label: "Customer Id",
      maxLength:21,
      method:this.keyPressAlphaNumeric
    },
    {
      key: "PARNT_CNTRCT_CUST_ID",
      type: "text",
      label: "Parent Customer Id",
      maxLength:21,
      method:this.keyPressAlphaNumeric
    },
    {
      key: "HQ_ACCT_ID",
      type: "text",
      label: "HQ Account",
      maxLength:21,
      method:this.keyPressAlphaNumeric
    },

    {
      key: "HQ_SLS_OFFC_CD",
      type: "text",
      label: "HQ Sales Office Code",
      maxLength:2,
      method:this.keyPressAlphaNumeric
    },
    {
      key: "HQ_BL_GP_CD",
      type: "text",
      label: "HQ Bill Group Code",
      maxLength:3,
      method:this.keyPressAlphaNumeric
    },
    {
      key: "EFF_STRT_DT",
      type: "date",
      label: "Customer Id Effective Date"
    },
    {
      key: "BL_CYC_NB",
      type: "select",
      label: "Bill Cycle"
    },
    {
      key: "OFFR_TYPE_DESC_TX",
      type: "select",
      label: "Service"
    },
    {
      key: "OFFR_ID",
      type: "text",
      label: "Offer Id",
      maxLength:16,
      method:this.keyPressAlphaNumeric
    },
    {
      key: "OFFR_EFF_DT",
      type: "date",
      label: "Effective Date"
    },
    {
      key: "CUST_OFFR_SCI_BY_DT",
      type: "date",
      label: "SCI by Date"
    }, {
      key: "CUST_OFFR_STRT_DT",
      type: "date",
      label: "Start Date"
    }, {
      key: "CUST_OFFR_SCHED_END_DT",
      type: "date",
      label: "Scheduled End Date"
    }, {
      key: "OFFR_TERM_MO_NB",
      type: "text",
      label: "Term Number of Months",
      maxLength:4,
      method:this.keyPressNumbers
    }, {
      key: "CUST_OFFR_END_DT",
      type: "date",
      label: "Terminated Date"
    }, {
      key: "DSCNCT_DT",
      type: "date",
      label: "Customer Id Disconnect Date"
    }
  ];
  topGridNewRow = {
    PRFR_CUST_NM: '', CNTRCT_CUST_ID: '', PARNT_CNTRCT_CUST_ID: '', HQ_ACCT_ID: '', HQ_SLS_OFFC_CD: '', HQ_BL_GP_CD: '',
    EFF_STRT_DT: '', BL_CYC_NB: '', OFFR_TYPE_DESC_TX: '', OFFR_ID: '', OFFR_EFF_DT: '',
    CUST_OFFR_SCI_BY_DT: '', CUST_OFFR_STRT_DT: '', CUST_OFFR_SCHED_END_DT: '', OFFR_TERM_MO_NB: '', CUST_OFFR_END_DT: '', DSCNCT_DT: ''
  };

  COLUMNS_SCHEMA1 = [
    {
      key: "editable",
      type: "editable",
      label: "Call To Action"
    },
    {
      key: "mapping",
      type: "mapping",
      label: "Mapping"
    },
    {
      key: "charges",
      type: "charges",
      label: "Charges"
    },
    {
      key: "OFFR_ACTN_ID",
      type: "text",
      label: "Activity Number"
    },
    {
      key: "ACTN_DESC_SHRT_TX",
      type: "select",
      label: "Activity Type"
    },
    {
      key: "ACTN_DESC_TX",
      type: "select",
      label: "Activity Type Description",
    },
    {
      key: "CMNT_AT",
      type: "text",
      label: "Amount"
    }, {
      key: "CMNT_UNIT_TX",
      type: "select",
      label: "Unit Code"
    }, {
      key: "TRK_RVNU_TYPE_TX",
      type: "select",
      label: "Pre/Post Discount"
    }, {
      key: "OFFR_ACTN_STRT_MO",
      type: "text",
      label: "Activity Start Month"
    }, {
      key: "OFFR_ACTN_SCHED_STRT_MO",
      type: "text",
      label: "Activity End Month"
    }, {
      key: "OFFR_ACTN_MSR_PRD_CD",
      type: "text",
      label: "Measure Period"
    }, {
      key: "ACTN_SCHED_DT",
      type: "date",
      label: "Activity Due month"
    }, {
      key: "OFFR_ACTN_EXP_STRT_DT",
      type: "date",
      label: "Expiration Start Date"
    }, {
      key: "OFFR_ACTN_EXP_END_DT",
      type: "date",
      label: "Expiration End Date"
    }, {
      key: "TARF_REF_NM",
      type: "text",
      label: "CT Reference"
    }, {
      key: "TARF_REF_PG_NB",
      type: "text",
      label: "CT Reference Page"
    }
  ];
  actGridNewRow = {
    editable: true, OFFR_ACTN_ID: '', ACTN_DESC_SHRT_TX: '', ACTN_DESC_TX: '', CMNT_AT: '', CMNT_UNIT_TX: '', TRK_RVNU_TYPE_TX: '', OFFR_ACTN_STRT_MO: '',
    OFFR_ACTN_SCHED_STRT_MO: '', OFFR_ACTN_MSR_PRD_CD: '', ACTN_SCHED_DT: '', OFFR_ACTN_EXP_STRT_DT: '', OFFR_ACTN_EXP_END_DT: '', TARF_REF_NM: '', TARF_REF_PG_NB: ''
  };
  topIndex: any;
  actIndex: any;
  submitted: boolean;
  copyCustomerData: boolean = false;

  constructor(private ccntmain: CustomerContractMaintenanceService, private notifService: NotificationService, private router: Router, private activeRouter: ActivatedRoute, private user: UserService,
    private dialog: MatDialog, private fb: FormBuilder, private cdr: ChangeDetectorRef, public el: ElementRef, public renderer: Renderer2, private _formBuilder: FormBuilder) {
    this.activeRouter.queryParams.subscribe(param => {
      this.customerInputs = Object.assign({}, param);
    });
    this.pageName = this.customerInputs.mode == 'edit' ? "Edit" : "Add"
    this.topGridForm = this.fb.group({
      PRFR_CUST_NM: ['', Validators.required], CNTRCT_CUST_ID: ['', Validators.required], PARNT_CNTRCT_CUST_ID: [''], HQ_ACCT_ID: ['', Validators.required], HQ_SLS_OFFC_CD: [''], HQ_BL_GP_CD: [''],
      EFF_STRT_DT: ['', Validators.required], BL_CYC_NB: ['', Validators.required], OFFR_TYPE_DESC_TX: ['', Validators.required], OFFR_ID: ['', Validators.required], OFFR_EFF_DT: ['', Validators.required],
      CUST_OFFR_SCI_BY_DT: [''], CUST_OFFR_STRT_DT: ['', Validators.required], CUST_OFFR_SCHED_END_DT: ['', Validators.required], OFFR_TERM_MO_NB: ['', Validators.required], CUST_OFFR_END_DT: [''], DSCNCT_DT: ['']
    });
    this.actGridForm = this.fb.group({
      OFFR_ACTN_ID: ['', Validators.required], ACTN_DESC_SHRT_TX: ['', Validators.required], ACTN_DESC_TX: ['', Validators.required], CMNT_AT: ['', Validators.required], CMNT_UNIT_TX: ['', Validators.required], TRK_RVNU_TYPE_TX: ['', Validators.required], OFFR_ACTN_STRT_MO: ['', Validators.required],
      OFFR_ACTN_SCHED_STRT_MO: ['', Validators.required], OFFR_ACTN_MSR_PRD_CD: ['', Validators.required], ACTN_SCHED_DT: ['', Validators.required], OFFR_ACTN_EXP_STRT_DT: [''], OFFR_ACTN_EXP_END_DT: [''], TARF_REF_NM: ['', Validators.required], TARF_REF_PG_NB: ['', Validators.required]
    });
    this.actGridForm1 = this.fb.group({
      PersonalData: this.fb.array([])
    });
  }

  ngOnInit(): void {
    this.fetchingReport = true;
    for (var i = 1; i <= 31; i++) {
      this.billCycle.push(JSON.stringify(i));
    }
    this.ccntmain.getActivityTypeDropdown().subscribe(activity => {
      this.activityTpe = activity;
    }, error => {
      this.notifService.showErrorNotification(error);
    });
    this.ccntmain.getUnitCodePrePostDiscount().subscribe(discount => {
      this.unitCode = discount['unitCode'];
      this.prePostDiscount = discount['prePostDiscount'];
    }, error => {
      this.notifService.showErrorNotification(error);
    });
    this.ccntmain.getServiceDropdown().subscribe(service => {
      this.services = service;
    }, error => {
      this.notifService.showErrorNotification(error);
    });
    if (this.customerInputs.mode == 'edit') {
    this.fetchData();
    } else {
      this.addNewData();
    }
  }

  fetchData() {
    this.fetchingReport=true;
    this.taskChange = false;
    this.selectedTask="0";
      let inputData = Object.assign({}, this.customerInputs)
      delete inputData.mode;
      this.ccntmain.getcustomerService(inputData).subscribe(cust => {
        this.fetchingReport = false;
        this.PersonalData().clear();
        if(cust && (cust.topGrid.length !=0 || cust.actGrid.length !=0)) {
        this.topGrid = new MatTableDataSource(cust.topGrid);
        this.actGrid1 = new MatTableDataSource(cust.actGrid);
        this.topGrid.data[0]['mode'] = '';
        this.topGridForm.patchValue(this.topGrid.data[0]);
        this.actGrid1.data.forEach(row => {
          let obj = this.newPersonalData() as FormGroup;
          obj['edit'] = false;
          obj.patchValue(row);
          this.PersonalData().push(obj);
        });
      } else {
        this.topGrid = new MatTableDataSource([]);
        this.actGrid1 = new MatTableDataSource([]);
      }
      }, error => {
        this.notifService.showErrorNotification(error);
        this.fetchingReport = false;
      });
  }
  addNewData() {
    this.fetchingReport = false;
    this.topGridNewRow["EFF_STRT_DT"] = new Date().toLocaleDateString();
    this.topGridNewRow["CUST_OFFR_SCHED_END_DT"] = 'System Generated';
    this.topGridNewRow['isEdit'] = true;
    this.topGridNewRow['BL_CYC_NB'] = '1';
    this.topGridNewRow['OFFR_TYPE_DESC_TX'] = 'ABN';
    this.topGridNewRow['mode'] = 'ADD';
    this.topGridForm.patchValue(this.topGridNewRow);
    this.newTopGridTask = true;
    this.newActGridTask = true;
    this.topGrid = new MatTableDataSource([this.topGridNewRow]);
    this.addPersonalData();
    this.isUpdated = true;
  }
  displayedColumns: string[] = this.COLUMNS_SCHEMA.map(col => col.key);
  columnsSchema: any = this.COLUMNS_SCHEMA;
  displayedColumns1: string[] = this.COLUMNS_SCHEMA1.map(col => col.key);
  columnsSchema1: any = this.COLUMNS_SCHEMA1;
  selection = new SelectionModel(true, []);

  setMode(mode: any) {
    this.serviceMode = mode;
  }
  editTopTable(ele: any) {
    this.topGridObj["EFF_STRT_DT"] = new Date().toLocaleDateString();
    this.topGridObj["CUST_OFFR_SCHED_END_DT"] = 'System Generated';
    ele.isEdit = true;
    this.isUpdated = true;
  }
  inEditTopTable(ele: any) {
    this.inEdit = true;
    ele['mode'] = 'UPDATESERVICE';
    this.topGridForm.patchValue(ele);
    this.isUpdated = true;
  }
  editActGridTable(ele: any) {
    this.inEditable = true;
    this.getActTypeDesc(ele.ACTN_DESC_SHRT_TX, ele, 2);
    ele.editable = true;
    this.isUpdated = true;
  }
  clearRowData(table: any,index:any) {
    if (table == 'topGrid') {
      this.topGrid.data = [];
      let newRow = Object.assign({}, this.topGridNewRow);
      newRow["EFF_STRT_DT"] = new Date().toLocaleDateString();
      newRow["CUST_OFFR_SCHED_END_DT"] = 'System Generated';
      newRow['isEdit'] = true;
      newRow['BL_CYC_NB'] = '1';
      newRow['OFFR_TYPE_DESC_TX'] = 'A';
      newRow['mode'] = 'ADD';
      this.topGrid.data = [...this.topGrid.data, newRow];
      this.topGridForm.patchValue(newRow);
    } else {
      // let control = this.actGridForm1.controls['PersonalData']['controls'][index] as FormArray;
      // Object.keys(control.controls).forEach(cell => {
      //   if(cell !='id' && cell !='mode' && cell !='checked'){
      //   control.controls[cell].value = "";
      //   }
      // });
    }
  };
  setExpActivity(date: any) {
    this.terminatedDate = date.target.value;
  };
  setDate(date:any) {
    let dt = new Date(date);
    return dt.toISOString();
  };
  setUnTerminate() {
    const dialogRef = this.dialog.open(ConfirmComponent, {
      data: {
        type: 1,
        content: 'Warning: The Offer ID you submitted is currently NOT in CADM! Do you still want to continue ?'
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.unTerminate = true;
        this.taskChange = true;
        this.topGridForm.patchValue(this.topGrid.data[0]);
        this.actGridForm1.controls['PersonalData']['controls'].map(row => {
        let rowData = row as FormGroup;
        rowData.controls["OFFR_ACTN_EXP_END_DT"].setValidators([Validators.required]);
        rowData.controls["OFFR_ACTN_EXP_END_DT"].updateValueAndValidity();
      });
    }
  });
}
  deleteActivity(ele: any) {
    const dialogRef = this.dialog.open(ConfirmComponent, {
      data: {
        type: 1,
        content: 'Please confirm if you want to proceed with the delete Activity'
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        let tempAct = {
          "actEndMnth": ele.value.OFFR_ACTN_SCHED_STRT_MO,
          "actStartMnth": ele.value.OFFR_ACTN_STRT_MO,
          "activityType": ele.value.ACTN_DESC_SHRT_TX,
          "activityTypeDesc": ele.value.ACTN_DESC_TX,
          "amount": ele.value.CMNT_AT,
          "ctRef": ele.value.TARF_REF_NM,
          "ctRefPage": ele.value.TARF_REF_PG_NB,
          "customerId": this.topGrid.data[0]['CNTRCT_CUST_ID'].trim(),
          "prePostDiscount": ele.value.TRK_RVNU_TYPE_TX,
          "unitCode": ele.value.CMNT_UNIT_TX,
          "offerActnId": ele.value.OFFR_ACTN_ID,
          "mode": "DELETE",
          'activityDueMnth': ele.value.ACTN_SCHED_DT ?? ''
        };
        let obj = {
          "activityEntity": [tempAct],
          "customerId": this.topGrid.data[0]['CNTRCT_CUST_ID'].trim(),
          "offerDate": this.customerInputs.offerDate ?? '',
          "offerId": this.customerInputs.offerId,
          "serviceEntity": {
              "billCycle": this.topGrid.data[0]['BL_CYC_NB'],
              "billGrpCd": this.topGrid.data[0]['HQ_BL_GP_CD'],
              "customerId": this.topGrid.data[0]['CNTRCT_CUST_ID'].trim(),
              "customerIdDisDt": this.topGrid.data[0]['DSCNCT_DT'] ? moment(this.topGrid.data[0]['DSCNCT_DT']).format('MM/DD/YYYY') :'',
              "customerIdEffDt": this.topGrid.data[0]['EFF_STRT_DT'] ? moment(new Date(this.topGrid.data[0]['EFF_STRT_DT'])).format('MM/DD/YYYY') : '',
              "customerNm": this.topGrid.data[0]['PRFR_CUST_NM'].trim(),
              "effDate": this.topGrid.data[0]['OFFR_EFF_DT'] ? moment(this.topGrid.data[0]['OFFR_EFF_DT']).format('MM/DD/YYYY') : '',
              "hqAccount": this.topGrid.data[0]['HQ_ACCT_ID'],
              "offerId": this.topGrid.data[0]['OFFR_ID'].trim(),
              "parentCustomerId": this.topGrid.data[0]['PARNT_CNTRCT_CUST_ID'],
              "salesOfcCd": this.topGrid.data[0]['HQ_SLS_OFFC_CD'],
              "schEndDt": this.topGrid.data[0]['CUST_OFFR_SCHED_END_DT'] ? moment(this.topGrid.data[0]['CUST_OFFR_SCHED_END_DT']).format('MM/DD/YYYY') : '',
              "sciByDate": this.topGrid.data[0]['CUST_OFFR_SCI_BY_DT'] ? moment(this.topGrid.data[0]['CUST_OFFR_SCI_BY_DT']).format('MM/DD/YYYY') : '',
              "service": this.topGrid.data[0]['OFFR_TYPE_DESC_TX'],
              "startDt": this.topGrid.data[0]['CUST_OFFR_STRT_DT'] ? moment(this.topGrid.data[0]['CUST_OFFR_STRT_DT']).format('MM/DD/YYYY') : '',
              "termNoOfMnths": this.topGrid.data[0]['OFFR_TERM_MO_NB'],
              "terminatedDt": this.topGrid.data[0]['CUST_OFFR_END_DT'] ? moment(this.topGrid.data[0]['CUST_OFFR_END_DT']).format('MM/DD/YYYY') : '',
              "mode": ""
            },
          "sourceId": this.customerInputs.sourceId,
          "webUserId": this.user.attuid
        }
        this.editedServiceData(obj);
      }
    });
  };
  serviceEdit() {
    let submitApi = true;
    this.submitted = true;
    if (this.unTerminate && this.topGridForm.valid && this.actGridForm1.valid) {
    //   if (this.unTerminate && !this.topGrid.data[0]['CUST_OFFR_END_DT']) {
    //   const dialogRef = this.dialog.open(ConfirmComponent, {
    //     data: {
    //       type: 2,
    //       content: 'Cannot be Unterminated as it is not being terminated before'
    //     }
    //   });
    //   dialogRef.afterClosed().subscribe(result => {
    //     this.actGridForm1.controls['PersonalData']['controls'].map((row: any) => {
    //       let rowData = row.controls as FormGroup;
    //       rowData['OFFR_ACTN_EXP_END_DT'].setValue('');
    //     });
    //     this.taskChange = false;
    //   });
    //   submitApi = false;
    //   return;
    // } else if(this.unTerminate && this.topGridForm.valid && this.actGridForm1.valid){
      this.terminateMode = 'UNTERMINATE'; 
      this.terminateUnterminate();
      submitApi = false;
      return;
    // }
  }
    if (this.actGridForm1.invalid || this.topGridForm.invalid) {
      const dialogRef = this.dialog.open(ConfirmComponent, {
        data: {
          type: 2,
          content: 'Please fill the required Fields.'
        }
      });
      dialogRef.afterClosed().subscribe(result => {
      });
      submitApi = false;
      return;
    }
    if (this.terminate) {
      this.terminateMode = 'TERMINATE';
      const dialogRef = this.dialog.open(ConfirmComponent, {
        data: {
          type: 1,
          content: 'Do you want to terminate all activites ?'
        }
      });
      dialogRef.afterClosed().subscribe(result => {
        if (result) {
          this.actGridForm1.controls['PersonalData']['controls'].map((row, index) => {
            let rowData = row.controls as FormGroup;
            rowData['OFFR_ACTN_EXP_STRT_DT'].setValue(this.terminatedDate);
            row.value['OFFR_ACTN_EXP_STRT_DT'] = this.terminatedDate;
          });
          this.terminateUnterminate();
        } else {
          this.topGridForm.controls["CUST_OFFR_END_DT"].setValue(null);
          this.setFalse();
          this.terminateMode = "";
          this.topGrid.data[0]['mode'] = "";
        }
      });
      submitApi = false;
    }
    // if(this.newTopGridTask && this.topGridForm.controls['CNTRCT_CUST_ID'].value.trim() == this.topGrid.data[0]['CNTRCT_CUST_ID'].trim()) {
    //   const dialogRef = this.dialog.open(ConfirmComponent, {
    //     data: {
    //       type: 1,
    //       content: 'The Customer with Contract Cust ID  already exists'
    //     }
    //   });
    //   dialogRef.afterClosed().subscribe(result => {
    //     return false;
    //   });
    //   submitApi = false;
    // }
    // if(this.newTopGridTask && this.topGridForm.controls['OFFR_ID'].value.trim() == this.topGrid.data[0]['OFFR_ID'].trim()) {
    //   const dialogRef = this.dialog.open(ConfirmComponent, {
    //     data: {
    //       type: 1,
    //       content: 'The Offer ID already exists'
    //     }
    //   });
    //   dialogRef.afterClosed().subscribe(result => {
    //     return false;
    //   });
    //   submitApi = false;
    // }
    if (submitApi) {
      let tempAct = [];
      this.actGridForm1.controls['PersonalData']['controls'].map((row: any) => {
        let rowData = row.controls as FormGroup;
        if(rowData['checked'].value) {
          let obj = {
            "actEndMnth": rowData['OFFR_ACTN_SCHED_STRT_MO'].value,
            "actStartMnth": rowData['OFFR_ACTN_STRT_MO'].value,
            "activityType": rowData['ACTN_DESC_SHRT_TX'].value,
            "activityTypeDesc": rowData['ACTN_DESC_TX'].value,
            "amount": rowData['CMNT_AT'].value,
            "ctRef": rowData['TARF_REF_NM'].value,
            "ctRefPage": rowData['TARF_REF_PG_NB'].value,
            "customerId": this.topGridForm.controls['CNTRCT_CUST_ID'].value.trim(),
            "prePostDiscount": rowData['TRK_RVNU_TYPE_TX'].value,
            "unitCode": rowData['CMNT_UNIT_TX'].value,
            "offerActnId": rowData['OFFR_ACTN_ID'].value,
            "mode": rowData['mode'].value,
            'activityDueMnth': rowData['ACTN_SCHED_DT'].value ?? ''
          };
          if(this.copyCustomerData) {
            obj['prevOffrActnId'] = rowData['OFF_ACT_ID'].value;
          } 
        tempAct.push(obj);       
      }
      });
      let obj = {
        "activityEntity": tempAct,
        "customerId": this.topGridForm.controls['CNTRCT_CUST_ID'].value.trim(),
        "offerDate": this.customerInputs.offerDate ?? "",
        "offerId": this.customerInputs.offerId ?? "",
        "serviceEntity": {
            "billCycle": this.topGridForm.controls['BL_CYC_NB'].value,
            "billGrpCd": this.topGridForm.controls['HQ_BL_GP_CD'].value,
            "customerId": this.topGridForm.controls['CNTRCT_CUST_ID'].value.trim() ?? '',
            "customerIdDisDt": this.topGridForm.controls['DSCNCT_DT'].value ? moment(this.topGridForm.controls['DSCNCT_DT'].value).format('MM/DD/YYYY') : '',
            "customerIdEffDt": this.topGridForm.controls['EFF_STRT_DT'].value ? moment(new Date(this.topGridForm.controls['EFF_STRT_DT'].value)).format('MM/DD/YYYY') : '',
            "customerNm": this.topGridForm.controls['PRFR_CUST_NM'].value.trim(),
            "effDate": this.topGridForm.controls['OFFR_EFF_DT'].value ? moment(this.topGridForm.controls['OFFR_EFF_DT'].value).format('MM/DD/YYYY') : '',
            "hqAccount": this.topGridForm.controls['HQ_ACCT_ID'].value,
            "offerId": this.topGridForm.controls['OFFR_ID'].value.trim(),
            "parentCustomerId": this.topGridForm.controls['PARNT_CNTRCT_CUST_ID'].value,
            "salesOfcCd": this.topGridForm.controls['HQ_SLS_OFFC_CD'].value,
            "schEndDt": this.topGridForm.controls['CUST_OFFR_SCHED_END_DT'].value ?? '',
            "sciByDate": this.topGridForm.controls['CUST_OFFR_SCI_BY_DT'].value ? moment(this.topGridForm.controls['CUST_OFFR_SCI_BY_DT'].value).format('MM/DD/YYYY') : '',
            "service": this.topGridForm.controls['OFFR_TYPE_DESC_TX'].value,
            "startDt": this.topGridForm.controls['CUST_OFFR_STRT_DT'].value ? moment(this.topGridForm.controls['CUST_OFFR_STRT_DT'].value).format('MM/DD/YYYY') : '',
            "termNoOfMnths": this.topGridForm.controls['OFFR_TERM_MO_NB'].value,
            "terminatedDt": this.topGridForm.controls['CUST_OFFR_END_DT'].value ? moment(this.topGridForm.controls['CUST_OFFR_END_DT'].value).format('MM/DD/YYYY') : '',
            "mode": this.topGrid.data[0]['mode']
          },
        "sourceId": this.customerInputs.sourceId ?? "",
        "webUserId": this.user.attuid
      };
      console.log(obj);
      this.editedServiceData(obj);
      this.copyCustomerData = false;
    }
  };
  terminateUnterminate() {
    this.fetchingReport = true;
    let actvity = [];
    this.actGridForm1.controls['PersonalData']['controls'].map((row: any) => {
      let rowData = row.controls as FormGroup;
      actvity.push({
        "expirEndDate": rowData['OFFR_ACTN_EXP_END_DT'].value ? moment(new Date(rowData['OFFR_ACTN_EXP_END_DT'].value)).format('MM/DD/YYYY') : '',
        "expirStartDate": this.topGridForm.controls['CUST_OFFR_END_DT'].value ? moment(new Date(this.topGridForm.controls['CUST_OFFR_END_DT'].value)).format('MM/DD/YYYY') : '',
        "offerActnId": rowData['OFFR_ACTN_ID'].value
      });

    });
    let term = {
      "activeGridEntity": actvity,
      "addCustService": '',
      "customerId": this.topGrid.data[0]['CNTRCT_CUST_ID'].trim(),
      "mode": this.terminateMode,
      "offerDate": this.customerInputs.offerDate,
      "offerId": this.topGrid.data[0]['OFFR_ID'].trim(),
      "sourceId": this.customerInputs.sourceId,
      "terminationDate": this.topGridForm.controls['CUST_OFFR_END_DT'].value ? moment(new Date(this.topGridForm.controls['CUST_OFFR_END_DT'].value)).format('MM/DD/YYYY') : '',
      "webUserId": this.user.attuid
    };
    this.actGridForm1.disable();
    this.topGridForm.disable();
    this.ccntmain.terminateUntermService(term).subscribe(term => {
      if(!!term) {
        this.notifService.showSuccessNotification(term);
      }
      this.fetchingReport = false;
      this.actGridForm1.enable();
      this.topGridForm.enable();
      this.setFalse();
      this.fetchData();
    }, error => {
      this.notifService.showErrorNotification(error);
      this.setFalse();
      this.fetchingReport = false;
    });
  };
  setFalse() {
    this.newTopGridTask = false;
    this.newActGridTask = false;
    this.copyCustomer = false;
    this.copyActivity = false;
    this.terminate = false;
    this.unTerminate = false;
    this.inEdit = false;
    this.inEditable = false;
    this.submitted = false;
    this.isUpdated = false;
    this.topGridForm.controls["CUST_OFFR_END_DT"].setValidators([]);
    this.topGridForm.controls["CUST_OFFR_END_DT"].updateValueAndValidity();
    this.actGridForm1.clearAsyncValidators();
  };
  editedServiceData(obj: any) {
    this.actGridForm1.disable();
    this.topGridForm.disable();
    this.fetchingReport = true;
    this.isUpdated = false;
    this.ccntmain.customerServiceEdit(obj).subscribe(service => {
      this.fetchingReport = false;
      this.actGridForm1.enable();
      this.topGridForm.enable();
      this.setFalse();
      if(!!service) {
        (service).includes('Already') ? this.notifService.showWarningNotification(service) : this.notifService.showSuccessNotification(service);
      if(this.customerInputs.mode == "add") {
        this.router.navigate(['/customer-contract/customer-contract-maintenance']);
      } else {
        this.fetchData();
        this.setFalse();
      }
    }
    this.isUpdated = true;
    }, error => {
      this.actGridForm1.enable();
      this.topGridForm.enable();
      this.notifService.showErrorNotification(error);
      this.fetchingReport = false;
      this.setFalse();
    });
  };
  getMapping(activity: any) {
    const dialogRef = this.dialog.open(MappingModalComponent, {
      data: {
        customerId: this.customerInputs.customerId,
        offerActnId: this.copyCustomerData ? activity.controls['OFF_ACT_ID'].value : activity.controls['OFFR_ACTN_ID'].value,
        offerEffDate: moment(new Date(this.topGrid.data[0]['OFFR_EFF_DT'])).format('MM/DD/YYYY'),
        offerId: this.customerInputs.offerId,
        // offerStartDate: this.topGrid.data[0]['CUST_OFFR_STRT_DT'],
        sourceId: this.customerInputs.sourceId
      },
      disableClose: true,
      width: '95%',
      maxWidth:'100vw',
      maxHeight:'95vh',
      panelClass: 'resize-modalbox'
      // height:'90%'
    });

    dialogRef.afterClosed().subscribe(val => {
      if (val) {

      }
    });
  };
  getCharges(charge: any) {
    const dialogRef = this.dialog.open(ChargesComponent, {
      data: {
        custData: this.customerInputs,
        actGrid: charge.value,
        topGrid: this.topGrid.data[0]        
      },
      width: '70%',
      disableClose: true,
      panelClass: 'resize-modalbox'
    });

    dialogRef.afterClosed().subscribe(val => {
      if (val) {

      }
    });
  };

  //validation form settings
  actGridForm1: FormGroup;
  PersonalData(): FormArray {
    return this.actGridForm1.get('PersonalData') as FormArray;
  };
  newPersonalData(): FormGroup {
    return this.fb.group({
      id: '', activityTypeDesc: [''], mode: '',checked:'',unitCode:[''],ACTN_TYPE_ID:'',VTNS_CHILD_IND:'',OFF_ACT_ID:'',ACTN_SCHED_DT_COPY:'',
      OFFR_ACTN_ID: ['System Generated'], ACTN_DESC_SHRT_TX: [''], ACTN_DESC_TX: [''], CMNT_AT: [''], CMNT_UNIT_TX: [''], TRK_RVNU_TYPE_TX: [''], OFFR_ACTN_STRT_MO: [''],
      OFFR_ACTN_SCHED_STRT_MO: [''], OFFR_ACTN_MSR_PRD_CD: ['System Generated'], ACTN_SCHED_DT: ['System Generated'], OFFR_ACTN_EXP_STRT_DT: [''], OFFR_ACTN_EXP_END_DT: [''], TARF_REF_NM: [''], TARF_REF_PG_NB: ['']
    });
  };
  addPersonalData() {
    let obj = this.newPersonalData();
    obj.controls = this.setValidations(obj.controls);
    obj.controls['OFFR_ACTN_ID'].disable();
    obj.controls['checked'].disable();
    obj.controls['OFFR_ACTN_MSR_PRD_CD'].disable();
    obj.controls['ACTN_SCHED_DT'].disable();
    obj.controls['OFFR_ACTN_EXP_STRT_DT'].disable();
    obj.controls['OFFR_ACTN_EXP_END_DT'].disable();
    obj['edit'] = true;
    obj.controls['checked'].setValue(true);
    if(this.topGrid.data[0] && this.topGrid.data[0]['mode'] != 'ADD') {
      obj.controls['mode'].setValue('ADD');
    };
    this.selectedTask="0";
    this.PersonalData().push(obj);
  };
  inEditActTable(ele: any, i: number) {
    this.fetchingReport = true;
    let obj = { activityType: ele.value.ACTN_DESC_SHRT_TX };
    ele['edit'] = true;
    this.isUpdated = true;
    let unitObj = { activityType: ele.value.ACTN_DESC_SHRT_TX,activityDesc:ele.value.ACTN_DESC_TX };
    let unitData:any;
    this.ccntmain.getUnitCode(unitObj).subscribe(unit => {
      unitData = unit;
    }, error => {
      this.notifService.showErrorNotification(error);
    });
    this.ccntmain.getActivityDescDropdown(obj).subscribe(act => {
      let control = this.actGridForm1.controls['PersonalData']['controls'][i].controls as FormGroup;
      control = this.setValidations(control);
      control['mode'].setValue('UPDATEACTIVITY');
      control['OFFR_ACTN_ID'].disable();
      control['OFFR_ACTN_MSR_PRD_CD'].disable();
      control['ACTN_SCHED_DT'].disable();
      control['OFFR_ACTN_EXP_STRT_DT'].disable();
      control['checked'].value = true;
      if (this.unTerminate) {
        control['OFFR_ACTN_EXP_END_DT'].enable();
      } else {
        control['OFFR_ACTN_EXP_END_DT'].disable();
      }
      control['activityTypeDesc'].value = act;
      control['unitCode'].value = unitData;
      this.fetchingReport = false;
    }, error => {
      this.notifService.showErrorNotification(error);
    });
  };
  getActTypeDesc(activity: any, ele: any, index: number) {
    this.fetchingReport = true;
    let obj = { activityType: activity.value };
    this.ccntmain.getActivityDescDropdown(obj).subscribe(act => {
      let control = this.actGridForm1.controls['PersonalData']['controls'][index].controls as FormGroup;
      this.fetchingReport = false;
      //control['ACTN_DESC_TX'].setValue(act[0]);
      control['activityTypeDesc'].value = act;      
      this.getUnitCode(activity,ele, index,true);
    }, error => {
      this.notifService.showErrorNotification(error);
    });
  };
  getUnitCode(activity: any, ele: any, index: number,cond?) {
    let unitObj:any;
    if(cond && !ele.value) {
      unitObj = { activityType: ele['ACTN_DESC_SHRT_TX'].value,activityDesc:ele['ACTN_DESC_TX'].value }; 
    } else {
     unitObj = { activityType: ele.value.ACTN_DESC_SHRT_TX,activityDesc:ele.value.ACTN_DESC_TX }; 
    } 
    this.fetchingReport = true;
    if(unitObj) {
    this.ccntmain.getUnitCode(unitObj).subscribe(unitcode => {
      let control = this.actGridForm1.controls['PersonalData']['controls'][index].controls as FormGroup;
      this.fetchingReport = false;
      control['CMNT_UNIT_TX'].setValue(unitcode[0]);
      control['unitCode'].value = unitcode;
    }, error => {
      this.notifService.showErrorNotification(error);
    });
  }
  }
  setValidations(control:any) {
    control['OFFR_ACTN_STRT_MO'].setValidators([Validators.required]);
    control['OFFR_ACTN_STRT_MO'].updateValueAndValidity();
    control['ACTN_DESC_SHRT_TX'].setValidators([Validators.required]);
    control['ACTN_DESC_SHRT_TX'].updateValueAndValidity();
    control['ACTN_DESC_TX'].setValidators([Validators.required]);
    control['ACTN_DESC_TX'].updateValueAndValidity();
    control['CMNT_AT'].setValidators([Validators.required]);
    control['CMNT_AT'].updateValueAndValidity();
    control['CMNT_UNIT_TX'].setValidators([Validators.required]);
    control['CMNT_UNIT_TX'].updateValueAndValidity();
    control['TRK_RVNU_TYPE_TX'].setValidators([Validators.required]);
    control['TRK_RVNU_TYPE_TX'].updateValueAndValidity();
    control['OFFR_ACTN_SCHED_STRT_MO'].setValidators([Validators.required]);
    control['OFFR_ACTN_SCHED_STRT_MO'].updateValueAndValidity();
    control['OFFR_ACTN_MSR_PRD_CD'].setValidators([Validators.required]);
    control['OFFR_ACTN_MSR_PRD_CD'].updateValueAndValidity();
    control['ACTN_SCHED_DT'].setValidators([Validators.required]);
    control['ACTN_SCHED_DT'].updateValueAndValidity();
    control['TARF_REF_NM'].setValidators([Validators.required]);
    control['TARF_REF_NM'].updateValueAndValidity();
    control['TARF_REF_PG_NB'].setValidators([Validators.required]);
    control['TARF_REF_PG_NB'].updateValueAndValidity();
    return control;
  }
  removeValidations(control:any) {
    control['OFFR_ACTN_STRT_MO'].setValidators([]);
    control['OFFR_ACTN_STRT_MO'].updateValueAndValidity();
    control['ACTN_DESC_SHRT_TX'].setValidators([]);
    control['ACTN_DESC_SHRT_TX'].updateValueAndValidity();
    control['ACTN_DESC_TX'].setValidators([]);
    control['ACTN_DESC_TX'].updateValueAndValidity();
    control['CMNT_AT'].setValidators([]);
    control['CMNT_AT'].updateValueAndValidity();
    control['CMNT_UNIT_TX'].setValidators([]);
    control['CMNT_UNIT_TX'].updateValueAndValidity();
    control['TRK_RVNU_TYPE_TX'].setValidators([]);
    control['TRK_RVNU_TYPE_TX'].updateValueAndValidity();
    control['OFFR_ACTN_SCHED_STRT_MO'].setValidators([]);
    control['OFFR_ACTN_SCHED_STRT_MO'].updateValueAndValidity();
    control['OFFR_ACTN_MSR_PRD_CD'].setValidators([]);
    control['OFFR_ACTN_MSR_PRD_CD'].updateValueAndValidity();
    control['ACTN_SCHED_DT'].setValidators([]);
    control['ACTN_SCHED_DT'].updateValueAndValidity();
    control['TARF_REF_NM'].setValidators([]);
    control['TARF_REF_NM'].updateValueAndValidity();
    control['TARF_REF_PG_NB'].setValidators([]);
    control['TARF_REF_PG_NB'].updateValueAndValidity();
    return control;
  };
  selectCheckBox(obj:any) {
    let control = obj.controls as FormGroup;
    if(control['checked'].value) {
      this.setValidations(control);
    } else {
      this.removeValidations(control);
    }
  }
  selectTask(task: any) {
    this.setFalse();
    this.isUpdated = true;
    if (task == 1) {
      this.selectedTask="0";
      this.topGrid.data = [];
      let newRow = Object.assign({}, this.topGridNewRow);
      newRow["EFF_STRT_DT"] = new Date().toLocaleDateString();
      newRow["CUST_OFFR_SCHED_END_DT"] = 'System Generated';
      newRow['isEdit'] = true;
      newRow['BL_CYC_NB'] = '1';
      newRow['OFFR_TYPE_DESC_TX'] = 'A';
      newRow['mode'] = 'ADD';
      this.topGrid.data = [...this.topGrid.data, newRow];
      this.topGridForm.patchValue(newRow);
      this.newTopGridTask = true;
      this.PersonalData().clear();
      this.addPersonalData();
      this.newActGridTask = true;
      this.router.navigate([], { relativeTo: this.activeRouter, queryParams: {mode:'add'} });
    } else if (task == 2) {
      if(this.topGrid.data[0]['CUST_OFFR_END_DT']) {
        const dialogRef = this.dialog.open(ConfirmComponent, {
          data: {
            type: 2,
            content: 'Can not add an activity to a terminated customer service'
          }
        });
        dialogRef.afterClosed().subscribe(result => {
          this.isUpdated = false;
          this.taskChange = false;
        });
        return false;
      } else {
      this.addPersonalData();
      }
    } else if (task == 3) {
      if(this.topGrid.data[0]['CNTRCT_CUST_ID']){
      this.copyCustomerData = true;
      let copyRow = Object.assign({}, this.topGrid.data[0]);
      copyRow['CUST_OFFR_SCHED_END_DT'] = 'System Generated';
      copyRow['CUST_OFFR_STRT_DT'] = copyRow['CUST_OFFR_STRT_DT'] ? new Date(copyRow['CUST_OFFR_STRT_DT']) : copyRow['CUST_OFFR_STRT_DT'];
      copyRow['OFFR_EFF_DT'] =copyRow['OFFR_EFF_DT'] ? new Date(copyRow['OFFR_EFF_DT']) : copyRow['OFFR_EFF_DT'];
      copyRow['CUST_OFFR_SCI_BY_DT'] = copyRow['CUST_OFFR_SCI_BY_DT'] ? new Date(copyRow['CUST_OFFR_SCI_BY_DT']) : copyRow['CUST_OFFR_SCI_BY_DT'];
      copyRow['isEdit'] = true;
      copyRow['mode']="ADD";
      this.topGrid.data = [];
      this.topGrid.data = [...this.topGrid.data, copyRow];
      this.topGridForm.patchValue(copyRow);
      this.newTopGridTask = true;
      this.copyCustomer = true;
      this.actGridForm1.controls['PersonalData']['controls'].map((row, index) => {
        row['edit'] = true;
        let rowData = row.controls as FormGroup;
        rowData = this.setValidations(rowData);
        this.getActTypeDesc(rowData['ACTN_DESC_SHRT_TX'], rowData, index);
        // rowData['activityTypeDesc'].value = ;
        rowData['OFFR_ACTN_ID'].disable();
        // rowData['checked'].disable();
        rowData['OFFR_ACTN_MSR_PRD_CD'].disable();
        rowData['ACTN_SCHED_DT'].disable();
        rowData['OFF_ACT_ID'].value = JSON.parse(JSON.stringify(rowData['OFFR_ACTN_ID'].value));
        rowData['OFFR_ACTN_ID'].value = 'System Generated';
        rowData['OFFR_ACTN_MSR_PRD_CD'].value = 'System Generated';
        rowData['ACTN_SCHED_DT_COPY'].value = JSON.parse(JSON.stringify(rowData['ACTN_SCHED_DT'].value));
        rowData['ACTN_SCHED_DT'].value = 'System Generated';
        rowData['OFFR_ACTN_EXP_STRT_DT'].disable();
        rowData['OFFR_ACTN_EXP_END_DT'].disable();
        rowData['mode'].value = '';
        rowData['checked'].value = true;
      });
      this.taskChange = true;
    } else {
      return false;
    }
    } else if (task == 4) {
      if(this.topGrid.data[0]['CUST_OFFR_END_DT']) {
        const dialogRef = this.dialog.open(ConfirmComponent, {
          data: {
            type: 2,
            content: 'Can not add/copy an activity to a terminated customer service'
          }
        });
        dialogRef.afterClosed().subscribe(result => {
          this.isUpdated = false;
          this.taskChange = false;
        });
        return false;
      } else {
      let selectedRows = this.actGridForm1.controls['PersonalData']['controls'].filter(item => {
        if(item['controls']['checked'].value == true && item['controls']['OFFR_ACTN_ID'].value != 'System Generated') {
          return item;
        }
        });
      if(selectedRows.length){ 
      this.taskChange = true;
      this.copyActivity = true;
      this.actGridForm1.controls['PersonalData']['controls'].map(async row => {
        let obj = { activityType: row.value.ACTN_DESC_SHRT_TX };
        if(row.controls['checked'].value && row.controls['OFFR_ACTN_ID'].value != 'System Generated') {
          let unitObj = { activityType: row.value.ACTN_DESC_SHRT_TX,activityDesc:row.value.ACTN_DESC_TX };
          let unitCode = await this.ccntmain.getUnitCode(unitObj).toPromise();
          this.ccntmain.getActivityDescDropdown(obj).subscribe(act => {            
          let obj = this.newPersonalData() as FormGroup;
          obj.controls = this.setValidations(obj.controls);
          let ele = Object.assign({},row.value);
          obj.patchValue(ele);
          obj['edit'] = true;
          obj.controls['checked'].setValue(true);
          obj.controls['activityTypeDesc'].setValue(act);
          obj.controls['unitCode'].setValue(unitCode);
          obj.controls['OFFR_ACTN_ID'].disable();
          obj.controls['OFFR_ACTN_MSR_PRD_CD'].disable();
          obj.controls['ACTN_SCHED_DT'].disable();
          obj.controls['OFFR_ACTN_ID'].setValue('System Generated');
          obj.controls['OFFR_ACTN_MSR_PRD_CD'].setValue('System Generated');
          obj.controls['ACTN_SCHED_DT'].setValue('System Generated');
          obj.controls['OFFR_ACTN_EXP_STRT_DT'].disable();
          obj.controls['OFFR_ACTN_EXP_END_DT'].disable();
          obj.controls['mode'].setValue('ADD');
          this.PersonalData().push(obj);
          });
        } 
      });
    } else {
      const dialogRef = this.dialog.open(ConfirmComponent, {
        data: {
          type: 2,
          content: 'Please select the row on Activity Grid to be Copied'
        }
      });
      dialogRef.afterClosed().subscribe(result => {
        if (result) {
          this.taskChange = false;
          this.selectedTask="0";
          this.isUpdated = false;
        }
      });
    }
  }
    } else if (task == 5) {
      if(this.topGrid.data[0]['CNTRCT_CUST_ID']){
      if(this.topGrid.data[0]['CUST_OFFR_END_DT']) {
        const dialogRef = this.dialog.open(ConfirmComponent, {
          data: {
            type: 2,
            content: 'The Customer already Terminated, it cannot be terminated'
          }
        });
        dialogRef.afterClosed().subscribe(result => {
          this.isUpdated = false;
          this.taskChange = false;
        });
        return false;
      } else {
      this.terminate = true;
      this.topGridForm.patchValue(this.topGrid.data[0]);
      this.topGridForm.controls["CUST_OFFR_END_DT"].setValidators([Validators.required]);
      this.topGridForm.controls["CUST_OFFR_END_DT"].updateValueAndValidity();
      this.topGrid.data[0]['mode'] = 'TERMINATE';
      this.actGridForm1.controls['PersonalData']['controls'].map(row => {
        row.disable();
      });
    }
  } else {
    return false;
  }
    } else if (task == 6) {
      if(this.topGrid.data[0]['CUST_OFFR_END_DT']) {
        this.topGridForm.controls["CUST_OFFR_END_DT"].setValidators([]);
        this.topGridForm.controls["CUST_OFFR_END_DT"].updateValueAndValidity();
        this.setUnTerminate();
        this.topGrid.data[0]['mode'] = 'UNTERMINATE';
        this.taskChange = true;
      } else {
        const dialogRef = this.dialog.open(ConfirmComponent, {
          data: {
            type: 2,
            content: 'Cannot be Unterminated as it is not being terminated before'
          }
        });
        dialogRef.afterClosed().subscribe(result => {
          this.isUpdated = false;
          this.actGridForm1.controls['PersonalData']['controls'].map((row: any) => {
            let rowData = row.controls as FormGroup;
            rowData['OFFR_ACTN_EXP_END_DT'].setValue('');
          });
          this.taskChange = false;
        });
        return false;
      }
      
    }
  }
// Only AlphaNumeric with Some Characters [-_ ]
keyPressAlphaNumericWithCharacters(event) {

  var inp = String.fromCharCode(event.keyCode);
  // Allow numbers, alpahbets, space, underscore
  if (/[a-zA-Z0-9-_ ]/.test(inp)) {
    return true;
  } else {
    event.preventDefault();
    return false;
  }
}
// Only AlphaNumeric
keyPressAlphaNumeric(event) {

  var inp = String.fromCharCode(event.keyCode);

  if (/[a-zA-Z0-9\s]/.test(inp)) {
    return true;
  } else {
    event.preventDefault();
    return false;
  }
}
// Only Numbers with Decimals
keyPressNumbersDecimal(event) {
  var charCode = (event.which) ? event.which : event.keyCode;
  if (charCode != 46 && charCode > 31
    && (charCode < 48 || charCode > 57)) {
    event.preventDefault();
    return false;
  }
  return true;
}
// Only Integer Numbers
keyPressNumbers(event) {
  var charCode = (event.which) ? event.which : event.keyCode;
  // Only Numbers 0-9
  if ((charCode < 48 || charCode > 57)) {
    event.preventDefault();
    return false;
  } else {
    return true;
  }
}
onPaste(event: ClipboardEvent,ele:any) {
  let txt = event.clipboardData.getData('text/plain');
  if(ele == 'ref') {
  let numberPattern = new RegExp(/^[0-9]+([.]{1}[0-9]+)?$/);
    if(!numberPattern.test(txt)) return false;
  } else {
    let numberPattern = new RegExp(/\d+/g);
    if(!numberPattern.test(txt)) return false;
  }
} 
}
