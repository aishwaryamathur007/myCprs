import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerContractEditComponent } from './customer-contract-edit.component';

describe('CustomerContractEditComponent', () => {
  let component: CustomerContractEditComponent;
  let fixture: ComponentFixture<CustomerContractEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerContractEditComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerContractEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
