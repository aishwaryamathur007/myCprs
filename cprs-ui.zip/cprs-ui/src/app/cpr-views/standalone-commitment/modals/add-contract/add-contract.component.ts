import { Component, OnInit, Inject, Optional } from '@angular/core';
import { FormControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ReportsDataService } from 'src/app/cpr-views/service/reports-data.service';

@Component({
  selector: 'add-contract',
  templateUrl: './add-contract.component.html',
  styleUrls: ['./add-contract.component.scss']
})
export class AddContractComponent implements OnInit {

  appData: any;
  addAppForm: FormGroup;
  contractLevelOptions: any;
  primaryBucketsOptions: any;
  load: boolean = false;
  fetchingReport: boolean;
  isSubmit: boolean = true;

  constructor(private fb: FormBuilder, private reportService: ReportsDataService, public dialogRef: MatDialogRef<AddContractComponent>,
    @Optional() @Inject(MAT_DIALOG_DATA) public data: any) {
    // dialogRef.disableClose = true;
  }

  ngOnInit(): void {
    this.getContractLevelsData();
    this.getPrimaryBucketsData();
    this.setupSearchForm();

  }
  async getContractLevelsData() {
    this.reportService.getContractLevelsData().subscribe(resp => {
      this.contractLevelOptions = resp;
      this.setupSearchForm();
    });
  }
  async getPrimaryBucketsData() {
    this.reportService.getPrimaryBucketsData().subscribe(resp => {
      this.primaryBucketsOptions = resp;
      this.setupSearchForm();
    });
  }
  // this.contractLevelOptions[0]
  // this.primaryBucketsOptions[0]
  setupSearchForm(): void {
    this.addAppForm = this.fb.group({
      contractType: new FormControl('', [Validators.required]),
      contractLevel: new FormControl('', [Validators.required]),
      serviceType: new FormControl('', [Validators.required]),
      primaryBucket: new FormControl('', [Validators.required])
    });
    this.load = true;
  }

  async fetchReport() {
    this.fetchingReport = true;
    let contractType = this.addAppForm.get('contractType').value;
    let contractLevel = this.addAppForm.get('contractLevel').value;
    let serviceType = this.addAppForm.get('serviceType').value;
    let primaryBucket = this.addAppForm.get('primaryBucket').value;
    console.log(this.addAppForm.value);
    this.dialogRef.close({ data: this.addAppForm.value });
    this.isSubmit = true;
  }
}
