import { Component, OnInit, Inject, Optional } from '@angular/core';
import { FormControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ReportsDataService } from 'src/app/cpr-views/service/reports-data.service';

@Component({
  selector: 'add-new-service',
  templateUrl: './add-new-service.component.html',
  styleUrls: ['./add-new-service.component.scss']
})
export class AddNewServiceComponent implements OnInit {

  appData: any;
  addForm: FormGroup;
  contractTypeOptions: any;
  load: boolean = false;
  fetchingReport: boolean;
  isSubmit: boolean = true;

  constructor(private fb: FormBuilder, private reportService: ReportsDataService, public dialogRef: MatDialogRef<AddNewServiceComponent>,
    @Optional() @Inject(MAT_DIALOG_DATA) public data: any) {
    this.appData = this.data;
  }

  ngOnInit(): void {
    this.getData();
    this.setupSearchForm();
  }

  async getData() {
    this.reportService.getContractTypeData().subscribe(resp => {
      this.contractTypeOptions = resp;
      this.setupSearchForm();
    });
  }
  // this.contractTypeOptions[0]
  setupSearchForm(): void {
    this.addForm = this.fb.group({
      contractType: new FormControl('', [Validators.required]),
      serviceType: new FormControl('', [Validators.required]),
  });
    this.load = true;
  }

  async fetchReport() {
    this.fetchingReport = true;
    let contractType = this.addForm.get('contractType').value;
    let serviceType = this.addForm.get('serviceType').value;
    this.dialogRef.close({data: this.addForm.value});
    this.isSubmit = true;
  }
}
