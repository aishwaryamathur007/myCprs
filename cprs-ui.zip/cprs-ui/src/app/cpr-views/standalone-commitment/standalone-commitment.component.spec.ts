import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StandaloneCommitmentComponent } from './standalone-commitment.component';

describe('StandaloneCommitmentComponent', () => {
  let component: StandaloneCommitmentComponent;
  let fixture: ComponentFixture<StandaloneCommitmentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StandaloneCommitmentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StandaloneCommitmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
