import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MatTable, MatTableDataSource } from '@angular/material/table';
import { UserDetails, UserService } from 'src/app/shared/service/user.service';
import { ReportsDataService } from '../service/reports-data.service';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { NotificationService } from 'src/app/common/services/notification.service';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { AddContractComponent } from './modals/add-contract/add-contract.component';
import { AddNewServiceComponent } from './modals/add-new-service/add-new-service.component';
import { ConfirmComponent } from 'src/app/common/component/confirm/confirm.component';
import { Subject } from 'rxjs';

export interface StandaloneCommitmentDetails {
  contractType: string;
  contractLevel: string;
  serviceType: string;
  primaryBucket: [];
}
@Component({
  selector: 'standalone-commitment',
  templateUrl: './standalone-commitment.component.html',
  styleUrls: ['./standalone-commitment.component.scss'],
})
export class StandaloneCommitmentComponent implements OnInit {
  
  reportDetailsColumns: string[] = [
    'contractType',
    'contractLevel',
    'serviceType',
    'primaryBucket',
  ];
  columnsData: string[] = [
    'Contract Type',
    'Contract Level',
    'Service Type',
    'Primary Buckets',
  ];

  searchText: any;
  mode: string = 'search';
  addAppForm: FormGroup;
  appData: any = [];
  applications: any = [];
  application: any;
  dataFetched: boolean;
  fetchingReport: boolean;
  load: boolean = false;
  user: UserDetails;
  isTabletMode: boolean = false;
  //isSubmitted: boolean = false;
  isSubmit: boolean = true;
  reportDataSource: MatTableDataSource<any>;
  reportData: StandaloneCommitmentDetails[] = [];
  paginator: any;
  sort: any;
  pageSize = 5;
  tabIndex: number = 0;
  newContract = [];
  showDialog = false;
  subject = new Subject<boolean>();

  @ViewChild('paginator', { static: false }) set matPaginator(
    mp: MatPaginator
  ) {
    this.paginator = mp;
    if (mp && this.reportDataSource) {
      this.reportDataSource.paginator = this.paginator;
    }
  }
  @ViewChild('sort', { static: false }) set matSort(ms: MatSort) {
    this.sort = ms;

    if (ms && this.reportDataSource) {
      this.reportDataSource.sort = this.sort;
    }
  }

  constructor(
    public dialog: MatDialog,
    private fb: FormBuilder,
    private userService: UserService,
    private router: Router,
    // tslint:disable-next-line: variable-name
    private _notifService: NotificationService,
    private reportService: ReportsDataService,
  ) {
    this.user = this.userService.getUserDetails();
  }

  ngOnInit(): void {
    this.fetchReport();
  }
  
  openDialog(){
    if(!this.isSubmit){
    const dialogRef = this.dialog.open(ConfirmComponent, {
          data: {
            type:1,
            content: 'Do you want discard your changes'
          }
        });
    
        dialogRef.afterClosed().subscribe(result => {
        this.subject.next(result);
        });
      }else{        
        const dialogRef1 = this.dialog.open(ConfirmComponent, {
          data: {type:1,content: 'Test'}, panelClass: 'custom-modalbox'
        });
        const overlay = document.getElementsByClassName('cdk-overlay-container')[0] as HTMLElement;
        overlay.style.opacity = '0';
        document.getElementsByTagName('confirm')[0].querySelectorAll('span[class="mat-button-wrapper"').forEach(element => {
          if(element.textContent == 'OK') {
            const btn = element as HTMLElement;
            btn.click();
          }
        })    
        dialogRef1.afterClosed().subscribe(result => {
        this.subject.next(result);
        overlay.style.opacity = '1';
        });
      }
  }

  async fetchReport() {
    this.reportService.getStandaloneCommitmentData().subscribe((resp) => {
      this.reportData = resp;
      this.reportDataSource = new MatTableDataSource(this.reportData);
      this.load = true;
      this.reportDataSource.paginator = this.paginator;
      this.reportDataSource.sort = this.sort;
    });
  }

  isTablet(): boolean {
    if (window.screen.width <= 1024) {
      return true;
    }
    return false;
  }

  doFilter(value: string) {
    this.reportDataSource.filter = value.trim().toLocaleLowerCase();
    this.searchText = value;
  }

  openDialogA(): void {
    let dialogRef = this.dialog.open(AddContractComponent, {
      minWidth: '30%',
    });
    dialogRef.afterClosed().subscribe((result) => {
      console.log('result', result);
      if (result?.data) {
        let obj;
        let contractData;
        result.data.primaryBucket.forEach((ele) => {
          obj = {
            dialogCheck: 'x',
            contractType: result.data.contractType.trim(),
            contractLevel: result.data.contractLevel,
            serviceType: result.data.serviceType,
            primaryBucket: ele,
          };
          contractData = {
            contractList: [
              {
                contractLevel: result.data.contractLevel,
                contractType: result.data.contractType,
                primaryBucket: ele,
                serviceType: result.data.serviceType.trim(),
              },
            ],
            serviceList: [
              {
                contractType: '',
                serviceType: '',
              },
            ],

            webUid: this.user.attuid,
          };
          this.reportDataSource.data.unshift(obj);
          this.reportDataSource = new MatTableDataSource(this.reportDataSource.data);
          this.reportDataSource.paginator = this.paginator;
          this.reportDataSource.sort = this.sort;
          this.isSubmit = false;
          this.newContract.unshift(contractData);
        });
        console.log(obj);
      }
    });
  }

  openDialogB(): void {
    let dialogRef = this.dialog.open(AddNewServiceComponent, {
      minWidth: '30%',
    });
    dialogRef.afterClosed().subscribe((result) => {
      console.log('result', result);
      if (result?.data) {
        let obj;
        let serviceData;
        obj = {
          dialogCheck: 'x',
          contractType: result.data.contractType.trim(),
          serviceType: result.data.serviceType,
        };
        serviceData = {
          contractList: [
            {
              contractLevel: '',
              contractType: '',
              primaryBucket: '',
              serviceType: '',
            },
          ],
          serviceList: [
            {
              contractType: result.data.contractType.trim(),
              serviceType: result.data.serviceType.trim(),
            },
          ],
          webUid: this.user.attuid,
        };
        this.reportDataSource.data.unshift(obj);
        this.reportDataSource = new MatTableDataSource(this.reportDataSource.data);
        this.reportDataSource.paginator = this.paginator;
        this.reportDataSource.sort = this.sort;
        this.isSubmit = false;
        this.newContract.unshift(serviceData);
      }
    });
  }

  submit() {
    this.isSubmit = true;

    console.log('obj', this.newContract);
    this.newContract.forEach((newRow) => {
      this.reportService.addRecord(newRow).subscribe((result) => {
        if (result != null) {
          this.fetchReport();
          this._notifService.showSuccessNotification(result);
          this.newContract = [];
        }
        // tslint:disable-next-line: no-unused-expression
        (error) => {
          this._notifService.showErrorNotification(error);
        };
      });
    });
  }

  cancel() {
    const filteredElements = this.reportDataSource.data.filter(
      (element) => element.dialogCheck !== 'x'
    );
    this.reportDataSource = new MatTableDataSource(filteredElements);
    console.log(filteredElements);
    this.reportDataSource.paginator = this.paginator;
    this.reportDataSource.sort = this.sort;
    this.isSubmit = !this.isSubmit;
  }
}
