import { Component, OnInit } from '@angular/core';
import { UserDetails, UserService } from 'src/app/shared/service/user.service';

@Component({
  selector: 'ub-my-links',
  templateUrl: './my-links.component.html',
  styleUrls: ['./my-links.component.scss']
})
export class MyLinksComponent implements OnInit {

  appId = [27];
  userDetails: UserDetails;
  constructor(private userService: UserService) {
    this.userDetails = this.userService.getUserDetails();
  }

  ngOnInit(): void {
  }

}
