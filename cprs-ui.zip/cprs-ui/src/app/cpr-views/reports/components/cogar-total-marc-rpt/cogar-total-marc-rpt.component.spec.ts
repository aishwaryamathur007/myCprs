import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CogarTotalMarcRptComponent } from './cogar-total-marc-rpt.component';

describe('CogarTotalMarcRptComponent', () => {
  let component: CogarTotalMarcRptComponent;
  let fixture: ComponentFixture<CogarTotalMarcRptComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CogarTotalMarcRptComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CogarTotalMarcRptComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
