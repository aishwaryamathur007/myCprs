import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
//import { ReportFilter } from 'src/app/common/component/report-table/models/report-filter';
import { ReportFilter } from '@report-table-library/common-report-table';
import { UserDetails, UserService } from 'src/app/shared/service/user.service';
import { UtilityService } from 'src/app/common/services/utility.service';
import { ReportsService } from 'src/app/cpr-views/reports/service/reports.service';
import { distinctUntilChanged } from 'rxjs/operators';
import { ReportIdConstants } from '../../constants/report-id.constants';
import { ConfirmComponent } from 'src/app/common/component/confirm/confirm.component';
import { ConfigType } from 'src/app/common/component/confirm/model/confirm-config';
import { MatDialog } from '@angular/material/dialog';
import { NotificationService } from 'src/app/common/services/notification.service';
import * as  FileSaver from 'file-saver';
import * as moment from 'moment';

@Component({
  selector: 'app-cogar-total-marc-rpt',
  templateUrl: './cogar-total-marc-rpt.component.html',
  styleUrls: ['./cogar-total-marc-rpt.component.scss']
})
export class CogarTotalMarcRptComponent implements OnInit {
  [x: string]: any;
  
  appId = 27;
  reportId = ReportIdConstants.COGAR_TOTAL_RPT;
  load: boolean;
  mode: string = 'search'; // used to toggle between search and report view
  user: UserDetails;
  searchForm: FormGroup;
  fetchingReport: boolean;
  dataFetched: boolean;
  reportData: any;
  downloading = false;
  showErrorMessage = '';

  startDate: Date;
  startMinDate: Date;
  startMaxDate: Date;

  endDate: Date;
  endMinDate: Date;
  endMaxDate: Date;
  flag: boolean = false;

  constructor(private fb: FormBuilder,
    private reportsService: ReportsService,
    private userService: UserService,
    _notifService: NotificationService,
    private router: Router) {
    this.user = this.userService.getUserDetails();
  }

  ngOnInit(): void {
    let yt = new Date().getFullYear() - 3;
    let mt = new Date().getMonth();
    let dt = new Date().getDate();
    this.startMinDate = new Date(yt, mt, dt);
    this.startMaxDate = new Date();
    this.setupSearchForm();
  }

  onSelect(){ 
    this.startDate = this.searchForm.get('startDate').value;
    this.endDate = null;
    let yt = new Date(this.searchForm.get('startDate').value).getFullYear();
    let dt = new Date(this.searchForm.get('startDate').value).getDate();
    let mt = new Date(this.searchForm.get('startDate').value).getMonth() + 12;
    this.endMaxDate = new Date(yt, mt, dt);
  }

  sendMail() {
    this.mode = 'view';
    this.downloading = true;
    this.showErrorMessage = '';
    let content = {
      "emailId": this.user.email,
      "enterpriseId": this.searchForm.get('enterpriseID').value ?? '',
      "fromDate": moment(this.searchForm.value.startDate).format('YYYY-MM-DD'),
      "svid": this.searchForm.get('svid').value ?? '',
      "toDate": moment(this.searchForm.value.endDate).format('YYYY-MM-DD')
    };
    this.reportsService.downloadContent(content).subscribe(resp => {
      if (!!resp && resp !== 504) {
        FileSaver.saveAs(resp, 'CogarTotalMarcReport' + (new Date()) + '.xlsx');
        this.downloading = false;
      } else {
        this._notifService.showErrorNotification('Sorry, an error occurred! Please refresh the page and narrow down the search criteria.');
      }
    }, error => {
      this._notifService.showErrorNotification('Sorry, an error occurred! Please refresh the page and narrow down the search criteria.');
    })
    this.searchForm.disable();
  }

  back() {
    this.router.navigate(['/application-reports']);
  }

  windowResized() {
    setTimeout(() => { }, 750);
  }

  setupSearchForm(): void {
    this.searchForm = this.fb.group({
      startDate: new FormControl('', [Validators.required]),
      endDate: new FormControl('', [Validators.required]),
      svid: new FormControl('', [Validators.required]),
      enterpriseID: new FormControl('', [Validators.required]),
    });
    this.searchForm.get('svid').valueChanges.pipe(distinctUntilChanged()).subscribe(val => {
      if (val) {
        this.searchForm.get('enterpriseID').disable();

      } else {
        this.searchForm.get('enterpriseID').enable();
      }
    });
    this.searchForm.get('enterpriseID').valueChanges.pipe(distinctUntilChanged()).subscribe(val => {
      if (val) {
        this.searchForm.get('svid').disable();

      } else {
        this.searchForm.get('svid').enable();
      }
    });

    this.load = true;
  }

  cancel() {
    this.searchForm.enable();
    this.searchForm.reset();
    this.mode = 'search';
  }

  isTablet(): boolean {
    if (window.screen.width <= 1024) {
      return true;
    }

    return false;
  }

}