import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UbContractComponent } from './ub-contract.component';

describe('UbContractComponent', () => {
  let component: UbContractComponent;
  let fixture: ComponentFixture<UbContractComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UbContractComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UbContractComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
