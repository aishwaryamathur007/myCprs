import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
//import { ReportFilter } from 'src/app/common/component/report-table/models/report-filter';
import { ReportFilter } from '@report-table-library/common-report-table';
import { UserDetails, UserService } from 'src/app/shared/service/user.service';
import { UtilityService } from 'src/app/common/services/utility.service';
import { ReportsService } from 'src/app/cpr-views/reports/service/reports.service';
import { ReportIdConstants } from '../../constants/report-id.constants';
import { distinctUntilChanged } from 'rxjs/operators';
import { ConfirmComponent } from 'src/app/common/component/confirm/confirm.component';
import { ConfigType } from 'src/app/common/component/confirm/model/confirm-config';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'ub-contract',
  templateUrl: './ub-contract.component.html',
  styleUrls: ['./ub-contract.component.scss']
})
export class UbContractComponent implements OnInit {

  appId = 27;
  reportId = ReportIdConstants.UB_CONTRACT_RPT;
  load: boolean = false;
  mode: string = 'search'; // used to toggle between search and report view
  user: UserDetails;
  searchForm: FormGroup;
  fetchingReport: boolean;
  dataFetched: boolean;
  reportData: any;
  orignalFilter: ReportFilter[] = [];
  maxDate: Date;
  minDate: Date;
  creditBiller = ['Yes', 'No'];
  creditAmount = ['Between', 'Equal', 'Not Equal', 'Greater Than', 'Greater than and Equal', 'Less Than', 'Equal', 'In'];
  maxDateFromDate: Date;
  flag: boolean = false;
  serviceType: any;
  creditType: boolean = false;
  minDateFromDate: Date;

  constructor(private fb: FormBuilder,
    private reportsService: ReportsService,
    private userService: UserService,
    private utilService: UtilityService, private dialog: MatDialog,
    private router: Router) {
    this.user = this.userService.getUserDetails();
  }

  ngOnInit(): void {
    this.setupSearchForm();
    this.getData();
  }

  back() {
    this.router.navigate(['/application-reports']);
  }

  getData() {
    this.reportsService.getServiceType().subscribe(resp => {
      this.serviceType = resp;
    });
  }

  columnNameChanged($event) {

    if ($event.value !== 'Between') {
      this.creditType = true;
    } else {
      this.creditType = false;
    }

  }

  windowResized() {
    setTimeout(() => { }, 750);
  }

  setupSearchForm(): void {
    this.searchForm = this.fb.group({
      fromDate: new FormControl('', [Validators.required]),
      toDate: new FormControl('', [Validators.required]),
      creditBiller: new FormControl(''),
      contractTariff: new FormControl(''),
      customerName: new FormControl(''),
      serviceType: new FormControl(''),
      creditAmount: new FormControl('Between'),
      customerAccount: new FormControl(''),
      invoiceAccount: new FormControl(''),
      countryCode: new FormControl(''),
      creditAmount1: new FormControl(''),
      creditAmount2: new FormControl('')

    });

    this.searchForm.get('fromDate').valueChanges.pipe(distinctUntilChanged()).subscribe(val => {
      if (val) {
        this.minDate = val;
        this.flag = true;
        this.searchForm.get('toDate').setValidators([Validators.required]);
        this.searchForm.get('toDate').updateValueAndValidity();
      } else {
        this.flag = false;
        this.searchForm.get('toDate').clearValidators();
      }
    });
    this.searchForm.get('toDate').valueChanges.pipe(distinctUntilChanged()).subscribe(val => {
      if (val) {
        this.maxDateFromDate = val;
      } else {
        this.maxDateFromDate = null;
      }
    });

    this.searchForm.get('fromDate').valueChanges.pipe(distinctUntilChanged()).subscribe(val => {
      if (val) {
        this.minDateFromDate = val;
      } else {
        this.minDateFromDate = null;
      }
    });

    this.load = true;
  }

  async fetchReport() {
    this.orignalFilter = [];
    // this.mode = 'view';
    let fromDate = this.searchForm.get('fromDate').value;
    let toDate = this.searchForm.get('toDate').value;
    let contractTariff = this.searchForm.get('contractTariff').value;
    let customerName = this.searchForm.get('customerName').value;
    let serviceType = this.searchForm.get('serviceType').value;
    let creditAmount = this.searchForm.get('creditAmount').value;
    let creditBiller = this.searchForm.get('creditBiller').value;
    let customerAccount = this.searchForm.get('customerAccount').value;
    let invoiceAccount = this.searchForm.get('invoiceAccount').value;
    let countryCode = this.searchForm.get('countryCode').value;
    let creditAmount1 = this.searchForm.get('creditAmount1').value;
    let creditAmount2 = this.searchForm.get('creditAmount2').value;

    let fromDt: Date = new Date(fromDate);
    let toDt: Date = new Date(toDate);
    let months;
    months = (toDt.getFullYear() - fromDt.getFullYear()) * 12;
    months -= fromDt.getMonth();
    months += toDt.getMonth();
    let from = fromDt.getMonth();
    let to = toDt.getMonth();
    if (fromDt > toDt || months > 12) {

      const dialogRef = this.dialog.open(ConfirmComponent, {
        data: {
          type: ConfigType.Alert,
          content: ` The difference between start date and end date should not be greater than a year `
        }
      });

      dialogRef.afterClosed().subscribe(val => {
        this.load = true;
        this.mode = 'search';
        return;
      });


    } else {

      this.mode = 'view';

      if (fromDate && toDate) {
        let transactionDate = {
          columnName: 'INVC_DT',
          filterValue: this.utilService.getStringFromDate(fromDate, 'yyyy-MM-dd') + ';' + this.utilService.getStringFromDate(toDate, 'yyyy-MM-dd'),
          operation: 'between',
        };
        this.orignalFilter.push(transactionDate);
      }

      if (contractTariff) {
        this.orignalFilter.push({
          columnName: 'OFFR_ID',
          filterValue: contractTariff,
          operation: 'like'
        });
      }

      if (customerName) {
        this.orignalFilter.push({
          columnName: 'PRFR_CUST_NM',
          filterValue: customerName,
          operation: 'like'
        });
      }

      if (creditBiller) {
        creditBiller.forEach(element => {
          this.orignalFilter.push({
            columnName: 'CR_BL_ND',
            filterValue: element,
            operation: 'like'
          });
        });

      }
      if (customerAccount) {
        this.orignalFilter.push({
          columnName: 'CNTRCT_CUST_ID',
          filterValue: customerAccount,
          operation: 'between'
        });
      }


      if (invoiceAccount) {
        this.orignalFilter.push({
          columnName: 'PARNT_ACCT_ID',
          filterValue: invoiceAccount,
          operation: 'like'
        });
      }

      if (creditAmount && (creditAmount1 || creditAmount2)) {
        let creditAmount7;
        switch (creditAmount) {
          case "Between": {
            creditAmount7 = {
              columnName: 'CR_AT',
              filterValue: creditAmount1 + ';' + creditAmount2,
              operation: 'between'
            };
            break;

          }
          case "Equal": {
            creditAmount7 = {
              columnName: 'CR_AT',
              filterValue: creditAmount2,
              operation: '='
            };
            break;
          }
          case 'Not Equal': {
            creditAmount7 = {
              columnName: 'CR_AT',
              filterValue: creditAmount2,
              operation: '<>'
            };
            break;
          }

          case 'Greater Than': {
            creditAmount7 = {
              columnName: 'CR_AT',
              filterValue: creditAmount1,
              operation: '>'
            };
            break;
          }

          case 'Greater Than or Equal': {
            creditAmount7 = {
              columnName: 'CR_AT',
              filterValue: creditAmount2,
              operation: '>='
            };
            break;
          }

          case 'Less Than': {
            creditAmount7 = {
              columnName: 'CR_AT',
              filterValue: creditAmount2,
              operation: '<'
            };
            break;
          }

          case 'Less Than or Equal': {
            creditAmount7 = {
              columnName: 'CR_AT',
              filterValue: creditAmount2,
              operation: '<='
            };
            break;
          }

          case 'In': {
            creditAmount7 = {
              columnName: 'CR_AT',
              filterValue: creditAmount2,
              operation: 'in'
            };
            break;
          }

        }
        if (!!creditAmount7)
          this.orignalFilter.push(creditAmount7);
      }

      if (countryCode) {
        this.orignalFilter.push({
          columnName: 'SOC_CNTRY_CD',
          filterValue: countryCode,
          operation: 'like'
        });
      }

      this.searchForm.disable();
      console.log(this.orignalFilter);
    }
  }
  cancel() {
    this.searchForm.enable();
    this.orignalFilter = [];
    this.searchForm.reset();
    this.searchForm.controls['creditAmount'].setValue('Between');
    console.log(this.creditAmount);
    this.fetchingReport = false;
    this.mode = 'search';
    this.dataFetched = false;
  }

  isTablet(): boolean {
    if (window.screen.width <= 1024) {
      return true;
    }

    return false;
  }

}

