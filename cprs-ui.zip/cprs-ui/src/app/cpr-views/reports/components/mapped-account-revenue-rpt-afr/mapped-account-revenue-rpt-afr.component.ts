import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
//import { ReportFilter } from 'src/app/common/component/report-table/models/report-filter';
import { ReportFilter } from '@report-table-library/common-report-table';
import { UserDetails, UserService } from 'src/app/shared/service/user.service';
import { UtilityService } from 'src/app/common/services/utility.service';
import { ReportsService } from 'src/app/cpr-views/reports/service/reports.service';
import { ReportIdConstants } from '../../constants/report-id.constants';
import { distinctUntilChanged } from 'rxjs/operators';
import { MatDialog } from '@angular/material/dialog';
import { ConfirmComponent } from 'src/app/common/component/confirm/confirm.component';
import { ConfigType } from 'src/app/common/component/confirm/model/confirm-config';

@Component({
  selector: 'mapped-account-revenue-rpt-afr',
  templateUrl: './mapped-account-revenue-rpt-afr.component.html',
  styleUrls: ['./mapped-account-revenue-rpt-afr.component.scss']
})
export class MappedAccountRevenueRptAFRComponent implements OnInit {

  appId = 27;
  reportId = ReportIdConstants.MAPPED_ACT_REVENUE_RPT_AFR;
  load: boolean = false;
  mode: string = 'search'; // used to toggle between search and report view
  user: UserDetails;
  searchForm: FormGroup;

  dataFetched: boolean;
  reportData: any;
  orignalFilter: ReportFilter[] = [];
  maxDate: Date;
  minDate: Date;
  maxDateFromDate: Date;
  minDateFromDate: Date;
  flag: boolean = false;

  constructor(private fb: FormBuilder,
    private reportsService: ReportsService,
    private userService: UserService,
    private utilService: UtilityService,
    private router: Router,
    private dialog: MatDialog) {
    this.user = this.userService.getUserDetails();
    console.log('this.user', this.user);
  }

  ngOnInit(): void {
    this.setupSearchForm();
  }

  back() {
    this.router.navigate(['/application-reports']);
  }

  windowResized() {
    setTimeout(() => { }, 750);
  }

  setupSearchForm(): void {
    this.searchForm = this.fb.group({
      billerId: new FormControl('', [Validators.required]),
      accountNumber: new FormControl('', [Validators.required]),
      fromDate: new FormControl('', [Validators.required]),
      toDate: new FormControl('', [Validators.required])

    });


    this.searchForm.get('fromDate').valueChanges.pipe(distinctUntilChanged()).subscribe(val => {
      if (val) {
        this.minDate = val;
        this.flag = true;
        this.searchForm.get('toDate').setValidators([Validators.required]);
        this.searchForm.get('toDate').updateValueAndValidity();
      } else {
        this.flag = false;
        this.searchForm.get('toDate').clearValidators();
      }
    });
    this.searchForm.get('toDate').valueChanges.pipe(distinctUntilChanged()).subscribe(val => {
      if (val) {
        this.maxDateFromDate = val;
      } else {
        this.maxDateFromDate = null;
      }
    });

    this.searchForm.get('fromDate').valueChanges.pipe(distinctUntilChanged()).subscribe(val => {
      if (val) {
        this.minDateFromDate = val;
      } else {
        this.minDateFromDate = null;
      }
    });

    this.load = true;
  }

  async fetchReport() {
    //this.mode = 'view';
    let billerId = this.searchForm.get('billerId').value;
    let accountNumber = this.searchForm.get('accountNumber').value;
    let fromDate = this.searchForm.get('fromDate').value;
    let toDate = this.searchForm.get('toDate').value;

    let fromDt: Date = new Date(fromDate);
    let toDt: Date = new Date(toDate);
    let months;
    months = (toDt.getFullYear() - fromDt.getFullYear()) * 12;
    months -= fromDt.getMonth();
    months += toDt.getMonth();
    let from = fromDt.getMonth();
    let to = toDt.getMonth();
    if (fromDt > toDt || months > 12) {

      const dialogRef = this.dialog.open(ConfirmComponent, {
        data: {
          type: ConfigType.Alert,
          content: ` The difference between start date and end date should not be greater than a year `
        }
      });

      dialogRef.afterClosed().subscribe(val => {
        this.load = true;
        this.mode = 'search';
        return;
      });


    } else {

      this.mode = 'view';

      if (billerId) {
        this.orignalFilter.push({
          columnName: 'BLR_ID',
          filterValue: billerId,
          operation: 'like'
        });
      }
      if (fromDate) {
        this.orignalFilter.push({
          columnName: 'MO_PRD_JRNL_DT',
          filterValue: this.utilService.getStringFromDate(fromDate, 'yyyy-MM-dd') + ';' + this.utilService.getStringFromDate(toDate, 'yyyy-MM-dd'),
          operation: 'between'
        });

      }
      if (accountNumber) {
        this.orignalFilter.push({
          columnName: 'MTCH_ACCT_ID',
          filterValue: accountNumber,
          operation: 'like'
        });
      }
      console.log('this.orignalFilter', this.orignalFilter);

      this.searchForm.disable();
    }
  }

  cancel() {
    this.searchForm.enable();
    this.orignalFilter = [];
    this.searchForm.reset();
    // this.load = false;
    this.mode = 'search';
    this.dataFetched = false;
  }

  isTablet(): boolean {
    if (window.screen.width <= 1024) {
      return true;
    }

    return false;
  }

}