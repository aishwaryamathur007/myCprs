import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MappedAccountRevenueRptAFRComponent } from './mapped-account-revenue-rpt-afr.component';

describe('MappedAccountRevenueRptAFRComponent', () => {
  let component: MappedAccountRevenueRptAFRComponent;
  let fixture: ComponentFixture<MappedAccountRevenueRptAFRComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MappedAccountRevenueRptAFRComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MappedAccountRevenueRptAFRComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
