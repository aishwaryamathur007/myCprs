import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ActiveContractRptComponent } from './active-contract-rpt.component';

describe('ActiveContractRptComponent', () => {
  let component: ActiveContractRptComponent;
  let fixture: ComponentFixture<ActiveContractRptComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ActiveContractRptComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ActiveContractRptComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
