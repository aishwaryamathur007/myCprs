import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
//import { ReportFilter } from 'src/app/common/component/report-table/models/report-filter';
import { ReportFilter } from '@report-table-library/common-report-table';
import { UserDetails, UserService } from 'src/app/shared/service/user.service';
import { UtilityService } from 'src/app/common/services/utility.service';
import { ReportsService } from 'src/app/cpr-views/reports/service/reports.service';
import { distinctUntilChanged } from 'rxjs/operators';
import { ReportIdConstants } from '../../constants/report-id.constants';

@Component({
  selector: 'ict',
  templateUrl: './ict.component.html',
  styleUrls: ['./ict.component.scss']
})
export class IctComponent implements OnInit {

  appId = 27;
  reportId = ReportIdConstants.ICT_ERROR_RPT;
  load: boolean = false;
  mode: string = 'search'; // used to toggle between search and report view
  user: UserDetails;
  searchForm: FormGroup;
  fetchingReport: boolean;
  dataFetched: boolean;
  reportData: any;
  orignalFilter: ReportFilter[] = [];
  maxDate: Date;
  minDate: Date;
  maxDateFromDate: Date;
  minDateFromDate: Date;
  flag: boolean = false;

  constructor(private fb: FormBuilder,
    private reportsService: ReportsService,
    private userService: UserService,
    private utilService: UtilityService,
    private router: Router) {
    this.user = this.userService.getUserDetails();
    console.log('this.user', this.user);
    console.log(this.reportId);
  }

  ngOnInit(): void {
    this.setupSearchForm();
  }
  
  back() {
    this.router.navigate(['/application-reports']);
  }

  windowResized() {
    setTimeout(() => { }, 750);
  }

  setupSearchForm(): void {
    this.searchForm = this.fb.group({
      fromDate: new FormControl(''),
      toDate: new FormControl('')

    });

    this.searchForm.get('fromDate').valueChanges.pipe(distinctUntilChanged()).subscribe(val => {
      if (val) {
        this.minDate = val;
        this.flag = true;
        this.searchForm.get('toDate').setValidators([Validators.required]);
        this.searchForm.get('toDate').updateValueAndValidity();
      } else {
        this.flag = false;
        this.searchForm.get('toDate').clearValidators();
      }
    });
    this.searchForm.get('toDate').valueChanges.pipe(distinctUntilChanged()).subscribe(val => {
      if (val) {
        this.maxDateFromDate = val;
      } else {
        this.maxDateFromDate = null;
      }
    });

    this.searchForm.get('fromDate').valueChanges.pipe(distinctUntilChanged()).subscribe(val => {
      if (val) {
        this.minDateFromDate = val;
      } else {
        this.minDateFromDate = null;
      }
    });

    this.load = true;
  }

  async fetchReport() {
    this.mode = 'view';
    let fromDate = this.searchForm.get('fromDate').value;
    let toDate = this.searchForm.get('toDate').value;


    if (fromDate) {
      this.orignalFilter.push({
        columnName: 'ICT_ERR_DT',
        filterValue: this.utilService.getStringFromDate(fromDate, 'yyyy-MM-dd') + ';' + this.utilService.getStringFromDate(toDate, 'yyyy-MM-dd'),
        operation: 'between'
      });

    }

    console.log('this.orignalFilter', this.orignalFilter);

    this.searchForm.disable();
  }

  cancel() {
    this.searchForm.enable();
    this.orignalFilter = [];
    this.searchForm.reset();
    this.fetchingReport = false;
    this.mode = 'search';
    this.dataFetched = false;
  }

  isTablet(): boolean {
    if (window.screen.width <= 1024) {
      return true;
    }

    return false;
  }

}