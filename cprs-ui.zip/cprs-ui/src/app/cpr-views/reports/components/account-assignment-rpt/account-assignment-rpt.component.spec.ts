import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountAssignmentRptComponent } from './account-assignment-rpt.component';

describe('AccountAssignmentRptComponent', () => {
  let component: AccountAssignmentRptComponent;
  let fixture: ComponentFixture<AccountAssignmentRptComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AccountAssignmentRptComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountAssignmentRptComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
