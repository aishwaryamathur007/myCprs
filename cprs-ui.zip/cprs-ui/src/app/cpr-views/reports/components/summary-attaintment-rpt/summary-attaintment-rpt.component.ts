import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
//import { ReportFilter } from 'src/app/common/component/report-table/models/report-filter';
import { ReportFilter } from '@report-table-library/common-report-table';
import { UserDetails, UserService } from 'src/app/shared/service/user.service';
import { ReportIdConstants } from '../../constants/report-id.constants';

@Component({
  selector: 'summary-attaintment-rpt',
  templateUrl: './summary-attaintment-rpt.component.html',
  styleUrls: ['./summary-attaintment-rpt.component.scss']
})
export class SummaryAttaintmentRptComponent implements OnInit {

  appId = 27;
  reportId = ReportIdConstants.SUMMARY_ATTAINMENT_RPT;
  orignalFilter: ReportFilter[] = [];

  load: boolean = false;
  user: UserDetails;

  constructor(private router: Router,
    private route: ActivatedRoute,
    private userService: UserService) {
    this.user = this.userService.getUserDetails();
  }

  ngOnInit(): void {
    this.load = true;
  }

}
