import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SummaryAttaintmentRptComponent } from './summary-attaintment-rpt.component';

describe('SummaryAttaintmentRptComponent', () => {
  let component: SummaryAttaintmentRptComponent;
  let fixture: ComponentFixture<SummaryAttaintmentRptComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SummaryAttaintmentRptComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SummaryAttaintmentRptComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
