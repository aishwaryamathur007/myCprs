import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
//import { ReportFilter } from 'src/app/common/component/report-table/models/report-filter';
import { ReportFilter } from '@report-table-library/common-report-table';
import * as moment from 'moment';
import { UserDetails, UserService } from 'src/app/shared/service/user.service';
import { ReportIdConstants } from '../../constants/report-id.constants';

@Component({
  selector: 'shortfall-termination',
  templateUrl: './shortfall-termination.component.html',
  styleUrls: ['./shortfall-termination.component.scss']
})
export class ShortfallTerminationComponent implements OnInit {
  appId = 27;
  reportId = ReportIdConstants.SHORTFALL_TERMINATION_RPT;
  orignalFilter: ReportFilter[] = [];

  load: boolean = false;
  user: UserDetails;

  constructor(private router: Router,
    private route: ActivatedRoute,
    private userService: UserService) {
    this.user = this.userService.getUserDetails();
  }

  ngOnInit(): void {
    this.load = true;
    
    const invoiceDate = {
      columnName: 'INVC_DT',
      filterValue: moment(new Date()).format('YYYYMM'),
      operation: 'like',
    };
    this.orignalFilter.push(invoiceDate);

  }

}

