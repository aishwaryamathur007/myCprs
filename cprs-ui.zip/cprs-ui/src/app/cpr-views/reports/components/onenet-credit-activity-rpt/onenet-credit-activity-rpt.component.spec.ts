import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OnenetCreditActivityRptComponent } from './onenet-credit-activity-rpt.component';

describe('OnenetCreditActivityRptComponent', () => {
  let component: OnenetCreditActivityRptComponent;
  let fixture: ComponentFixture<OnenetCreditActivityRptComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OnenetCreditActivityRptComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OnenetCreditActivityRptComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
