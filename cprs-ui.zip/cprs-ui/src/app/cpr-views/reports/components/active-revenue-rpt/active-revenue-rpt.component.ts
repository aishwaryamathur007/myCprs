import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
//import { ReportFilter } from 'src/app/common/component/report-table/models/report-filter';
import { ReportFilter } from '@report-table-library/common-report-table';
import { NotificationService } from 'src/app/common/services/notification.service';
import { UserDetails, UserService } from 'src/app/shared/service/user.service';
import { ReportIdConstants } from '../../constants/report-id.constants';
import { ReportsService } from '../../service/reports.service';
import * as moment from 'moment-timezone';

@Component({
  selector: 'active-revenue-rpt',
  templateUrl: './active-revenue-rpt.component.html',
  styleUrls: ['./active-revenue-rpt.component.scss']
})
export class ActiveRevenueRptComponent implements OnInit {

  mode: string = 'search'; // used to toggle between search and report view
  searchForm: FormGroup;
  dataFetched: boolean;
  reportData: any;
  dateOptions: any = [];

  appId = 27;
  reportId = ReportIdConstants.ACTIVE_REVENUE_RPT;
  user: UserDetails;
  orignalFilter: ReportFilter[] = [];

  constructor(private fb: FormBuilder,
    private reportsService: ReportsService,
    private userService: UserService,
    private router: Router,
    private notifService: NotificationService
    ) {
    this.user = this.userService.getUserDetails();
  }

  ngOnInit(): void {
    this.getData();
  }

  back() {
    this.router.navigate(['/application-reports']);
  }

  async getData() {
    this.dataFetched = false;
    this.reportsService.getActiveContractOptions().subscribe(resp => {
      for (let i = 0; i <= 5; i++) {
        let dateArr = resp.split('/');
        let dateObj = `${dateArr[1]}/${dateArr[0]}`;
        let now = moment(new Date(dateObj)).subtract(i, 'months').format('MM/YYYY');
        console.log(now);
        this.dateOptions.push(now);
      }
      console.log('this.dateOptions', this.dateOptions);
      this.setupSearchForm();
    });
  }

  windowResized() {
    setTimeout(() => { }, 750);
  }

  setupSearchForm(): void {
    this.searchForm = this.fb.group({
      date: new FormControl(this.dateOptions[0]),
    });
    this.dataFetched = true;
  }

  async fetchReport() {
    // this.mode = 'view';
    const date = this.searchForm.controls.date.value;
    let obj = { date: date, isActiveRevenueReport: 'true' };
    this.reportsService.getupdateReportColumnsDetails(obj).subscribe(resp => {

      if (resp === 'Column values are updated Successfully') {
        console.log('resp', resp);
        this.mode = 'view';
      }


    }, error => {
      this.notifService.showErrorNotification(error);

    });
    this.searchForm.disable();
  }

  cancel() {
    this.searchForm.enable();
    this.searchForm.reset();
    this.mode = 'search';
    this.orignalFilter = [];
    this.searchForm.controls.date.setValue(this.dateOptions[0]);
  }

  isTablet(): boolean {
    return window.screen.width <= 1024;
  }


}
