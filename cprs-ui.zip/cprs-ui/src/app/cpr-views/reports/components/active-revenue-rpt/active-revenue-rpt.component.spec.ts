import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ActiveRevenueRptComponent } from './active-revenue-rpt.component';

describe('ActiveRevenueRptComponent', () => {
  let component: ActiveRevenueRptComponent;
  let fixture: ComponentFixture<ActiveRevenueRptComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ActiveRevenueRptComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ActiveRevenueRptComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
