import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ForecastCreditComponent } from './forecast-credit.component';

describe('ForecastCreditComponent', () => {
  let component: ForecastCreditComponent;
  let fixture: ComponentFixture<ForecastCreditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ForecastCreditComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ForecastCreditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
