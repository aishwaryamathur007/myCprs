import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ActiveContractRptComponent } from './components/active-contract-rpt/active-contract-rpt.component';
import { ForecastCreditComponent } from './components/forecast-credit/forecast-credit.component';
import { IctComponent } from './components/ict/ict.component';
import { MappedAccountRevenueRptAFRComponent } from './components/mapped-account-revenue-rpt-afr/mapped-account-revenue-rpt-afr.component';
import { ShortfallTerminationComponent } from './components/shortfall-termination/shortfall-termination.component';
import { AccountAssignmentRptComponent } from './components/account-assignment-rpt/account-assignment-rpt.component';
import { OnenetCreditActivityRptComponent } from './components/onenet-credit-activity-rpt/onenet-credit-activity-rpt.component';
import { ActiveRevenueRptComponent } from './components/active-revenue-rpt/active-revenue-rpt.component';
import { SummaryAttaintmentRptComponent } from './components/summary-attaintment-rpt/summary-attaintment-rpt.component';
import { UtilizationReportComponent } from './components/utilization-report/utilization-report.component';
import { UbContractComponent } from './components/ub-contract/ub-contract.component';
import { CogarTotalMarcRptComponent } from './components/cogar-total-marc-rpt/cogar-total-marc-rpt.component';

const routes: Routes = [
  { path: 'mapped-account-revenue-rpt-afr', component: MappedAccountRevenueRptAFRComponent },
  {
    path: 'account-assignment',
    component: AccountAssignmentRptComponent
  },
  {
    path: 'onenet-credit-activity-rpt',
    component: OnenetCreditActivityRptComponent
  },
  {
    path: 'active-revenue-rpt',
    component: ActiveRevenueRptComponent
  },
  { path: 'utilization-rpt', component: UtilizationReportComponent },
  { path: 'forecast-credit-rpt', component: ForecastCreditComponent },
  { path: 'summary-attainment-rpt', component: SummaryAttaintmentRptComponent },
  { path: 'active-contract-rpt', component: ActiveContractRptComponent },
  { path: 'shortfall-termination-rpt', component: ShortfallTerminationComponent },
  { path: 'ict', component: IctComponent },
  { path: 'ub-contract', component: UbContractComponent },
  { path: 'cogar-total-rpt', component: CogarTotalMarcRptComponent },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ReportsRoutingModule { }