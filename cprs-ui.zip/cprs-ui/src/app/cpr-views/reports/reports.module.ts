import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { ReportsRoutingModule } from './reports-routing.module';
import { SharedModule } from 'src/app/shared/root-material/shared.module';
import { FlexLayoutModule } from '@angular/flex-layout';
import { AppCommonModule } from 'src/app/common/app-common.module';
import { MappedAccountRevenueRptAFRComponent } from './components/mapped-account-revenue-rpt-afr/mapped-account-revenue-rpt-afr.component';
import { AccountAssignmentRptComponent } from './components/account-assignment-rpt/account-assignment-rpt.component';
import { OnenetCreditActivityRptComponent } from './components/onenet-credit-activity-rpt/onenet-credit-activity-rpt.component';
import { ActiveRevenueRptComponent } from './components/active-revenue-rpt/active-revenue-rpt.component';
import { UtilizationReportComponent } from './components/utilization-report/utilization-report.component';
import { ForecastCreditComponent } from './components/forecast-credit/forecast-credit.component';
import { SummaryAttaintmentRptComponent } from './components/summary-attaintment-rpt/summary-attaintment-rpt.component';
import { ActiveContractRptComponent } from './components/active-contract-rpt/active-contract-rpt.component';
import { ShortfallTerminationComponent } from './components/shortfall-termination/shortfall-termination.component';
import { IctComponent } from './components/ict/ict.component';
import { UbContractComponent } from './components/ub-contract/ub-contract.component';
import { CommonReportTableModule } from '@report-table-library/common-report-table';
import { CogarTotalMarcRptComponent } from './components/cogar-total-marc-rpt/cogar-total-marc-rpt.component';




@NgModule({
  declarations: [MappedAccountRevenueRptAFRComponent, AccountAssignmentRptComponent, OnenetCreditActivityRptComponent, ActiveRevenueRptComponent, UtilizationReportComponent, ForecastCreditComponent, SummaryAttaintmentRptComponent, ActiveContractRptComponent, ShortfallTerminationComponent, IctComponent, UbContractComponent, CogarTotalMarcRptComponent],
  providers: [DatePipe],
  imports: [
    CommonModule,
    ReportsRoutingModule,
    SharedModule,
    FlexLayoutModule,
    AppCommonModule,
    CommonReportTableModule
  ]
})
export class ReportsModule { }