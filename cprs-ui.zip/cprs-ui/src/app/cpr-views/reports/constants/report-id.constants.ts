export class ReportIdConstants {
    public static MAPPED_ACT_REVENUE_RPT_AFR = 254;
    public static ACCOUNT_ASSIGNMENT_RPT = 175;
    public static ONENET_CREDIT_ACTIVITY_RPT = 1644;
    public static ACTIVE_REVENUE_RPT = 1962;
    public static UTILIZATION_RPT = 169;
    public static FORCAST_CREDIT_RPT = 189;
    public static SUMMARY_ATTAINMENT_RPT = 211;
    public static ACTIVE_CONTRACT_RPT = 1960;
    public static SHORTFALL_TERMINATION_RPT = 183;
    public static ICT_ERROR_RPT = 1642;
    public static UB_CONTRACT_RPT = 1842;
    public static COGAR_TOTAL_RPT = 2046;
    


}


