import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ReportsService {


  constructor(private http: HttpClient) { }

  getActiveContractOptions(): Observable<any> {
    return this.http.get(environment.cprApiBaseUrl + '/reporting/getInvoiceDate');
  }

  getupdateReportColumnsDetails(obj): Observable<any> {
    return this.http.get(environment.cprApiBaseUrl + '/reporting/updateReportColumns', {
      params: {
        date: obj.date,
        isActiveRevenueReport: obj.isActiveRevenueReport
      }
    });
  }
  getServiceType(): Observable<any> {
    return this.http.get(environment.cprApiBaseUrl + '/reporting/getServiceType');
  }

  downloadContent(obj:any) : Observable<any> {
    return this.http.post(environment.cprApiBaseUrl +'/reporting/getCogarTotalMarcRpt', obj , {responseType: 'blob'});
  };
}
