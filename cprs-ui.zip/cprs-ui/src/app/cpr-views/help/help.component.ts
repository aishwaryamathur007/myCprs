import { Component, OnInit } from '@angular/core';
import { element } from 'protractor';
import { HelpService } from 'src/app/cpr-views/help/service/help.service';
import { HelpDetail } from 'src/app/cpr-views/help/models/help-details';

export interface HelpElement {
  topic: string;
  narr: string;
}

@Component({
  selector: 'app-help',
  templateUrl: './help.component.html',
  styleUrls: ['./help.component.scss']
})
export class HelpComponent implements OnInit {

  helpDataNameGroups: string[] = [];
  uniqueNames: string[] = [];
  loader: boolean;
  helpData: HelpDetail[] = [];
  allExpandState: boolean = true;
  constructor(private helpService: HelpService) { }

  ngOnInit(): void {
    this.getHelpData();
  }

  toggleShow(data: HelpDetail, pIndex: string) {
    this.helpData.forEach((help) => {
      if (help.helpId === data.helpId) {
        help.showDetails = help.showDetails ? false : true;
      }
    });
    const filteredHelpData = this.filterByType(this.helpData, pIndex);
    this.allExpandState = filteredHelpData.every((help) => {
      return help.showDetails === true;
    });
  }
  getHelpDataNameGroups() {
    this.helpData.forEach((data) => {
      this.helpDataNameGroups.push(data.groupName);
    })
    this.uniqueNames = [...new Set(this.helpDataNameGroups)]
  }
  onlyUnique(value, index, self) {
    return self.indexOf(value) === index;
  }
  getHelpData() {
    this.loader = true;
    this.helpService.getHelpData().subscribe((result: HelpDetail[]) => {
      if (result) {
        this.helpData = result;
        this.getHelpDataNameGroups();
        this.helpData.forEach(e => {
          e.showDetails = true;
        });
        this.loader = false;
      }
    });
  }

  onTabChange() {

    this.allExpandState = true;
    this.helpData.forEach((help) => {
      help.showDetails = true;
    });
  }

  expand(expId: string) {
    this.allExpandState = !this.allExpandState;
    this.helpData.forEach((help) => {
      if (expId === help.groupName) {
        help.showDetails = this.allExpandState;
      }
    });
  }

  filterByType(data: HelpDetail[], type: string) {
    // tslint:disable-next-line: no-shadowed-variable
    return data.filter((element) => element.groupName === type);
  }
}
