export class HelpDetail {
    helpId: number;
    topic: string;
    narr: string;
    applicationId: number;
    groupId: number;
    groupName: string;
    mpiApplnId: number;
    // UI only
    showDetails?: boolean = true;
  }
  