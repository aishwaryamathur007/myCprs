import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdministrationAssignmentComponent } from './administration-assignment.component';

describe('AdministrationAssignmentComponent', () => {
  let component: AdministrationAssignmentComponent;
  let fixture: ComponentFixture<AdministrationAssignmentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdministrationAssignmentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdministrationAssignmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
