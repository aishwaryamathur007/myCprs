import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import { ReportsDataService } from '../../service/reports-data.service';
import { NotificationService } from 'src/app/common/services/notification.service';
import { MatPaginator } from '@angular/material/paginator';
import { ConfirmComponent } from 'src/app/common/component/confirm/confirm.component';
import { MatDialog } from '@angular/material/dialog';

export class AssignDetails {
  CNTRCT_CUST_ID: string;
  CNTRCT_SRCE_ID: string;
  DELETABLE: string;
  PRFR_CUST_NM: string;
  SUMCOUNT?: number;
}

export class SearchAssignDetails {
  customerName: string;
  customerId: string;
  sourceId: string;
  isSelected: boolean;
  sumCount?: number;
}

@Component({
  selector: 'administration-assignment',
  templateUrl: './administration-assignment.component.html',
  styleUrls: ['./administration-assignment.component.scss'],
})
export class AdministrationAssignmentComponent implements OnInit {
  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private reportsService: ReportsDataService,
    private _notifService: NotificationService,
    private router: Router,
    public dialog: MatDialog
  ) { }

  businessForm: FormGroup;
  isTabletMode: boolean = false;
  isSubmitted: boolean = false;
  mode; // used to toggle between search and report view
  reportData: AssignDetails[];
  fetchingReport: boolean;
  // dataFetched: boolean;
  displayedColumns: string[] = [
    'PRFR_CUST_NM',
    'CNTRCT_CUST_ID',
    'CNTRCT_SRCE_ID',
    'delete',
  ];
  dataSource: MatTableDataSource<AssignDetails>;
  paginator: any;

  @ViewChild('paginator', { static: false }) set matPaginator(
    mp: MatPaginator
  ) {
    this.paginator = mp;
    if (mp && this.dataSource) {
      this.dataSource.paginator = this.paginator;
    }
  }
  sourceIdOptions: string[] = [
    'All',
    'ABN',
    'DCS',
    'ESP',
    'GBP',
    'ON',
    'SDN',
    'VTNS',
    'ANIRA',
    'AVTS',
    'AVPN',
    'EVPN',
  ];
  userID: string;
  userFullName: string;
  queryParams;
  sourceIdMap = new Map<string, string>();
  // Searched data
  searchData: SearchAssignDetails[];
  searchedDataSource: MatTableDataSource<SearchAssignDetails>;
  paginator2: any;

  @ViewChild('paginator2', { static: false }) set matPaginator2(
    mp: MatPaginator
  ) {
    this.paginator2 = mp;
    if (mp && this.searchedDataSource) {
      this.searchedDataSource.paginator = this.paginator2;
    }
  }
  searchDataColumns: string[] = [
    'action',
    'customerName',
    'customerId',
    'sourceId',
  ];
  // dataSearched: boolean;
  selectedAssignments = [];

  ngOnInit(): void {
    this.route.queryParams.subscribe((params) => {
      this.loadSourceIdMap();
      this.userID = params.attuId;
      this.userFullName = params.fullName;
      this.queryParams = { attuId: this.userID };
      this.fetchReport();
      this.setupSearchForm();
      // this.dataSource = new MatTableDataSource(ELEMENT_DATA);
    });
  }

  loadSourceIdMap(): void {
    this.sourceIdMap.set('ABN', 'A');
    this.sourceIdMap.set('DCS', 'D');
    this.sourceIdMap.set('ESP', 'E');
    this.sourceIdMap.set('GBP', 'G');
    this.sourceIdMap.set('ON', 'O');
    this.sourceIdMap.set('SDN', 'S');
    this.sourceIdMap.set('VTNS', 'V');
    this.sourceIdMap.set('ANIRA', 'R');
    this.sourceIdMap.set('AVTS', 'T');
    this.sourceIdMap.set('AVPN', 'P');
    this.sourceIdMap.set('EVPN', 'E');
  }

  setupSearchForm(): void {
    this.businessForm = this.fb.group({
      customerName: new FormControl('', [Validators.required]),
      customerID: new FormControl('', [Validators.required]),
      sourceID: new FormControl('All', [Validators.required]),
      // customerID: new FormControl('',[Validators.required]),
      // sourceID: new FormControl('',[Validators.required]),
    });
  }
  searchReport(): void {
    this.fetchingReport = true;
    let customerName = this.businessForm.get('customerName').value;
    let customerID = this.businessForm.get('customerID').value;
    const sourceVal = this.businessForm.get('sourceID').value;
    let sourceID = this.sourceIdMap.get(sourceVal);
    this.businessForm = this.fb.group({
      customerName: new FormControl(customerName),
      customerID: new FormControl(customerID),
      sourceID: new FormControl(sourceVal),
    });
    const payload = {
      custId: customerID ?? '',
      custName: customerName ?? '',
      sourceID: sourceID ?? '',
      userID: this.userID,
    };
    this.reportsService.getAssignSearchData(payload).subscribe((resp) => {
      this.searchData = resp;
      this.searchedDataSource = new MatTableDataSource(this.searchData);
      this.fetchingReport = false;
      // this.dataSearched = true;
      this.mode = 'search';
    });
  }
  async fetchReport() {
    console.log('Fetching reports');
    this.fetchingReport = true;
    // TODO fetch reports
    this.reportsService.getAssignDetails(this.userID).subscribe((resp) => {
      this.reportData = resp;
      this.dataSource = new MatTableDataSource(this.reportData);
      this.dataSource.paginator = this.paginator;
      this.mode = 'view';
      this.fetchingReport = false;
      // this.dataFetched = true;
      this.mode = 'view';
    });
  }

  cancel() {
    console.log('Cancel action');
    this.businessForm.reset();
    this.mode = 'search';
    this.dataSource = new MatTableDataSource(this.reportData);
  }

  applyFilter(dataSource: string, event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this[dataSource].paginator) {
      this[dataSource].paginator.firstPage();
    }
  }
  addAssignment() {
    if (this.mode === 'view') {
      const customerName = this.businessForm.get('customerName').value;
      const customerID = this.businessForm.get('customerID').value;
      const sourceVal = this.businessForm.get('sourceID').value;
      let sourceId = this.sourceIdMap.get(sourceVal);
      if (sourceVal === 'All') {
        sourceId = Array.from(this.sourceIdMap.values()).join(',')
        //sourceId = sourceVal;
      }
      const newAssignment: AssignDetails = {
        CNTRCT_CUST_ID: customerID,
        DELETABLE: 'TRUE',
        CNTRCT_SRCE_ID: sourceId,
        PRFR_CUST_NM: customerName,
      };
      const payload = [];
      if (
        this.userID &&
        newAssignment.CNTRCT_CUST_ID &&
        newAssignment.CNTRCT_SRCE_ID
      ) {
        payload.push({
          cntctId: this.userID,
          cntrctCustId: newAssignment.CNTRCT_CUST_ID,
          cntrctSrceId: newAssignment.CNTRCT_SRCE_ID,
        });
        console.log('Adding', newAssignment);
        this.reportsService.addAssignDetails(payload).subscribe(
          (resp) => {
            if (resp.endsWith('added to the selected user.')) {
              this.reportData.push(newAssignment);
              this.dataSource.data.push(newAssignment);
              this.dataSource._updateChangeSubscription();
            }
            this.fetchReport();
            this._notifService.showSuccessNotification(resp);
          },
          (error) => {
            this._notifService.showErrorNotification(
              'There was an error while deleting!'
            );
          }

        );

      }
    } else {
      console.log('Adding searh data', this.selectedAssignments);
      if (this.selectedAssignments.length > 0) {
        const payload = [];
        this.selectedAssignments.forEach((a) => {
          if (this.userID && a.customerId && a.sourceId) {
            payload.push({
              cntctId: this.userID,
              cntrctCustId: a.customerId,
              cntrctSrceId: a.sourceId,
            });
          }
        });
        console.log('Adding', payload);
        this.reportsService.addAssignDetails(payload).subscribe(
          (resp) => {
            if (resp.endsWith('added to the selected user.')) {
              this.searchData.filter((s) => s.isSelected).forEach(a => a.isSelected = false);
            }
            this._notifService.showSuccessNotification(resp);
          },
          (error) => {
            this._notifService.showErrorNotification(
              'There was an error while adding!'
            );
          }
        );
      }
      this.fetchReport();
    }
  }

  delete(element, index) {
    let confirmObj = {
      type: 1,
      content: 'Are you sure you want to Delete the Record?',
    };
    this.dialog
      .open(ConfirmComponent, {
        data: confirmObj
      })
      .afterClosed().subscribe((result) => {
        if (result) {
          this.reportsService.deleteAssignDetails(this.userID, element).subscribe(
            (resp) => {
              if (resp) {
                this._notifService.showSuccessNotification(resp);
                this.fetchReport();
              }
            },
            (error) => {
              this._notifService.showErrorNotification(
                'There was an error while deleting!'
              );
              this.fetchReport();
            }
          );
        }
      });

  }
  doFilter(value: string) {
    this.dataSource.filter = value.trim().toLocaleLowerCase();
  }

  doFilterSearchData(value: string) {
    this.searchedDataSource.filter = value.trim().toLocaleLowerCase();
  }

  goBack(): void {
    this.router.navigate(['customer-contract/contract-assignment'], {
      queryParams: { state: 'back' },
    });
  }

  cancelSearch(): void {
    this.mode = 'view';
    this.dataSource.filter = '';
    this.searchedDataSource.filter = '';
    this.setupSearchForm();
    this.fetchReport();
  }

  validateForm(): void {
    this.selectedAssignments = this.searchData.filter((s) => s.isSelected);
    console.log("Validate form", this.selectedAssignments);
  }
}
