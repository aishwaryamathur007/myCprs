import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { filter, last } from 'rxjs/operators';
import { UserDetails, UserService } from 'src/app/shared/service/user.service';
import { ReportsDataService } from '../service/reports-data.service';

export interface UserData  {
  assign: string;
  firstName: string;
  lastName: string;
  attUid: string;
  title: string;
  email: string;
  tel: number;
}

@Component({
  selector: 'contract-assignment',
  templateUrl: './contract-assignment.component.html',
  styleUrls: ['./contract-assignment.component.scss']
})
export class ContractAssignmentComponent implements OnInit {
  searchForm: FormGroup;
  mode: string = 'search'; // used to toggle between search and report view
  reportData: any;
  dataFetched: boolean;
  fetchingReport: boolean;
  load: boolean = false;
  user: UserDetails;

  reportDetailsColumns: string[] = [
    'assign',
    'firstName',
    'lastName',
    'cntctId',
    'titleCode',
    'email',
    'phone'
   ];

  columnsData = {
    assign: 'Assignment',
    firstName: 'First Name',
    lastName: 'Last Name',
    cntctId: 'ATTUID',
    titleCode: 'Title',
    email: 'Email',
    phone: 'Tel#'
  };

  sortColumns = [
    'firstName',
    'lastName',
    'cntctId',
    'email'
  ]

  reportDataSource: MatTableDataSource<any>;
  paginator: any;
  sort: any;
  
  private readonly storageKey = 'cntrctAssgnmntSearchPayload';

  @ViewChild('paginator', { static: false }) set matPaginator(
    mp: MatPaginator
  ) {
    this.paginator = mp;
    if (mp && this.reportDataSource) {
      this.reportDataSource.paginator = this.paginator;
    }
  }
  @ViewChild('sort', { static: false }) set matSort(ms: MatSort) {
    this.sort = ms;

    if (ms && this.reportDataSource) {
      this.reportDataSource.sort = this.sort;
    }
  }

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private userService: UserService,
    private reportService: ReportsDataService
  ) {
    this.user = this.userService.getUserDetails();
  }

  ngOnInit(): void {
    this.route.queryParams.subscribe((params) => {
      if(params?.state === 'back'){
        const formData = JSON.parse(localStorage.getItem(this.storageKey));
        //console.log("Previus data", formData);
        this.setupSearchForm(formData);
        this.fetchReport();
      } else {
        this.setupSearchForm();
        this.reportDataSource = new MatTableDataSource();
      }
    });
  }

  setupSearchForm(formData?): void {
    this.searchForm = this.fb.group({
    firstName: new FormControl(formData?.firstName),
    lastName: new FormControl(formData?.lastName),
    attUid: new FormControl(formData?.attUID),
    title: new FormControl(formData?.title),
    email: new FormControl(formData?.email),
    tel: new FormControl(formData?.telePhone),
    });
    // this.fetchReport();
    this.load = true;
  }

  async fetchReport() {
    //console.log('fetching report');
    this.fetchingReport = true;
    const firstName = this.searchForm.controls.firstName.value;
    const lastName = this.searchForm.controls.lastName.value;
    const attUid = this.searchForm.controls.attUid.value;
    const title = this.searchForm.controls.title.value;
    const email = this.searchForm.controls.email.value;
    const tel = this.searchForm.controls.tel.value;
    const searchPayload = {
      "attUID": attUid??'',
      "email": email??'',
      "firstName": firstName??'',
      "lastName": lastName??'',
      "selectUserType": "",
      "telePhone": tel??'',
      "title": title??''
    }

    // saving 
    localStorage.setItem(this.storageKey, JSON.stringify(searchPayload));
    // TODO fetching report
    this.reportService.getContractData(searchPayload).subscribe((resp) => {
    this.mode = 'view';
    this.reportData = resp;
    this.reportDataSource = new MatTableDataSource(this.reportData);
    this.reportDataSource._updateChangeSubscription();
    //console.log('reponse data', this.reportData);
    this.fetchingReport = false;
    this.dataFetched = true;
  });
  }

  cancel() {
    localStorage.removeItem(this.storageKey);
    this.searchForm.enable();
    this.searchForm.reset();
    this.mode = 'search';
    this.dataFetched = false;
  }


  applyFilter(dataSource: string, event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this[dataSource].filter = filterValue.trim().toLowerCase();

    if (this[dataSource].paginator) {
      this[dataSource].paginator.firstPage();
    }
  }
  
  isTablet(): boolean {
    if (window.screen.width <= 1024) {
      return true;
    }
    return false;
  }

  windowResized() {
    setTimeout(() => {}, 750);
  }
  doFilter(value: string) {
    this.reportDataSource.filter = value.trim().toLocaleLowerCase();
  }
  }
