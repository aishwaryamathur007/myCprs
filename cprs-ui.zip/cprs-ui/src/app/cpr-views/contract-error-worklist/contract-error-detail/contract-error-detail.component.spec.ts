import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ContractErrorDetailComponent } from './contract-error-detail.component';

describe('ContractErrorDetailComponent', () => {
  let component: ContractErrorDetailComponent;
  let fixture: ComponentFixture<ContractErrorDetailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ContractErrorDetailComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ContractErrorDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
