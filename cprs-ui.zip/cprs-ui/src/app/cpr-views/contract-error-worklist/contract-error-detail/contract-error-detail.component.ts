import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { UserDetails, UserService } from 'src/app/shared/service/user.service';
import { ReportsDataService } from '../../service/reports-data.service';

export interface ContractErrorDetails {
  gcpSolNb: string;
  custNm: string;
  parntCntrctCustId: string;
  hqBlGpCd: string;
  hqSlsOffcCd: string;
  blCycCd: string;
  effStrtDt: Date;
  offrEffDt: Date;
  offrId: string;
  cntrctSrceTx: string;
  postDiscNd: string;
  offrTermMoNb: number;
  yrlyMarcNd: string;
}
export interface ContractErrorDetailsA {
  cmntAt: string;
  mnthlyRngId: string;
  marcVarId: string;
}
export interface ContractErrorDetailsB {
  blAcctId: string;
  blGpCd: string;
  cntrctCustId: string;
  slsOffcCd: string;
}

@Component({
  selector: 'contract-error-detail',
  templateUrl: './contract-error-detail.component.html',
  styleUrls: ['./contract-error-detail.component.scss'],
})
export class ContractErrorDetailComponent implements OnInit {
  [x: string]: any;
  mode: string = 'search'; // used to toggle between search and report view
  dataFetched: boolean;
  fetchingData: boolean;
  load: boolean = false;
  user: UserDetails;
  errorId: any;
  details: boolean = false;
  reportDetailsColumns: string[] = [
    'gcpSolNb',
    'custNm',
    'parntCntrctCustId',
    'hqBlGpCd',
    'hqSlsOffcCd',
    'blCycCd',
    'effStrtDt',
    'offrEffDt',
    'offrId',
    'cntrctSrceTx',
    'postDiscNd',
    'offrTermMoNb',
    'yrlyMarcNd',
  ];
  columnsData: string[] = [
    'Contract Solution Number',
    'Customer Name',
    'Parent Customer Id',
    'Bill Group Cd',
    'Sales Office Cd',
    'Bill Cycle Nb',
    'Customer Effective Date',
    'Offer Effective Date',
    'Offer Id',
    'Service Type',
    'Pre Discount Ind',
    'Contract Term',
    'Yearly Marc Ind',
  ];

  reportDetailsColumnsA: string[] = [
    'cmntAt',
    'mnthlyRngId',
    'marcVarId'
  ];
  columnsDataA: string[] = [
    'Marc Variable',
    'Monthly Range',
    'Marc Value',
  ];

  reportDetailsColumnsB: string[] = [
    'cntrctCustId',
    'blAcctId',
    'slsOffcCd',
    'blGpCd'
  ];
  columnsDataB: string[] = [
    'Customer Id',
    'Mapped Account Id',
    'Mapped Sales Office Code',
    'Mapped Bill Gp Code'
  ];
  reportDataSource: MatTableDataSource<ContractErrorDetails[]>;
  reportDataSourceA: MatTableDataSource<ContractErrorDetailsA[]>;
  reportDataSourceB: MatTableDataSource<ContractErrorDetailsB[]>;

  constructor(
    private userService: UserService,
    private router: Router,
    private route: ActivatedRoute,
    private reportService: ReportsDataService
  ) {
    this.errorId = this.route.snapshot.paramMap.get('id');
    this.user = this.userService.getUserDetails();
  }

  ngOnInit(): void {
    this.fetchingData = true;
    this.fetchReport();
  }

  async fetchReport() {
    let arrayObj = [];
    let obj = { errorId: this.errorId };
    this.reportService.getContractErrorData(obj).subscribe((resp) => {
      arrayObj.push(resp.table1);
      this.reportDataSource = new MatTableDataSource(arrayObj);
      arrayObj = [];
      arrayObj.push(resp.table2);
      console.log('arrayObj', arrayObj);
      this.reportDataSourceA = new MatTableDataSource(arrayObj);
      arrayObj = [];
      arrayObj.push(resp.table3);
      console.log('table3', arrayObj);
      if (arrayObj[0]?.blAcctId === '' && arrayObj[0]?.blGpCd === '' && arrayObj[0]?.cntrctCustId === '' && arrayObj[0]?.slsOffcCd === '') {
        this.details = true;
      }
      this.reportDataSourceB = new MatTableDataSource(arrayObj);

      this.load = true;
      console.log('reportDataSourceB', this.reportDataSourceB);
      this.fetchingData = false;
    });
  }
  isTablet(): boolean {
    if (window.screen.width <= 1024) {
      return true;
    }
    return false;
  }

  goPrevious() {
    this.router.navigateByUrl('/review-work/contract-error-worklist');
  }
  windowResized() {
    setTimeout(() => { }, 750);
  }
}
