import { SelectionModel } from '@angular/cdk/collections';
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { UserDetails, UserService } from 'src/app/shared/service/user.service';
import { ReportsDataService } from '../service/reports-data.service';
import { Router } from '@angular/router';
import { FormBuilder } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { NotificationService } from 'src/app/common/services/notification.service';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';

export interface ContractErrorWorklistDetails {
  radio?: any;
  GCP_SOL_NB: string;
  CUST_NM: string;
  OFFR_ID: string;
  OFFR_EFF_DT: string;
  ERR_DESC_TX: string;
  ERR_DT: string;
}
@Component({
  selector: 'contract-error-worklist',
  templateUrl: './contract-error-worklist.component.html',
  styleUrls: ['./contract-error-worklist.component.scss'],
})
export class ContractErrorWorklistComponent implements OnInit {
  selectedRecords: any = [];
  reportDetailsColumns: string[] = [
    'radioId',
    'GCP_SOL_NB',
    'CUST_NM',
    'OFFR_ID',
    'OFFR_EFF_DT',
    'ERR_DESC_TX',
    'ERR_DT',
  ];
  columnsData: string[] = [
    'Issue Resolved',
    'Contract Solution Number',
    'Customer Name',
    'Offer ID',
    'Offer Effective Date',
    'Error Reason',
    'Error Date',
  ];
  
  mode: string = 'search';
  dataFetched: boolean;
  fetchingReport: boolean;
  load: boolean = false;
  user: UserDetails;
  selectedRow: any;
  isTabletMode: boolean = false;
  isSubmitted: boolean = false;
  isSubmit: boolean = true;
  selection = new SelectionModel<ContractErrorWorklistDetails>(true, []);
 // reportDataSource: ContractErrorWorklistDetails[];
  reportDataSource: MatTableDataSource<any>;
  reportData: ContractErrorWorklistDetails[] = [] ;
  paginator: any;
  sort: any;
  pageSize = 100;

  @ViewChild('paginator', { static: false }) set matPaginator(
     mp: MatPaginator
   ) {
     this.paginator = mp;
     if (mp && this.reportDataSource) {
       this.reportDataSource.paginator = this.paginator;
     }
   }
   @ViewChild('sort', { static: false }) set matSort(ms: MatSort) {
     this.sort = ms;
 
     if (ms && this.reportDataSource) {
       this.reportDataSource.sort = this.sort;
     }
   }
 

  constructor(
    public dialog: MatDialog,
    private fb: FormBuilder,
    private userService: UserService,
    private router: Router,
    // tslint:disable-next-line: variable-name
    private _notifService: NotificationService,
    private reportService: ReportsDataService
  ) {
    this.user = this.userService.getUserDetails();
  }

  ngOnInit(): void {
    this.fetchReport();
  }

  async fetchReport() {
    this.reportService.getContractErrorWorklistData().subscribe((resp) => {
      this.reportData = resp;
      this.reportDataSource = new MatTableDataSource(this.reportData);
      this.load = true;
      this.isSubmit = true;
    });
  }
  reviewSelected(contract) {
    this.router.navigate(['/contract-error-detail', contract.GCP_SOL_NB ]);
  }

  deleteRow(index: any, obj: any) {
    this.load = false;
    console.log('selected rep', this.selectedRecords);
    console.log('this.user.attuid', this.user.attuid);
    let dataObj = {
      ids: this.selectedRecords,
      userId: this.user.attuid
    };

    this.reportService.deleteApplication(dataObj).subscribe((resp) => {
      // tslint:disable-next-line: triple-equals
      if (resp != 'null') {
        this.selectedRecords = [];
        this.fetchReport();
        this._notifService.showSuccessNotification(resp);
      }
    });
  }

  isTablet(): boolean {
    if (window.screen.width <= 1024) {
      return true;
    }

    return false;
  }

  checkBoxSelected(ele: any, condition: any) {
    console.log('checking', ele.GCP_SOL_NB);
    if (this.selectedRecords.indexOf(ele) === -1 && condition.checked) {
      this.selectedRecords.push(ele.GCP_SOL_NB);
      console.log('this.selectedRecords', this.selectedRecords);
    } else if (!condition.checked) {
      let index = this.selectedRecords.indexOf(ele);
      this.selectedRecords.splice(index, 1);
      this.load = true;
    }
    this.isSubmit = this.selectedRecords.length > 0 ? false : true;
  }
  getSvidEnptrMode(val: any) {
    this.mode = val;
    }
    doFilter(value: string) {
      this.reportDataSource.filter = value.trim().toLocaleLowerCase();
    }
}
