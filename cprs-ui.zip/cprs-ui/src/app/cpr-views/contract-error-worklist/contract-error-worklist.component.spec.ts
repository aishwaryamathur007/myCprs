import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ContractErrorWorklistComponent } from './contract-error-worklist.component';

describe('ContractErrorWorklistComponent', () => {
  let component: ContractErrorWorklistComponent;
  let fixture: ComponentFixture<ContractErrorWorklistComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ContractErrorWorklistComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ContractErrorWorklistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
