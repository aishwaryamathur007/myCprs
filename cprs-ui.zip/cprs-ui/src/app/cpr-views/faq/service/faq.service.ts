import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { FaqDetail } from 'src/app/cpr-views/faq/models/faq-details';
import { environment } from 'src/environments/environment';
@Injectable({
  providedIn: 'root',
})
export class FaqService {
  constructor(private http: HttpClient) { }
  getFaqData(): Observable<FaqDetail[]> {
    return this.http.get<FaqDetail[]>(environment.commonApiBaseUrl + '/faqHelp/getFaqDetails?applicationId=27&mpi=true');
  }
}
