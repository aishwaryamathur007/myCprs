import { Component, OnInit } from '@angular/core';
//import { element } from 'protractor';
import { FaqService } from 'src/app/cpr-views/faq/service/faq.service';
import { FaqDetail } from 'src/app/cpr-views/faq/models/faq-details';

export interface FaqElement {
  question: string;
  answer: string;
}

@Component({
  selector: 'app-faq',
  templateUrl: './faq.component.html',
  styleUrls: ['./faq.component.scss'],
})
export class FaqComponent implements OnInit {
  faqDataNameGroups: string[] = [];
  uniqueNames: string[] = [];
  loader: boolean;
  faqData: FaqDetail[] = [];
  allExpandState: boolean = true;
  constructor(private faqService: FaqService) { }

  ngOnInit(): void {
    this.getFaqData();
  }

  toggleShow(data: FaqDetail, pIndex: string) {
    this.faqData.forEach((faq) => {
      if (faq.faqId === data.faqId) {
        faq.showDetails = faq.showDetails ? false : true;
      }
    });
    const filteredFaqData = this.filterByType(this.faqData, pIndex);
    this.allExpandState = filteredFaqData.every((faq) => {
      return faq.showDetails === true;
    });
  }

  getFaqDataNameGroups() {
    this.faqData.forEach((data) => {
      this.faqDataNameGroups.push(data.grpName);
    });
    this.uniqueNames = [...new Set(this.faqDataNameGroups)];
  }
  onlyUnique(value, index, self) {
    return self.indexOf(value) === index;
  }
  getFaqData() {
    this.loader = true;
    this.faqService.getFaqData().subscribe((result: FaqDetail[]) => {
      if (result) {
        this.faqData = result;
        this.getFaqDataNameGroups();
        this.faqData.forEach((e) => {
          e.showDetails = true;
        });
        this.loader = false;
      }
    });
  }

  onTabChange() {
    this.allExpandState = true;
    this.faqData.forEach((faq) => {
      faq.showDetails = true;
    });
  }

  expand(expId: string) {
    this.allExpandState = !this.allExpandState;
    this.faqData.forEach((faq) => {
      if (expId === faq.grpName) {
        faq.showDetails = this.allExpandState;
      }
    });
  }

  filterByType(data: FaqDetail[], type: string) {
    // tslint:disable-next-line: no-shadowed-variable
    return data.filter((element) => element.grpName === type);
  }
}