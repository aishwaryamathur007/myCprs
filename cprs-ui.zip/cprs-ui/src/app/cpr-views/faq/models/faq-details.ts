export class FaqDetail {
    faqId: number;
    question: string;
    answer: string;
    appId: number;
    grpId: number;
    grpName: string;
    mpiApplnId: number;
    // UI only
    showDetails?: boolean = true;
}
