import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CpidSearchComponent } from './cpid-search.component';

describe('CpidSearchComponent', () => {
  let component: CpidSearchComponent;
  let fixture: ComponentFixture<CpidSearchComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CpidSearchComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CpidSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
