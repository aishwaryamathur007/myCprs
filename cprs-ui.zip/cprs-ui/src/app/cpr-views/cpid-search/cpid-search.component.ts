import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatTable, MatTableDataSource } from '@angular/material/table';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CpidSearchService } from '../service/cpid-search.service';

@Component({
  selector: 'cpid-search',
  templateUrl: './cpid-search.component.html',
  styleUrls: ['./cpid-search.component.scss']
})
export class CpidSearchComponent implements OnInit {

  cpidForm: FormGroup;
  load: boolean = false;
  mode: string = 'search';
  reportData: any;
  isTabletMode: boolean = false;
  isSubmitted: boolean = false;
  paginator: any;
  pageSize = 100;
  displayedColumns: string[] = ['mcn', 'cpid'];
  // @ViewChild(MatTable, { static: true }) table: MatTable<any>;
  dataSource: MatTableDataSource<any>;
  @ViewChild('paginator', { static: false }) set matPaginator(
    mp: MatPaginator
  ) {
    this.paginator = mp;
    if (mp && this.dataSource) {
      console.log("this.dataSource", this.dataSource);
      this.dataSource.paginator = this.paginator;
    }

  }

  constructor(private fb: FormBuilder, private cpidSearchService: CpidSearchService
  ) { }



  ngOnInit(): void {
    this.setupForm();
    this.dataSource = new MatTableDataSource();
  }

  windowResized() {
    this.isTabletMode = this.isTablet() ? true : false;
  }
  setupForm(): void {
    this.cpidForm = this.fb.group({
      search: new FormControl('')
    });

  }

  fetchData(): void {
    let search = this.cpidForm.get('search').value;
    this.isSubmitted = true;
    // setTimeout(() => {
    this.cpidSearchService.getcpidSearchData(search).subscribe((resp: any) => {
      console.log("resp",resp);
      this.reportData = resp;
      this.dataSource = new MatTableDataSource(this.reportData);
      this.isSubmitted = false;
      this.mode = 'view';

    });
    //}, 500);

    this.cpidForm.disable();
  }

  cancel() {
    this.cpidForm.enable();
    this.mode = 'search';
    this.cpidForm.reset();
  }

  isTablet(): boolean {
    if (window.screen.width <= 1024) {
      return true;
    }

    return false;
  }
  doFilter(value: string) {
    this.dataSource.filter = value.trim().toLocaleLowerCase();
  }

}
