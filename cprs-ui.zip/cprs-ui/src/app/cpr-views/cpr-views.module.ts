import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from 'src/app/shared/root-material/shared.module';
import { FlexLayoutModule } from '@angular/flex-layout';
import { NgApexchartsModule } from 'ng-apexcharts';
import { FaqComponent } from 'src/app/cpr-views/faq/faq.component';
import { MyReportsComponent } from 'src/app/cpr-views/my-reports/my-reports.component';
import { MyLinksComponent } from 'src/app/cpr-views/my-links/my-links.component';
import { AppCommonModule } from 'src/app/common/app-common.module';
import { AccessDeniedComponent } from './access-denied/access-denied.component';
import { CprViewsRoutingModule } from 'src/app/cpr-views/cpr-views-routing.module';
import { ApplicationReportsComponent } from './application-reports/application-reports.component';
import { PscContractComponent } from './psc-contract/psc-contract.component';
import { ContractAssignmentComponent } from './contract-assignment/contract-assignment.component';
import { AdministrationAssignmentComponent } from './contract-assignment/administration-assignment/administration-assignment.component';
import { ReviewComponent } from './contract-worklist/components/review/review.component';
import { ReviewUpdateComponent } from './contract-worklist/components/review-update/review-update.component';
import { ProfileManagementComponent } from './profile-management/profile-management.component';
import { SvidEnterpriceServiceMappingComponent } from './svid-enterprice-service-mapping/svid-enterprice-service-mapping.component';
import { CustomerContractMaintenanceComponent } from './customer-contract-maintenance/customer-contract-search/customer-contract-maintenance.component';
import { CustomerContractEditComponent } from './customer-contract-maintenance/customer-contract-edit/customer-contract-edit.component';
import { ContractErrorWorklistComponent } from './contract-error-worklist/contract-error-worklist.component';
import { ContractErrorDetailComponent } from './contract-error-worklist/contract-error-detail/contract-error-detail.component';

import { SvidEnterpriseResultComponent } from './svid-enterprice-service-mapping/svid-enterprise-result/svid-enterprise-result.component';
import { IctErrorComponent } from './ict-error/ict-error.component';
import { CpidSearchComponent } from './cpid-search/cpid-search.component';
import { UpdateComponent } from './psc-contract/model/update/update.component';
import { StandaloneCommitmentComponent } from './standalone-commitment/standalone-commitment.component';
import { AddContractComponent } from './standalone-commitment/modals/add-contract/add-contract.component';
import { AddNewServiceComponent } from './standalone-commitment/modals/add-new-service/add-new-service.component';
import { ServiceMappingComponent } from './service-mapping/service-mapping.component';
import { MappingModalComponent } from './customer-contract-maintenance/mapping-modal/mapping-modal.component';
import { CprsReportingComponent } from './cprs-reporting/cprs-reporting.component';
import { FormsModule } from '@angular/forms';
import { NewserviceComponent } from './psc-contract/model/newservice/newservice.component';
import { ReferenceDataMaintenanceComponent } from './reference-data-maintenance/reference-data-maintenance.component';
import { AddComponent } from './reference-data-maintenance/modals/add/add.component';
import { EditComponent } from './reference-data-maintenance/modals/edit/edit.component';
import { ISODatePipe } from './/customer-contract-maintenance/custome.datepipe';
//import { CustomerSearchComponent } from '../common/component/customer-search/customer-search.component';
import { ChargesComponent } from './customer-contract-maintenance/charges/charges.component';
import { AdjustmentComponent } from './customer-contract-maintenance/adjustment/adjustment.component';
import { ServiceMappingRequestStatusComponent } from './svid-enterprice-service-mapping/service-mapping-request-status/service-mapping-request-status.component';
import { CommonReportTableModule } from '@report-table-library/common-report-table';
import { HelpComponent } from './help/help.component';

@NgModule({
  declarations: [
    FaqComponent,
    HelpComponent,
    MyReportsComponent,
    MyLinksComponent,
    AccessDeniedComponent,
    ApplicationReportsComponent,
    PscContractComponent,
    ContractAssignmentComponent,
    AdministrationAssignmentComponent,
    ReviewComponent,
    ReviewUpdateComponent,
    ProfileManagementComponent,
    SvidEnterpriceServiceMappingComponent,
    CustomerContractMaintenanceComponent,
    CustomerContractEditComponent,
    ContractErrorWorklistComponent,
    ContractErrorDetailComponent,
    SvidEnterpriseResultComponent,
    IctErrorComponent,
    CpidSearchComponent,
    UpdateComponent,
    StandaloneCommitmentComponent,
    AddContractComponent,
    AddNewServiceComponent,
    ServiceMappingComponent,
    MappingModalComponent,
    CprsReportingComponent,
    NewserviceComponent,
    ReferenceDataMaintenanceComponent,
    AddComponent,
    EditComponent,
    ISODatePipe,
    ChargesComponent,
    AdjustmentComponent,
    ServiceMappingRequestStatusComponent
  ],
  imports: [
    CommonModule,
    CprViewsRoutingModule,
    SharedModule,
    FlexLayoutModule,
    NgApexchartsModule,
    AppCommonModule,
    FormsModule,
    CommonReportTableModule
  ],
  exports: [
    SvidEnterpriceServiceMappingComponent,
    SvidEnterpriseResultComponent,
  ]
})
export class CprViewsModule { }
