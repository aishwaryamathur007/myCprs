import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from 'src/app/shared/guards/auth.guard';
import { AccessDeniedComponent } from 'src/app/cpr-views/access-denied/access-denied.component';
import { FaqComponent } from 'src/app/cpr-views/faq/faq.component';
import { MyLinksComponent } from 'src/app/cpr-views/my-links/my-links.component';
import { MyReportsComponent } from 'src/app/cpr-views/my-reports/my-reports.component';
import { ApplicationReportsComponent } from './application-reports/application-reports.component';
import { PscContractComponent } from './psc-contract/psc-contract.component';
import { ContractAssignmentComponent } from './contract-assignment/contract-assignment.component';
import { AdministrationAssignmentComponent } from './contract-assignment/administration-assignment/administration-assignment.component';
import { ReviewComponent } from './contract-worklist/components/review/review.component';
import { ReviewUpdateComponent } from './contract-worklist/components/review-update/review-update.component';
import { ProfileManagementComponent } from './profile-management/profile-management.component';
import { SvidEnterpriceServiceMappingComponent } from './svid-enterprice-service-mapping/svid-enterprice-service-mapping.component';
import { CustomerContractMaintenanceComponent } from './customer-contract-maintenance/customer-contract-search/customer-contract-maintenance.component';
import { CustomerContractEditComponent } from './customer-contract-maintenance/customer-contract-edit/customer-contract-edit.component';
import { ContractErrorWorklistComponent } from './contract-error-worklist/contract-error-worklist.component';
import { ContractErrorDetailComponent } from './contract-error-worklist/contract-error-detail/contract-error-detail.component';
import { SvidEnterpriseResultComponent } from './svid-enterprice-service-mapping/svid-enterprise-result/svid-enterprise-result.component';
import { IctErrorComponent } from './ict-error/ict-error.component';
import { CpidSearchComponent } from './cpid-search/cpid-search.component';
import { StandaloneCommitmentComponent } from './standalone-commitment/standalone-commitment.component';
import { ServiceMappingComponent } from './service-mapping/service-mapping.component';
import { CustomerSearchComponent } from '../common/component/customer-search/customer-search.component';
import { CprsReportingComponent } from './cprs-reporting/cprs-reporting.component';
import { NewserviceComponent } from './psc-contract/model/newservice/newservice.component';
import { ConfirmguardGuard } from '../shared/guards/confirmguard.guard';
import { ReferenceDataMaintenanceComponent } from './reference-data-maintenance/reference-data-maintenance.component';
import { HelpComponent } from './help/help.component';


const routes: Routes = [
  {
    path: '', redirectTo: 'dashboard', pathMatch: 'full'
  }, {
    path: 'dashboard', canActivate: [AuthGuard], data: { securityLevel: ['1', '2', '3', '4', '5', '6', '7', '8', '9'] },
    loadChildren: () => import('src/app/cpr-views/dashboard/dashboard.module').then(m => m.DashboardModule),
  }, {
    path: 'guides/help', component: HelpComponent, canActivate: [AuthGuard], data: { securityLevel: ['1', '2', '3', '4', '5', '6', '7', '8', '9'] }
  }, {
    path: 'guides/faq', component: FaqComponent, canActivate: [AuthGuard], data: { securityLevel: ['1', '2', '3', '4', '5', '6', '7', '8', '9'] }
  }, {
    path: 'reports', canActivate: [AuthGuard], data: { securityLevel: ['1', '3', '4', '5', '7', '9'] },
    loadChildren: () => import('src/app/cpr-views/reports/reports.module').then(m => m.ReportsModule),
  }, {
    path: 'bookmark/my-reports', component: MyReportsComponent, canActivate: [AuthGuard], data: { securityLevel: ['1', '3', '4', '5', '7', '9'] }
  }, {
    path: 'bookmark/my-links', component: MyLinksComponent, canActivate: [AuthGuard], data: { securityLevel: ['1', '3'] }
  }, {
    path: 'application-reports', component: CprsReportingComponent, canActivate: [AuthGuard], data: { securityLevel: ['1', '3', '4', '5', '7', '9'] }
  }, {
    path: 'customer-contract/contract-assignment', component: ContractAssignmentComponent, canActivate: [AuthGuard], data: { securityLevel: ['1', '3'] }
  }, {
    path: 'service-mapping/svid-enterprise-service-mapping', component: SvidEnterpriceServiceMappingComponent, canActivate: [AuthGuard], data: { securityLevel: ['1', '2', '3', '6'] }
  }, {
    path: 'service-mapping/svid-enterprise-service-mapping/svid-enterprise-result', component: SvidEnterpriseResultComponent, canActivate: [AuthGuard], data: { securityLevel: ['1', '2', '3', '6'] }
  }, {
    path: 'adminstration-assignment', component: AdministrationAssignmentComponent, canActivate: [AuthGuard], data: { securityLevel: ['1', '3'] }
  }, {
    path: 'customer-contract/psc-contract', component: PscContractComponent, canActivate: [AuthGuard], data: { securityLevel: ['1', '3'] }
  }, {
    path: 'customer-contract/psc-contract/new-service', component: NewserviceComponent, canActivate: [AuthGuard], data: { securityLevel: ['1', '3'] }
  }, {
    path: 'review-work/profile-management', component: ProfileManagementComponent, canActivate: [AuthGuard], data: { securityLevel: ['1'] }
  }, {
    path: 'review-work/ict-error', component: IctErrorComponent, canActivate: [AuthGuard], data: { securityLevel: ['1', '3'] }
  }, {
    path: 'access-denied', component: AccessDeniedComponent, canActivate: [AuthGuard], data: { securityLevel: ['1', '3'] }
  }, {
    path: 'review-work/contract-error-worklist', component: ContractErrorWorklistComponent, canActivate: [AuthGuard], data: { securityLevel: ['1', '3'] }
  }, {
    path: 'contract-error-detail/:id', component: ContractErrorDetailComponent, canActivate: [AuthGuard], data: { securityLevel: ['1', '3'] }
  }, {
    path: 'review-work/contract-review', component: ReviewComponent, canActivate: [AuthGuard], data: { securityLevel: ['1', '3'] }
  }, {
    path: 'contract-worklist/review-update', component: ReviewUpdateComponent, canActivate: [AuthGuard], data: { securityLevel: ['1', '3'] }
  }, {
    path: 'customer-contract/customer-contract-maintenance', component: CustomerContractMaintenanceComponent, canActivate: [AuthGuard], data: { securityLevel: ['1', '3'] }
  }, {
    path: 'service-mapping/standalone-commitment', component: StandaloneCommitmentComponent, canDeactivate: [ConfirmguardGuard], canActivate: [AuthGuard], data: { securityLevel: ["1", "3"] }
  }, {
    path: 'cpid-search', component: CpidSearchComponent, canActivate: [AuthGuard], data: { securityLevel: ['1', '3'] }
  }, {
    path: 'service-mapping/review-approval', component: ServiceMappingComponent, canActivate: [AuthGuard], data: { securityLevel: ['1', '3'] }
  }, {
    path: 'customer-contract/customer-contract-maintenance/edit', component: CustomerContractEditComponent, canActivate: [AuthGuard], data: { securityLevel: ['1', '3'] }
  },
  {
    path: 'service-mapping/reference-data', component: ReferenceDataMaintenanceComponent, canActivate: [AuthGuard], data: { securityLevel: ['1', '3'] }
  },
  {
    path: 'cprs-reporting', component: CprsReportingComponent, canActivate: [AuthGuard], data: { securityLevel: ['1', '3'] }
  },
  {
    path: '**', redirectTo: 'dashboard'
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CprViewsRoutingModule { }
