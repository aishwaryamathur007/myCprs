import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { UserDetails, UserService } from 'src/app/shared/service/user.service';
import { ReportsDataService } from '../service/reports-data.service';

export class ManagementData {
  userType: string;
  firstName: string;
  lastName: string;
  attUid: string;
  title: string;
  email: string;
  tel: number;
  // header: any;
}

@Component({
  selector: 'profile-management',
  templateUrl: './profile-management.component.html',
  styleUrls: ['./profile-management.component.scss']
})
export class ProfileManagementComponent implements OnInit {
  searchForm: FormGroup;
  mode: string = 'search'; // used to toggle between search and report view
  reportData: any;
  dataFetched: boolean;
  fetchingReport: boolean;
  user: UserDetails;
  userTypeOptions: any;

  reportDetailsColumns: string[] = [
    'userType',
    'firstName',
    'lastName',
    'attUid',
    'title',
    'email',
    'tel',
    'header'
  ];

  columnsData = {
    userType: 'User Type',
    firstName: 'First Name',
    lastName: 'Last Name',
    attUid: 'ATT UID',
    title: 'Title',
    email: 'Email',
    tel: 'Tel',
    header: 'Action'
    };

  reportDataSource: MatTableDataSource<any>;
  paginator: any;
  sort: any;
  spans: any;
  load: boolean;

  @ViewChild('paginator', { static: false }) set matPaginator(
    mp: MatPaginator
  ) {
    this.paginator = mp;
    if (mp && this.reportDataSource) {
      this.reportDataSource.paginator = this.paginator;
    }
  }
  @ViewChild('sort', { static: false }) set matSort(ms: MatSort) {
    this.sort = ms;

    if (ms && this.reportDataSource) {
      this.reportDataSource.sort = this.sort;
    }
  }

  constructor(
    private fb: FormBuilder,
    private userService: UserService,
    private reportService: ReportsDataService
  ) {
    this.user = this.userService.getUserDetails();
  }

  userRolesDisplayedColumnsActions: string[] = this.reportDetailsColumns.concat(['actionColumn']);


  ngOnInit(): void {
    this.getInputData();
  }

  async getInputData() {
    // TODO Get data for input fields
    setTimeout(() => {
      this.userTypeOptions = ['ALL', 'AGNS', 'AP INTL', 'ARMS', 'ACIS MW', 'CCMS', 'CFM', 'CRISWHL'];
      }, 1000);
    this.setupSearchForm();
  }

  setupSearchForm(): void {
    this.searchForm = this.fb.group({
    userType: new FormControl(),
    firstName: new FormControl(),
    lastName: new FormControl(),
    attUid: new FormControl(),
    title: new FormControl(),
    email: new FormControl(),
    tel: new FormControl(),
    });
    this.fetchReport();
    this.load = true;
  }

  async fetchReport() {
    console.log('fetching report');
    this.fetchingReport = true;
    // TODO fetching report
    setTimeout(() => {
    this.reportService.getProfileManagementData().subscribe((resp) => {
      this.reportData = resp;
      this.reportDataSource = new MatTableDataSource(this.reportData);
      console.log('reponse data', this.reportData);
      this.mode = 'view';
      this.fetchingReport = false;
      this.dataFetched = true;

    });
  }, 500);
  }

  cancel() {
    this.searchForm.enable();
    this.searchForm.reset();
    this.mode = 'search';
    this.dataFetched = false;
  }

  // deleteWebUser(deleteRow: any) {
  //   // tslint:disable-next-line: one-variable-per-declaration
  //   let ind = deleteRow.index,
  //     ele = deleteRow.element;
  //   this.data = ele.webUserId;
  //   this._notifService.showSuccessNotification('Web User Deleted Successfully');
  //  // this.dataSource = [...this.dataSource.filter((item, index) => index !== ind)];

  //   this._notifService.showErrorNotification('There was an error!');

  // }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.reportDataSource.filter = filterValue.trim().toLowerCase();
  }

  isTablet(): boolean {
    if (window.screen.width <= 1024) {
      return true;
    }
    return false;
  }

  windowResized() {
    setTimeout(() => {}, 750);
  }

  }
