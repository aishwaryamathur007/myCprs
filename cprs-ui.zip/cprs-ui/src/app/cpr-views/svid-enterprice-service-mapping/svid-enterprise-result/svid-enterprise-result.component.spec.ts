import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SvidEnterpriseResultComponent } from './svid-enterprise-result.component';

describe('SvidEnterpriseResultComponent', () => {
  let component: SvidEnterpriseResultComponent;
  let fixture: ComponentFixture<SvidEnterpriseResultComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SvidEnterpriseResultComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SvidEnterpriseResultComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
