import { Component, OnInit, ViewChild, EventEmitter, ChangeDetectorRef, Input, Output, OnChanges, ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import * as _ from 'lodash-es';
import * as  FileSaver from 'file-saver';
import { SvidEnterpriseService } from '../../service/svid-enterprise.service';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { NotificationService } from 'src/app/common/services/notification.service';
import { of } from 'rxjs';

// tslint:disable-next-line: class-name
export interface svidEnterpriseResultColumns {
  prfrCustNm: string;
  acctGpId: string;
  cntrctCustId: string;
  offrId: string;
  cntrctSrceTx: string;
  cntrctSvcNm: string;
  mapAcctId: string;
  blrId: string;
  acctNm: string;
  cntrctSvcDescTx: string;
  offrEffDt: string;
  accountType: string;
  // acctNd: string;
  // orderInd: string;
}

// tslint:disable-next-line: class-name
export interface svidEnterpriseResultColumnsReplaced {
  PRFR_CUST_NM: object;
  ACCT_GP_ID: object;
  CNTRCT_CUST_ID: object;
  OFFR_ID: object;
  CNTRCT_SRCE_TX: object;
  CNTRCT_SVC_NM: object;
  MAP_ACCT_ID: object;
  BLR_ID: object;
  ACCT_NM: object;
  CNTRCT_SVC_DESC_TX: object;
  OFFR_EFF_DT: object;
  ACCOUNT_TYPE: object;
  // acctNd: object;
  // orderInd: object;
}

export interface dashboardSvidEnterpriseResultColumns {
  ACCT_ND: any;
  PRFR_CUST_NM: object;
  ACCT_GP_ID: object;
  CNTRCT_CUST_ID: object;
  OFFR_ID: object;
  CNTRCT_SRCE_TX: object;
  CNTRCT_SVC_NM: object;
  MAP_ACCT_ID: object;
  BLR_ID: object;
  ACCT_NM: object;
  CNTRCT_SVC_DESC_TX: object;
  OFFR_EFF_DT: object;
  ACCOUNT_TYPE: object;
}

@Component({
  selector: 'svid-enterprise-result',
  templateUrl: './svid-enterprise-result.component.html',
  styleUrls: ['./svid-enterprise-result.component.scss'],
  providers: [DatePipe]
})
export class SvidEnterpriseResultComponent implements OnInit, OnChanges {

  svidEnterpriseResultColumnsReplaced: any[] = ['ACCT_GP_ID', 'ACCOUNT_TYPE', 'PRFR_CUST_NM', 'CNTRCT_SRCE_TX', 'CNTRCT_CUST_ID', 'OFFR_ID', 'OFFR_EFF_DT', 'CNTRCT_SVC_NM', 'CNTRCT_SVC_DESC_TX', 'MAP_ACCT_ID', 'ACCT_NM', 'BLR_ID'];
  svidEnterpriseResultHeaders: string[] = ['SVID / Enterprise', 'Account Type', 'Customer Name', 'Contract Type', 'Customer Id', 'Offer Id', 'Offer Effective Date', 'Service Bucket', 'Contract Service Description', 'Account Number', 'Account  Name', 'Biller'];

  dashboardSvidEnterpriseResultColumns: any[] = ['ACCT_ND', 'ACCOUNT_TYPE', 'ACCT_GP_ID', 'PRFR_CUST_NM', 'CNTRCT_SRCE_TX', 'CNTRCT_CUST_ID', 'OFFR_ID', 'OFFR_EFF_DT', 'CNTRCT_SVC_NM', 'CNTRCT_SVC_DESC_TX', 'MAP_ACCT_ID', 'ACCT_NM', 'BLR_ID'];
  dashboardSvidEnterpriseResultHeaders: string[] = ['Include / Remove', 'SVID / Enterprise', 'Account Type', 'Customer Name', 'Contract Type', 'Customer Id', 'Offer Id', 'Offer Effective Date', 'Service Bucket', 'Contract Service Description', 'Account Number', 'Account  Name', 'Biller'];

  
  svidEnterpriseResultDataSource: MatTableDataSource<any>;
  reportData: svidEnterpriseResultColumns[] = [];
  reportLimitData: svidEnterpriseResultColumnsReplaced[] = [];
  svidEnterpriseResultDataClone: any;
  @Input() svidEnterpriseResultData: any;
  @Input() customerId: any;
  @Input() selectedRowObj: any;
  @Output() isBack = new EventEmitter();
  @Input() isDashboard: any;
  paginator: any;
  sort: any;
  pageSize = 100;
  donwloading: any;
  isDownload: boolean = true;
  paginatorLoaded: boolean = false;
  goToPage = 1;
  pageNumbers = [];
  showPageTotals: boolean = true;
  incluRemovArr = [];
  @Input() searchMode: string;
  @Input() webUserId: string;
  load: boolean = false;
  isSubmit: boolean = false;
  respList: any;
  isCloseLink: boolean = false;
  isSubmitClicked: boolean = false;

  @ViewChild('scroll', { read: ElementRef }) public scroll: ElementRef<any>;

  @ViewChild('paginator', { static: false }) set matPaginator(
    mp: MatPaginator
  ) {
    this.paginator = mp;
    if (mp && this.svidEnterpriseResultDataSource) {
      this.svidEnterpriseResultDataSource.paginator = this.paginator;
      this.paginatorLoaded = true;

    }
  }
  @ViewChild('sort', { static: false }) set matSort(ms: MatSort) {
    this.sort = ms;

    if (ms && this.svidEnterpriseResultDataSource) {
      this.svidEnterpriseResultDataSource.sort = this.sort;
    }
  }

  constructor(
    private router: Router,
    private svidEnterpriceService: SvidEnterpriseService,
    private datePipe: DatePipe,
    private _notifService: NotificationService,
    private cdr: ChangeDetectorRef,
  ) { }

  ngOnInit(): void {
    this.svidEnterpriseResultDataClone =  _.cloneDeep(this.svidEnterpriseResultData)
    this.svidEnterpriseResultDataSource = new MatTableDataSource([]);
    this.reportData = this.svidEnterpriseResultData;
    if (!!this.reportData && this.reportData?.length > 0) {
      this.isDownload = false;
      console.log('this.reportData', this.reportData);
      this.svidEnterpriseResultDataSource = new MatTableDataSource(this.reportData);
      //console.log('this.svidEnterpriseResultDataSource', this.svidEnterpriseResultDataSource);
    }
    this.load = true;
  }
  ngOnChanges() {
    this.reportData = this.svidEnterpriseResultData;
    console.log('this.reportData', this.reportData);
    if (!!this.reportData && this.reportData?.length > 0) {
      this.isDownload = false;
      this.svidEnterpriseResultDataSource = new MatTableDataSource(this.reportData);
      //console.log('this.svidEnterpriseResultDataSource', this.svidEnterpriseResultDataSource);
    }
  }

  getUserIdCookie = (name: any) => (
    document.cookie.match('(^|;)\\s*' + name + '\\s*=\\s*([^;]+)')?.pop() || ''
  )
  goPrevious() {
    this.isBack.emit(true);
  }

  async download() {
    if (this.donwloading) { return; }
    this.donwloading = true;
    let tableData = JSON.parse(JSON.stringify(this.reportData));
    tableData.forEach((obj: any) => {
      delete obj['ACCT_ND'];
      delete obj['ORDER_IND'];
    });
    let obj = {
      input: tableData,
      colTitles: {
        ACCT_GP_ID: 'SVID/Enterprise',
        PRFR_CUST_NM: 'Customer Name',
        CNTRCT_SRCE_TX: 'Contract Type',
        CNTRCT_CUST_ID: 'Customer ID',
        OFFR_ID: 'Offer ID',
        OFFR_EFF_DT: 'Offer Effective Date',
        CNTRCT_SVC_NM: 'Service Bucket',
        CNTRCT_SVC_DESC_TX: 'Contract Service Description',
        MAP_ACCT_ID: 'Account Number',
        ACCT_NM: 'Account Name',
        BLR_ID: 'Biller',
        ACCOUNT_TYPE: 'Account Type'
      },

    };

    console.log('selectedRowObj', this.selectedRowObj);

    await this.svidEnterpriceService.downloadSvidEnterpriseResultData(this.selectedRowObj).toPromise().then(resp => {
      let date = this.datePipe.transform(Date.now(), 'yyyy-MM-dd');
      if (resp) {
        FileSaver.saveAs(resp, 'Potential Service_' + date + '.xlsx');
      }
      this.donwloading = false;
    });
  }

  incluRemoChange(eve: any, ele: any){
    let obj = {
      acctId: ele.MAP_ACCT_ID,
      blrId: ele.BLR_ID,
      cntrctCustId: ele.CNTRCT_CUST_ID,
      cntrctSrceId: ele.CNTRCT_SRCE_ID,
      cntrctSvcNm: ele.CNTRCT_SVC_NM,
      mode: this.searchMode,
      offeId: ele.OFFR_ID,
      offrEffDt: ele.OFFR_EFF_DT,
      type: eve.value,
      webUserId: this.webUserId === undefined ? this.getUserIdCookie('userId') : this.webUserId
    }
    this.incluRemovArr.push(obj);
    this.isSubmit = true;
  }

  getSvidIncludeRemoveListData(obj: any){
     this.respList = [];
     this.svidEnterpriseResultDataSource = new MatTableDataSource([]);
     this.reportData = this.svidEnterpriseResultDataClone;
     this.svidEnterpriceService.getSvidIncludeRemoveList(obj).subscribe((resp: any) => {
      if(resp.length > 1){
        this.respList = resp;
        this.isCloseLink = true;
      } else {
        this._notifService.showSuccessNotification(resp);
      }
      this.svidEnterpriseResultDataSource = new MatTableDataSource(this.reportData);
       this.isSubmitClicked = false;
      this.load = true;
      document.querySelector(".sidenav-content").scrollTo(0, 0);
      this.incluRemovArr = [];
    },
    error => {
      console.log(error);
      this._notifService.showErrorNotification(error);
    });
  }

  hideErrList(){
    this.isCloseLink = false;
    this.respList = [];
  }

  submitSvidIncludeRemoveList(){
    this.load = false;
    this.isSubmit = false;
    this.isSubmitClicked = true;
    this.getSvidIncludeRemoveListData(this.incluRemovArr);
  }

  doFilter(value: string) {
    this.svidEnterpriseResultDataSource.filter = value.trim().toLocaleLowerCase();
  }
}
