import { Component, OnInit, ViewChild, OnChanges, Input } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SelectionModel } from '@angular/cdk/collections';
import { SvidEnterpriseService } from '../../cpr-views/service/svid-enterprise.service';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { UserAuthService } from 'src/app/shared/service/user-auth.service';

// tslint:disable-next-line: class-name
export interface svidEnterpriseColumns {
  radioId?: any;
  cntrctCustId: string;
  prfrCustNm: string;
  cntrctSrceTx: string;
  offrId: string;
  offrEffDt: string;
}

@Component({
  selector: 'svid-enterprice-service-mapping',
  templateUrl: './svid-enterprice-service-mapping.component.html',
  styleUrls: ['./svid-enterprice-service-mapping.component.scss']
})

export class SvidEnterpriceServiceMappingComponent implements OnInit, OnChanges {
  svidEnterpriseDisplayedColumns: any[] = ['radioId', 'cntrctCustId', 'prfrCustNm', 'cntrctSrceTx', 'offrId', 'offrEffDt'];
  svidEnterpriseDisplayHeaders: string[] = ['', 'Customer Id', 'Customer Name', 'Contract Source', 'Offer Id', 'Offer Eff Date'];
  selection = new SelectionModel<svidEnterpriseColumns>(true, []);
  svidEnterpriseDataSource: MatTableDataSource<any>;
  reportData: svidEnterpriseColumns[] = [];
  selectedRow: any;
  accessRole: any;
  mode: any;
  load: boolean = false;
  paginator: any;
  sort: any;
  pageSize = 100;
  isSvidResult: boolean = false;
  svidEnterpriseResultData: any;
  customerId: any;
  isSubmit: boolean = false;
  getBack: any;
  searchData: any;
  isDashboardSearch: string = 'false';
  selectedRowObj: any;
  isCheckMapReqRes: boolean = false;
  webUserId: string;

  @ViewChild('paginator', { static: false }) set matPaginator(
    mp: MatPaginator
  ) {
    this.paginator = mp;
    if (mp && this.svidEnterpriseDataSource) {
      this.svidEnterpriseDataSource.paginator = this.paginator;
    }
  }
  @ViewChild('sort', { static: false }) set matSort(ms: MatSort) {
    this.sort = ms;

    if (ms && this.svidEnterpriseDataSource) {
      this.svidEnterpriseDataSource.sort = this.sort;
    }
  }

  constructor(private router: Router, private svidEnterpriceService: SvidEnterpriseService, private activeRouter: ActivatedRoute,private userAuthService: UserAuthService) { 
    this.accessRole = this.userAuthService.userAuth.securityLevel.split(',')[0];
  
    this.activeRouter.queryParams.subscribe(param => {
      this.isDashboardSearch = param.dashboard;
      this.webUserId = param.webUserId
    });
  }

  ngOnInit(): void {
    this.selectedRow = null;
    this.load = true;
    this.mode = 'svid';
  }
  ngOnChanges() {
    this.selectedRow = null;
  }

  getMapReqResult(){
    this.isCheckMapReqRes = true;
    this.isSvidResult = false;
  }

  prevBack(){
    this.isCheckMapReqRes = false;
    this.isSvidResult = true;
  }

  backSearch(){
    this.isDashboardSearch = "false";
    this.router.navigate(['dashboard/search']);
  }

  checkBoxSelected(row: number) {
    this.selectedRow = row;
  }

  customerData(evnt: any) {
    this.load = false;
    this.searchData = evnt.searchTypeValue;
    const paramObj = {
      searchType: '',
      searchValue: evnt.searchTypeValue ? evnt.searchTypeValue : ''
    };
    // this.svidEnterpriseDataSource = mockLandingTableData;

    switch (evnt.searchType) {
      case '1':
        paramObj.searchType = 'Customer Name';
        break;
      case '2':
        paramObj.searchType = 'Customer Id';
        break;
      case '3':
        paramObj.searchType = 'Offer Id';
        break;
      default:
        break;
    }
    Object.keys(paramObj).forEach(key => {
      if (paramObj[key] === '') {
        delete paramObj[key];
      }
    });
    this.svidEnterpriceService.getSvidEnterpriseCustomerData(paramObj).subscribe((resp: any) => {
      this.reportData = resp;

      this.isSubmit = true;
      this.svidEnterpriseDataSource = new MatTableDataSource(this.reportData);
      this.selectedRow = null;
      // this.mode = null;
      this.load = true;

    });
  }

  getSvidEnptrMode(val: any) {
    console.log('vall', val);
    this.mode = val;
  }

  getSvidEntpRowData() {
    this.load = false;
    let obj = {
      cntrctCustId: this.selectedRow.cntrctCustId,
      cntrctSrceId: this.selectedRow.cntrctSrceId,
      mode: this.mode,
      offeId: this.selectedRow.offrId,
      offrEffDt: this.selectedRow.offrEffDt
    };
    this.selectedRowObj = obj;
    this.svidEnterpriceService.getSvidEnterpriseResultData(obj).subscribe((resp: any) => {
      this.svidEnterpriseResultData = resp;
      this.isSvidResult = true;
      this.load = true;
      this.customerId = this.selectedRow.cntrctCustId;
      this.selectedRow = {};
      // this.mode = null;
    });
    
  }

  getIsBack(val: boolean) {
    this.isSvidResult = false;
    this.isCheckMapReqRes = false;
    this.isSubmit = true;
    this.getBack = val;
    this.mode = 'svid';
    this.selectedRow = null;
  }

  doFilter(value: string) {
    this.svidEnterpriseDataSource.filter = value.trim().toLocaleLowerCase();
    console.log(this.svidEnterpriseDataSource.filter);
  }
}
