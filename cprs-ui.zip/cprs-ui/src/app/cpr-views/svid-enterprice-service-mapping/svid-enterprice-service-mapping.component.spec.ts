import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SvidEnterpriceServiceMappingComponent } from './svid-enterprice-service-mapping.component';

describe('SvidEnterpriceServiceMappingComponent', () => {
  let component: SvidEnterpriceServiceMappingComponent;
  let fixture: ComponentFixture<SvidEnterpriceServiceMappingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SvidEnterpriceServiceMappingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SvidEnterpriceServiceMappingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
