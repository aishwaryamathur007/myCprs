import { Component, EventEmitter, OnInit, Input, ViewChild, Output } from '@angular/core';
import { SvidEnterpriseService } from '../../service/svid-enterprise.service';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';

export interface serviceMappingRequestStatusTable {
  ROW_CREAT_TS: object;
  MAP_RQST_STAT_CD: object;
  MAP_RQST_TYPE_CD: object;
  PRFR_CUST_NM: object;
  CNTRCT_CUST_ID: object;
  OFFR_ID: object;
  CNTRCT_SRCE_TX: object;
  ACCT_ID: object;
  BLR_ID: object;
  ROW_UPDT_USR_ID: object;
}

@Component({
  selector: 'service-mapping-request-status',
  templateUrl: './service-mapping-request-status.component.html',
  styleUrls: ['./service-mapping-request-status.component.scss']
})
export class ServiceMappingRequestStatusComponent implements OnInit {

  svidEnterpriseResultDataSource: MatTableDataSource<any>;
  @Input() webUserId: string;
  @Output() isCheckMapReqRes = new EventEmitter();
  paginator: any;
  sort: any;
  pageSize = 100;
  load: boolean = false;
  paginatorLoaded: boolean = false;
  serviceMappingRequestStatusColumns: any[] = ['ROW_CREAT_TS', 'MAP_RQST_STAT_CD', 'MAP_RQST_TYPE_CD', 'PRFR_CUST_NM', 'CNTRCT_CUST_ID', 'OFFR_ID', 'CNTRCT_SRCE_TX', 'ACCT_ID', 'BLR_ID', 'ROW_UPDT_USR_ID'];
  serviceMappingRequestStatusHeaders: string[] = ['Request Date', 'Request Status', 'Request Type', 'Customer Name', 'Customer ID', 'Offer ID', 'Service Bucket', 'Account Number', 'Biller', 'Approver ATTUID'];
  serviceMappingRequestStatusArr: serviceMappingRequestStatusTable[] = [];
  
  @ViewChild('paginator', { static: false }) set matPaginator(
    mp: MatPaginator
  ) {
    this.paginator = mp;
    if (mp && this.svidEnterpriseResultDataSource) {
      this.svidEnterpriseResultDataSource.paginator = this.paginator;
      this.paginatorLoaded = true;

    }
  }
  @ViewChild('sort', { static: false }) set matSort(ms: MatSort) {
    this.sort = ms;

    if (ms && this.svidEnterpriseResultDataSource) {
      this.svidEnterpriseResultDataSource.sort = this.sort;
    }
  }

  constructor(
    private svidEnterpriceService: SvidEnterpriseService,
  ) {}

  ngOnInit(): void {
    this.load = false;
    const paramObj = {
      webUserId : 'gh256j'
    };
    this.svidEnterpriceService.getServiceMappingRequestStatusData(paramObj).subscribe((resp: any) => {
      this.svidEnterpriseResultDataSource = new MatTableDataSource(resp);
      this.load = true;
    });
  }
  doFilter(value: string) {
    this.svidEnterpriseResultDataSource.filter = value.trim().toLocaleLowerCase();
  }

  getIsBack(){
    this.isCheckMapReqRes.emit(true);
  }

}
