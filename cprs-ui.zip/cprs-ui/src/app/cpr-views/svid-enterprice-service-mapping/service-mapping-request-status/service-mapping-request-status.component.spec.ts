import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ServiceMappingRequestStatusComponent } from './service-mapping-request-status.component';

describe('ServiceMappingRequestStatusComponent', () => {
  let component: ServiceMappingRequestStatusComponent;
  let fixture: ComponentFixture<ServiceMappingRequestStatusComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ServiceMappingRequestStatusComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ServiceMappingRequestStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
