import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { NotificationService } from 'src/app/common/services/notification.service';
import { UserDetails, UserService } from 'src/app/shared/service/user.service';
import { ContractWorklistService } from '../../services/contract-worklist.service';

@Component({
  selector: 'review',
  templateUrl: './review.component.html',
  styleUrls: ['./review.component.scss']
})
export class ReviewComponent implements OnInit {
  fetchingData: boolean;
  reportData: any[] = [];
  selectedRow;
  userDetails: UserDetails;
  
  appDetailsColumns: string[] = [
    'checkToApprove',
    'checkToIdentifyError',
    'contractType',
    'contractSolutionNm',
    'contractEvent',
    'customerName',
    'offerId',
    'replaceOfferId',
    'offerEffectiveDate',
  ];
  reportDataSource: MatTableDataSource<any>;
  paginator: any;
  sort: any;

  @ViewChild('paginator', { static: false }) set matPaginator(mp: MatPaginator) {
    this.paginator = mp;
    if (mp && this.reportDataSource) {
      this.reportDataSource.paginator = this.paginator;
    }
  }
  @ViewChild('sort', { static: false }) set matSort(ms: MatSort) {
    this.sort = ms;

    if (ms && this.reportDataSource) {
      this.reportDataSource.sort = this.sort;
    }
  }
  constructor(private contractWorklistService: ContractWorklistService,
    private router: Router,
    private userService: UserService,
    private notificationService: NotificationService) {
      this.userDetails = this.userService.getUserDetails();
    }

  ngOnInit(): void {
    this.getData();
  }

  async getData() {
    this.fetchingData = true;
    this.contractWorklistService.getContractReviewWorklist().subscribe((resp) => {
      this.reportData = resp;
      this.reportDataSource = new MatTableDataSource(this.reportData);
      this.fetchingData = false;
    });
  }

  checkToApprove($event, element) {
    element['isApprovedChecked'] = true;
    this.selectedRow = element;
  }

  checkToIdentifyError($event, element) {
    element['isApprovedChecked'] = false;
    this.selectedRow = element;
  }

  reviewSelected(contract) {
    let queryParams: any = { name: contract.contractSolutionNm };

    this.router.navigate(['/contract-worklist','review-update'], { queryParams: queryParams });
  }

  submit() {
    this.selectedRow['rowUpdtUsrId'] = this.userDetails.attuid;
    console.log("Submitting", this.selectedRow);
    this.contractWorklistService.checkToApproveAndError([this.selectedRow]).subscribe( resp => {
      //this.fetchingData = true;
      if(resp.aprvStatus) {
        this.notificationService.showSuccessNotification(resp);
        this.getData();
      } else {
        let errorMessage  = resp.cncuidNull ?? '';
        errorMessage = errorMessage + (resp.failStatus ?? '');
        errorMessage = errorMessage + (resp.rjctStatus ?? '');
        errorMessage = errorMessage + (resp.cntrctStatus ?? '');
        errorMessage = errorMessage + (resp.offerStatus ?? '');
        errorMessage = errorMessage + (resp.custOfferStatus ?? '');
        this.notificationService.showSuccessNotification(errorMessage);
        this.getData();
      }
    }, error => {
      this.notificationService.showErrorNotification(error);
    })
  }
}
