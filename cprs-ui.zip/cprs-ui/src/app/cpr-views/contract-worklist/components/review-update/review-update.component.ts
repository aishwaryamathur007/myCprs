import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute } from '@angular/router';
import { ConfirmComponent } from 'src/app/common/component/confirm/confirm.component';
import { NotificationService } from 'src/app/common/services/notification.service';
import { ContractReviewDetails, ContractReviewMonthly } from '../../model/contract-review-details';
import { ContractWorklistService } from '../../services/contract-worklist.service';

@Component({
  selector: 'review-update',
  templateUrl: './review-update.component.html',
  styleUrls: ['./review-update.component.scss'],
})
export class ReviewUpdateComponent implements OnInit {
  data: ContractReviewDetails;
  contractName: any;
  constructor(
    private contractWorklistService: ContractWorklistService,
    private route: ActivatedRoute,
    private _notifService: NotificationService,
    public dialog: MatDialog
  ) { }
  fetchingData: boolean;
  updatingData: boolean;

  reviewDetailsColumns: string[] = [
    'contractSolutionNm',
    'customerName',
    'parentContractCustId',
    'hqBlGpCd',
    'hqSlsOffcCd',
    'blCycCd',
    'effStartDt',
    'offrEffDt',
    'offerId',
    'cntrctSrceTx',
    // 'cntrctSrceId',
    // 'cntrctEvntTypeCd',
    'postDiscNd',
    'offrTermMoNb',
    // 'offrTermExtMoNb',
    'yrlyMarcNd',
    'rowUpdtUsrId',
  ];

  detailDataSource: MatTableDataSource<any>;
  monthlyColumns = [
    'gcpRvnuRecId',
    'marcVarId',
    'mnthlyRngId',
    'cmntAt',
    'rowUpdtUsrId',
    'action',
  ];
  contractReviewMonthlyDataSource: MatTableDataSource<any>;

  reviewColumns = ['cntrctCustId', 'blAcctId', 'slsOffcCd', 'blGpCd'];
  ContractReviewCustomerDetailsDataSource: MatTableDataSource<any>;

  ngOnInit(): void {
    this.fetchingData = true;
    this.route.queryParams.subscribe((params) => {
      this.contractName = params['name'];
      this.getData();
    });
  }

  async getData() {
    this.contractWorklistService
      .getContractReviewDetails(this.contractName)
      .subscribe((resp) => {
        this.data = resp;
        this.detailDataSource = new MatTableDataSource([
          this.data.contractReviewDetail,
        ]);
        this.contractReviewMonthlyDataSource = new MatTableDataSource(
          this.data.contractReviewMonthlyList
        );
        this.ContractReviewCustomerDetailsDataSource = new MatTableDataSource([
          this.data.contractReviewCustomerDetails,
        ]);
        this.fetchingData = false;
      });
  }
  keyPressNumbersDecimal(event, value) {
    var charCode = (event.which) ? event.which : event.keyCode;
    let txt = JSON.stringify(value);
    if (charCode != 46 && charCode > 31
      && (charCode < 48 || charCode > 57)) {
      event.preventDefault();
      return false;
    }

    else if (txt.includes('.') && event.key == '.') {
      return false;
    }
    return true;
  }

  update() {
    //console.log("Update", this.data, this.detailDataSource);
    this.updatingData = true;
    this.contractWorklistService.saveContractReviewDetails(this.data).subscribe(
      (resp) => {
        this._notifService.showSuccessNotification(
          'Contract Review Details Successfully Updated'
        );
        this.data = resp;
        this.contractReviewMonthlyDataSource = new MatTableDataSource(
          this.data.contractReviewMonthlyList
        );
        this.updatingData = false;
      },
      (error) => {
        this._notifService.showErrorNotification(
          'There was an error while saving the Contract review details!'
        );
        this.updatingData = false;
      }
    );
  }

  add() {
    const newRow = {
      gcpRvnuRecId: undefined,
      marcVarId: '',
      mnthlyRngId: '',
      cmntAt: 0,
      rowUpdtUsrId: '',
    };
    this.data.contractReviewMonthlyList.push(newRow);
    this.contractReviewMonthlyDataSource = new MatTableDataSource(
      this.data.contractReviewMonthlyList
    );
  }

  delete(ele: ContractReviewMonthly, index) {
    let confirmObj = {
      type: 1,
      content: 'Are you sure you want to Delete the Record?',
    };
    this.dialog
      .open(ConfirmComponent, {
        data: confirmObj,
        disableClose: true,
      })
      .afterClosed()
      .subscribe((result) => {
        console.log('The dialog was closed', result);
        if (result) {
          this.updatingData = true;
          if (ele.gcpRvnuRecId) {
            this.contractWorklistService
              .deleteContractReviewMonthlyData(ele.gcpRvnuRecId)
              .subscribe(
                (resp) => {
                  // this.data.contractReviewMonthlyList.splice(index, 1);
                  this.contractReviewMonthlyDataSource.data.splice(index, 1);
                  this.contractReviewMonthlyDataSource._updateChangeSubscription();
                  this._notifService.showSuccessNotification(
                    'Successfully deleted the record'
                  );
                  this.updatingData = false;
                },
                (error) => {
                  this._notifService.showErrorNotification(
                    'There was an error while deleting!'
                  );
                  this.updatingData = false;
                }
              );
          } else {
            // this.data.contractReviewMonthlyList.splice(index, 1);
            this.contractReviewMonthlyDataSource.data.splice(index, 1);
            this.contractReviewMonthlyDataSource._updateChangeSubscription();
            this._notifService.showSuccessNotification(
              'Successfully deleted the record'
            );
            this.updatingData = false;
          }
        }
      });
  }
}
