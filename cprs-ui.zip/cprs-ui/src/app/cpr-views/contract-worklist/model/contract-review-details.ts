export class ContractReviewDetails {
    contractReviewCustomerDetails: ContractReviewCustomerDetails;
    contractReviewMonthlyList: ContractReviewMonthly[];
    contractReviewDetail: ContractReviewDetail;
}

export class ContractReviewCustomerDetails {
    cntrctCustId: string;
    blAcctId: string;
    blGpCd: string;
    slsOffcCd: string;
}

export class ContractReviewMonthly {
    marcVarId: string;
    mnthlyRngId: string;
    //cntrctSrceId: string;
    cmntAt: number;
    gcpRvnuRecId: string;
    rowUpdtUsrId: string;
}

export class ContractReviewDetail {
    contractSolutionNm: string;
    customerName: string;
    parentContractCustId: string;
    hqBlGpCd: string;
    hqSlsOffcCd: string;
    blCycCd: string;
    effStartDt: string;
    offrEffDt: string;
    offerId: string;
    cntrctSrceTx: string;
    //cntrctSrceId: string;
    //cntrctEvntTypeCd: string;
    postDiscNd: string;
    offrTermMoNb: string;
    //offrTermExtMoNb: string;
    yrlyMarcNd: string;
    rowUpdtUsrId: string;
}