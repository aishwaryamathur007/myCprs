import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { ContractReviewDetails } from '../model/contract-review-details';

@Injectable({
  providedIn: 'root'
})
export class ContractWorklistService {

  constructor(private http: HttpClient) { }

  getContractReviewWorklist(): Observable<any[]> {
    return this.http.get<any[]>(environment.cprApiBaseUrl + '/cntrtRvwWrkList/getCrwls');
  }

  checkToApproveAndError(worklists): Observable<any> {
    return this.http.post(environment.cprApiBaseUrl + '/cntrtRvwWrkList/checkToApproveAndError', worklists);
  }

  getContractReviewDetails(solName): Observable<ContractReviewDetails> {
    return this.http.get<ContractReviewDetails>(environment.cprApiBaseUrl + '/cntrtRvwWrkList/getCrwlDetails?solutionNm='+ ( solName ?? '' ));
  }

  saveContractReviewDetails(contractReview: ContractReviewDetails): Observable<ContractReviewDetails> {
    let monthList = contractReview.contractReviewMonthlyList.map(ele => {
      ele['contractSolutionNm'] = contractReview.contractReviewDetail.contractSolutionNm;
      return ele;
    });
    const payload = {
      contractReviewDetail: contractReview.contractReviewDetail,
      contractReviewMonthlyList: monthList,
    };
    return this.http.post<ContractReviewDetails>(environment.cprApiBaseUrl + '/cntrtRvwWrkList/addOrUpdateContractDetail',payload);
  }

  deleteContractReviewMonthlyData(recId): Observable<any> {
    return this.http.delete(environment.cprApiBaseUrl + '/cntrtRvwWrkList/deleteRecordId?recordId='+ ( recId ?? '' ));
  }
}
