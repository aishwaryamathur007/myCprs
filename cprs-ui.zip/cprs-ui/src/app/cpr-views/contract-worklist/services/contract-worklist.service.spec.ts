import { TestBed } from '@angular/core/testing';

import { ContractWorklistService } from './contract-worklist.service';

describe('ContractWorklistService', () => {
  let service: ContractWorklistService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ContractWorklistService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
