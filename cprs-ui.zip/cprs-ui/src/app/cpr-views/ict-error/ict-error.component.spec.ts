import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IctErrorComponent } from './ict-error.component';

describe('IctErrorComponent', () => {
  let component: IctErrorComponent;
  let fixture: ComponentFixture<IctErrorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IctErrorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(IctErrorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
