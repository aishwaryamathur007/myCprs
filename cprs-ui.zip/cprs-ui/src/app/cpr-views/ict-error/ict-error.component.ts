import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { SelectionModel } from '@angular/cdk/collections';
import { FormBuilder } from '@angular/forms';
import { UserDetails, UserService } from 'src/app/shared/service/user.service';
import { NotificationService } from 'src/app/common/services/notification.service';
import { IctErrorService } from '../service/ict-error.service';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';

// tslint:disable-next-line: class-name
export interface svidEnterpriseColumns {
  radio?: any;
  ICT_REC_ID: number;
  CNTRCT_CUST_ID: number;
  HQ_SLS_OFFC_CD: number;
  HQ_BL_GP_CD: string;
  PARNT_CNTRCT_CUST_ID: number;
  ICT_SERVICE_TX: number;
  BL_CYC_NB: number;
  CUST_NM: string;
  EFF_STRT_DT: string;
  OFFR_ID: number;
  OFFR_TYPE_CD: number;
  ICT_OFFR_TYPE_DESC_TX: number;
  OFFR_TERM_MO_NB: number;
  OFFR_EFF_DT: string;
  CUST_OFFR_STRT_DT: number;
  MAP_ACCT_IDS: number;
  ACTN_DESC_SHRT_TX: number;
  OFFR_NM: number;
  CMNT_1_AT: number;
  CMNT_2_AT: number;
  CMNT_3_AT: number;
  CMNT_4_AT: number;
  CMNT_5_AT: number;
  CMNT_6_AT: number;
  CMNT_7_AT: number;
  CMNT_8_AT: number;
  CMNT_9_AT: number;
  CMNT_10_AT: number;
  CMNT_11_AT: number;
  CMNT_12_AT: number;
  CMNT_13_AT: number;
  CMNT_14_AT: number;
  ERR_DESC_TX: string;
  ERR_DT: string;
  isChecked?: false;
}

@Component({
  selector: 'ict-error',
  templateUrl: './ict-error.component.html',
  styleUrls: ['./ict-error.component.scss']
})
export class IctErrorComponent implements OnInit {
  selectedRecords: any = [];
  svidEnterpriseDisplayedColumns: any[] = ['radioId', 'ICT_REC_ID', 'CNTRCT_CUST_ID', 'HQ_SLS_OFFC_CD', 'HQ_BL_GP_CD', 'PARNT_CNTRCT_CUST_ID', 'ICT_SERVICE_TX', 'BL_CYC_NB', 'CUST_NM', 'EFF_STRT_DT',
    'OFFR_ID', 'OFFR_TYPE_CD', 'ICT_OFFR_TYPE_DESC_TX', 'OFFR_TERM_MO_NB', 'OFFR_EFF_DT', 'CUST_OFFR_STRT_DT', 'MAP_ACCT_IDS',
    'ACTN_DESC_SHRT_TX', 'OFFR_NM', 'CMNT_1_AT', 'CMNT_2_AT', 'CMNT_3_AT', 'CMNT_4_AT', 'CMNT_5_AT', 'CMNT_6_AT', 'CMNT_7_AT', 'CMNT_8_AT',
    'CMNT_9_AT', 'CMNT_10_AT', 'CMNT_11_AT', 'CMNT_12_AT', 'CMNT_13_AT', 'CMNT_14_AT', 'ERR_DESC_TX', 'ERR_DT'];

  svidEnterpriseDisplayHeaders: string[] = ['Issue Resolved', 'Record Id',
    'Customer ID (MCN)', 'Sales Office Code', 'Bill Group Code', 'Parent Customer Id', 'Service', 'Bill Cycle Number', 'Customer Name', 'Customer Start Date', 'Offer ID', 'Offer Type Code', 'Offer Type Description', 'Offer Term', 'Offer Effective Date', 'Offer Start Date', 'Mapped Accounts', 'Action Type', 'Offer Name', 'Commitment Amount 1', 'Commitment Amount 2', 'Commitment Amount 3', 'Commitment Amount 4', 'Commitment Amount 5', 'Commitment Amount 6', 'Commitment Amount 7', 'Commitment Amount 8', 'Commitment Amount 9', 'Commitment Amount 10', 'Commitment Amount 11', 'Commitment Amount 12', 'Commitment Amount 13', 'Commitment Amount 14', 'Error Description', 'Error Date'];

  selection = new SelectionModel<svidEnterpriseColumns>(true, []);
  // svidEnterpriseDataSource: svidEnterpriseColumns[];
  svidEnterpriseDataSource: MatTableDataSource<any>;

  selectedRow: any;
  isTabletMode: boolean = false;
  isSubmitted: boolean = false;
  mode: string = 'search'; // used to toggle between search and report view
  reportData: svidEnterpriseColumns[] = [];
  fetchingReport: boolean;
  dataFetched: boolean;
  user: any;
  load: boolean = false;
  isSubmit: boolean = true;
  paginator: any;
  sort: any;
  pageSize = 100;

  @ViewChild('paginator', { static: false }) set matPaginator(
    mp: MatPaginator
  ) {
    this.paginator = mp;
    if (mp && this.svidEnterpriseDataSource) {
      this.svidEnterpriseDataSource.paginator = this.paginator;
    }
  }
  @ViewChild('sort', { static: false }) set matSort(ms: MatSort) {
    this.sort = ms;

    if (ms && this.svidEnterpriseDataSource) {
      this.svidEnterpriseDataSource.sort = this.sort;
    }
  }

  constructor(public dialog: MatDialog, private router: Router, private fb: FormBuilder,
    private userService: UserService,
    // tslint:disable-next-line: variable-name
    private _notifService: NotificationService,
    private ictservice: IctErrorService) {
    this.user = this.userService.getUserDetails();
  }

  ngOnInit(): void {
    this.fetchReport();
  }

  async fetchReport() {
    this.ictservice.getIctErrorData().subscribe((resp) => {
      this.reportData = resp;
      this.svidEnterpriseDataSource = new MatTableDataSource(this.reportData);
      this.load = true;
      this.isSubmit = true;
    });
  }

  deleteRow(index: any, obj: any) {
    this.load = false;
    let dataObj = {
      ids: this.selectedRecords,
      userId: this.user.attuid
    };

    this.ictservice.deleteApplication(dataObj).subscribe((resp) => {
      if (resp !== 'null') {
        this.selectedRecords = [];
        this.fetchReport();
        this._notifService.showSuccessNotification(resp);
      }

    });
  }

  isTablet(): boolean {
    if (window.screen.width <= 1024) {
      return true;
    }

    return false;
  }

  checkBoxSelected(ele: any, condition: any) {
    if (this.selectedRecords.indexOf(ele) == -1 && condition.checked) {
      this.selectedRecords.push(JSON.stringify(ele.ICT_REC_ID));
    } else if (!condition.checked) {
      let index = this.selectedRecords.indexOf(ele);
      this.selectedRecords.splice(index, 1);
      this.load = true;
    }
    this.isSubmit = this.selectedRecords.length > 0 ? false : true;
  }

  getSvidEnptrMode(val: any) {
    this.mode = val;
  }
  doFilter(value: string) {
    this.svidEnterpriseDataSource.filter = value.trim().toLocaleLowerCase();
  }
}
