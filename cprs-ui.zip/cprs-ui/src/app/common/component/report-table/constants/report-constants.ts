export class ReportConstants {

    public static filterColumnOperationsTypeString = [{
        display: 'Like (use *)',
        value: 'like',
    }, {
        display: 'Not Like (use *)',
        value: 'not like',
    }, {
        display: 'Equal (Exact)',
        value: '=',
    }, {
        display: 'Not Equal (Exact)',
        value: '<>',
    }, {
        display: 'In',
        value: 'in',
    }, {
        display: 'Between',
        value: 'between',
    }];


    public static filterColumnOperationsTypeNumber = [{
        display: 'Equal',
        value: '=',
    }, {
        display: 'Not Equal',
        value: '<>',
    }, {
        display: 'Greater Than',
        value: '>',
    }, {
        display: 'Greater Than or Equal',
        value: '>=',
    }, {
        display: 'Less Than',
        value: '<',
    }, {
        display: 'Less Than or Equal',
        value: '<=',
    }, {
        display: 'In',
        value: 'in',
    }, {
        display: 'Between',
        value: 'between',
    }];
}

