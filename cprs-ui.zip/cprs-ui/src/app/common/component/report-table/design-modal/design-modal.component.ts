import { animate, state, style, transition, trigger } from '@angular/animations';
import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatTable, MatTableDataSource } from '@angular/material/table';
import { ReportConstants } from 'src/app/common/component/report-table/constants/report-constants';
import { ReportTableService } from 'src/app/common/component/report-table/service/report-table.service';
import { DatePipe } from '@angular/common';
import { UtilityService } from 'src/app/common/services/utility.service';


@Component({
  selector: 'app-design-modal',
  templateUrl: './design-modal.component.html',
  styleUrls: ['./design-modal.component.scss'],
  animations: [
    trigger('searchExpand', [
      state('collapsed', style({ display: 'none' })),
      state('expanded', style({ display: '', height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
  providers: [DatePipe]
})
export class DesignModalComponent implements OnInit {
  @ViewChild('table', { static: false }) set editTableContent(tableContent: MatTable<any>) {
    if (tableContent) {
      this.table = tableContent;
    }
  }

  deletingFilter: any;
  table: MatTable<any>;
  filterDataDatasource: MatTableDataSource<any> = new MatTableDataSource<any>();
  columnDetails: any;
  show: boolean = false;
  showedColumns: any[];
  hiddenColumns: any[];
  sortOrder: any;
  reportId: any;
  defaultColumn: any;
  defaultOperationOptions: any[];

  sortedColumns: any[];
  unsortedColumns: any[];
  selectedTab: any;
  columnOptions: any[] = [];
  filterData: any[];
  columnDetailsTableColumns = ['col', 'ops', 'val', 'action'];

  constructor(public dialogRef: MatDialogRef<DesignModalComponent>,
    private reportService: ReportTableService,
    private datePipe: DatePipe,
    private utilService: UtilityService,
    @Inject(MAT_DIALOG_DATA) public data: any) {

    this.dialogRef.addPanelClass('edit-column-dialog');
    this.dialogRef.disableClose = true;

    this.reportId = this.data.reportId;
    this.columnDetails = this.data.columnDetails;
    this.sortOrder = this.data.sortDetails;
    this.filterData = this.data.filter;
    this.filterData.forEach(e => {
      if (e.operation === 'like' || e.operation === 'not like') {
        e.filterValue = e.filterValue.split('%').join('*');
      } else if (e.operation === 'between') {
        let filterValues = e.filterValue.split(';');
        e.filterValue = filterValues[0];
        e.filterValue2 = filterValues[1];
      }
    });
    this.selectedTab = this.data.defaultTabIndex;
  }

  ngOnInit(): void {
    this.splitColumns();
  }

  confirm() {
    if (!this.sortedColumns.length) {
      let defaultSort = {
        bind: this.showedColumns[0].bind,
        order: 'ASC',
        columnName: this.showedColumns[0].columnName,
        columnNumber: this.showedColumns[0].columnNumber
      };
      this.sortedColumns.push(defaultSort);
    }


    let result = {
      columnDetails: this.showedColumns.concat(this.hiddenColumns),
      sortDetails: this.sortedColumns,
      filterDetails: this.filterData.map(x => {
        let filterValue = x.filterValue;
        let bind = x.columnName;
        if (this.isCalendarFilter(bind)) {
          filterValue = this.utilService.getStringFromDate(x.filterValue, 'yyyy-MM-dd');
          if (x.operation === 'between') {
            x.filterValue2 = this.utilService.getStringFromDate(x.filterValue2, 'yyyy-MM-dd');
          }
        }
        if (x.operation === 'between') {
          filterValue = filterValue + ';' + x.filterValue2;
        }

        let data = {
          columnName: x.columnName,
          filterValue: filterValue,
          operation: x.operation,
        };

        return data;
      })
    };

    this.dialogRef.close(result);
  }

  splitColumns() {
    this.showedColumns = this.columnDetails.filter(x => x.show);
    this.hiddenColumns = this.columnDetails.filter(x => !x.show);
    this.splitSortColumns();
  }

  splitSortColumns() {
    let shownColumnNumbers = this.showedColumns.map(x => x.columnNumber);
    this.sortedColumns = this.sortOrder.filter(x => shownColumnNumbers.includes(x.columnNumber));
    let sortedColNumbers = this.sortedColumns.map(x => x.columnNumber);
    this.unsortedColumns = this.showedColumns.filter(x => !sortedColNumbers.includes(x.columnNumber)).map(
      x => {
        return {
          bind: x.bind,
          columnName: x.columnName,
          columnNumber: x.columnNumber,
          order: 'ASC'
        };
      }
    );

    this.setupFilterForm();
  }

  setupFilterForm() {

    this.filterData = this.filterData.map(x => {
      let data = x;
      let fieldType = this.columnDetails.filter(y => y.bind === x.columnName)[0].fieldType;

      if (fieldType === '5') {
        // date picker type
        // formatting into date to avoid one day behind in date picker issue
        data.filterValue = this.utilService.toDateFromString(data.filterValue);
        if (data.filterValue2) {
          data.filterValue2 = this.utilService.toDateFromString(data.filterValue2);
        }
      }
      let options = this.getOperationOptions(fieldType);

      data = {
        ...data,
        operationOptions: options,
        expanded: false,
        searchValue: null,
        showLoader: false,
        selectionList: [],
        selectedValue: null,
        view: 'search'
      };

      return data;
    });

    this.columnOptions = this.columnDetails.map(x => {
      return { bind: x.bind, columnDisplay: x.columnName, disableFilter: x.disableFilter };
    });

    this.defaultColumn = this.columnOptions[0].bind;
    this.defaultOperationOptions = this.getOperationOptions(this.columnDetails[0].fieldType);

    this.filterDataDatasource.data = this.filterData;

    this.show = true;
  }

  getOperationOptions(fieldType: string): any[] {
    switch (fieldType) {
      case '0':
      case '1':
      case '4':
      case '9':
        return ReportConstants.filterColumnOperationsTypeString;

      case '2':
      case '3':
      case '5':
      case '6':
      case '7':
      case '8':
      case '10':
      case '11':
        return ReportConstants.filterColumnOperationsTypeNumber;
    }

  }

  addFilter() {
    let newFilter = {
      columnName: this.defaultColumn,
      filterValue: '',
      operation: this.defaultOperationOptions[0].value,
      operationOptions: this.defaultOperationOptions,
      filterValue2: '',
      expanded: false,
      searchValue: null,
      showLoader: false,
      selectionList: [],
      selectedValue: null,
      view: 'search'
    };

    this.filterData.push(newFilter);

    this.filterDataDatasource.data = this.filterData;
    this.table.renderRows();
  }

  deleteFilter(index: number) {
    if (this.deletingFilter) { return; }
    this.deletingFilter = true;

    this.filterData.splice(index, 1);
    this.filterDataDatasource.data = this.filterData;

    this.deletingFilter = false;
    this.table.renderRows();
  }

  search(data, index) {
    if (data.showLoader) { return; }
    data.showLoader = true;

    this.reportService.getReportFilterSearch(this.reportId, data.columnName, data.searchValue)
      .subscribe(resp => {
        data.selectionList = resp;
        data.showLoader = false;
        data.view = 'select';
      });
  }

  backToSearch(data) {
    data.searchValue = null;
    data.selectedValue = null;
    data.view = 'search';
  }

  select(data) {
    data.filterValue = data.selectedValue;
    data.searchValue = null;
    data.selectedValue = null;
    data.view = 'search';
    data.expanded = false;
  }

  columnNameChanged(i, $event) {

    let bind = this.filterData[i].columnName;
    let fieldType = this.columnDetails.filter(y => y.bind === bind)[0].fieldType;
    let options = this.getOperationOptions(fieldType);

    this.filterData[i].operation = options[0].value;
    this.filterData[i].operationOptions = options;
    this.filterDataDatasource.data = this.filterData;

  }

  hideColumn(index: number) {
    this.showedColumns[index].show = false;
    let col = this.showedColumns.splice(index, 1);
    this.hiddenColumns.push(col[0]);

    let removeSortIndex = this.sortedColumns.findIndex(x => x.columnNumber === col[0].columnNumber);

    if (removeSortIndex > -1) {
      this.removeFromSort(removeSortIndex);
    }
  }

  showColumn(index: number) {
    this.hiddenColumns[index].show = true;
    let col = this.hiddenColumns.splice(index, 1);
    this.showedColumns.push(col[0]);
  }

  removeFromSort(index: number) {
    this.sortedColumns[index].order = 'ASC';
    let col = this.sortedColumns.splice(index, 1);
    this.unsortedColumns.push(col[0]);
  }

  addToSort(index: number) {
    let col = this.unsortedColumns.splice(index, 1);
    this.sortedColumns.push(col[0]);
  }

  drop(event: CdkDragDrop<any[]>) {
    if (event.previousContainer === event.container) {
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
    } else {
      transferArrayItem(event.previousContainer.data,
        event.container.data,
        event.previousIndex,
        event.currentIndex);
    }
  }

  dropSort(event: CdkDragDrop<any[]>) {
    if (event.previousContainer === event.container) {
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
    } else {
      transferArrayItem(event.previousContainer.data,
        event.container.data,
        event.previousIndex,
        event.currentIndex);
    }
  }

  showSearchButton(index) {
    let bind = this.filterData[index].columnName;
    let fieldType = this.columnDetails.find(x => x.bind === bind).fieldType;
    if (['2', '3', '5', '6', '8'].includes(fieldType)) {
      return false;
    }
    return true;
  }

  isCalendarFilter(bind) {
    let fieldType = this.columnDetails.find(x => x.bind === bind).fieldType;

    if (fieldType === '5') {
      return true;
    }
    return false;
  }
}
