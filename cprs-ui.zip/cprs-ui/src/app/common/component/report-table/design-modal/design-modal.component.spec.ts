import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DesignModalComponent } from './design-modal.component';

describe('DesignModalComponent', () => {
  let component: DesignModalComponent;
  let fixture: ComponentFixture<DesignModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DesignModalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DesignModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
