export class ReportSortDetails {
    bind: string;
    order: string;
    columnName: string;
    columnNumber: number;
}
