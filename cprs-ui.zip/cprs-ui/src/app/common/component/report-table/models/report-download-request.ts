export class ReportDownloadRequest {
    input: any;
    colTitles: any;
    noOfSortedCols: number;
    noOfFilterCols: number;
    appId: number;
    rptType: number;
    rptId: number;
}
