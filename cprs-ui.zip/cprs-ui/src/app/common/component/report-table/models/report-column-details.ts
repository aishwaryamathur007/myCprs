export class ReportColumnDetails {
    columnNumber: number;
    bind: string;
    fieldType: number;
    dataType: number;
    sqlColName: string;
    colTitle: string;
    formulaTx: string;

}
