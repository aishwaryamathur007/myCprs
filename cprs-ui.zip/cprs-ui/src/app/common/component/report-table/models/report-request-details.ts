import { ReportColumnDetails } from 'src/app/common/component/report-table/models/report-column-details';
import { ReportFilter } from 'src/app/common/component/report-table/models/report-filter';
import { ReportSortDetails } from 'src/app/common/component/report-table/models/report-sort-details';

export class ReportRequestDetails {

    appId: number;
    reportId: number;
    filter: ReportFilter[] = [];
    originFilter: ReportFilter[] = [];
    origin: string = '4';
    listOfColumnDetails: ReportColumnDetails[] = [];
    listOfSortingDetail: ReportSortDetails[] = [];
    webUId: string;
    extras: any;
}
