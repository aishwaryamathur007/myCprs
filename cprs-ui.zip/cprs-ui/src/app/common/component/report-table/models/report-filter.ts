export class ReportFilter {
    columnName: string;
    filterValue: string;
    operation: string;
}
