import { ReportFilter } from 'src/app/common/component/report-table/models/report-filter';

export class ReportSavePackage {
    appId: string;
    appName: string;
    origin: string;
    reportId: string;
    dataareanm: string;
    rptCodeNmTx: string;
    sortOnColNum: string;
    sortByOrder: string;
    currentApplLvl: string;
    reportbkmk: string;
    designops: string;
    reportbkmknm: string;
    bkmkNmTx: string;
    filter: ReportFilter[];
    colsOrder: string[];
    originFilter: ReportFilter[];
}



