import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ReportTableService } from 'src/app/common/component/report-table/service/report-table.service';
import { NestedTreeControl } from '@angular/cdk/tree';
import { MatTreeNestedDataSource } from '@angular/material/tree';
import { NotificationService } from 'src/app/common/services/notification.service';
import { ReportManagement } from 'src/app/common/component/my-reports/models/report-management';
import { MyReportsService } from 'src/app/common/component/my-reports/service/my-reports.service';
import { ReportSavePackage } from 'src/app/common/component/report-table/models/report-save-package';

@Component({
  selector: 'app-save-my-report-modal',
  templateUrl: './save-my-report-modal.component.html',
  styleUrls: ['./save-my-report-modal.component.scss']
})
export class SaveMyReportModalComponent implements OnInit {

  view: string = '';
  show = false;
  locationData: any;

  hintText = '';
  mode = '';
  treeControl = new NestedTreeControl<any>(node => node.children);
  dataSource = new MatTreeNestedDataSource<any>();
  addNameText = '';
  selectedFolder = '';
  flatData: any[] = [];
  mapLookupData: any = {};
  pathArray: string[] = [];
  selectedNode: any;
  currentParentLoc: any;
  originalName: any;
  actionPending: string;
  reportSavePackage: ReportSavePackage;
  userDetails: any;
  bkmkId: any;

  constructor(public dialogRef: MatDialogRef<SaveMyReportModalComponent>,
    private reportService: ReportTableService,
    private notifService: NotificationService,
    private myReportService: MyReportsService,
    @Inject(MAT_DIALOG_DATA) public data: any) {

    this.dialogRef.addPanelClass('save-my-reports-dialog');
    this.dialogRef.disableClose = true;
    this.view = this.data.view;
    this.originalName = this.data.name;
    this.currentParentLoc = this.data.currentParentLoc;
    this.reportSavePackage = this.data.reportSavePackage;
    this.userDetails = this.data.userDetails;
    this.bkmkId = this.data.bkmkId;
  }

  ngOnInit(): void {
    this.getData();
  }

  async getData() {
    this.show = false;
    await this.reportService.getUserLocations(this.userDetails.attuid).toPromise().then(resp => {
      this.flatData = resp.flatData;
      this.flatData.unshift({
        LOC_ID: 0,
        LOC_NM_TX: 'My Reports',
        PARNT_LOC_ID: -1
      });
      this.setMapLookup();
      this.dataSource.data = resp.tree;
      this.show = true;
    });

    if (this.view === 'update') {
      this.mode = 'Update Report';
      this.addNameText = this.data.name;
      this.hintText = '';
    }

    this.show = true;


  }

  hasChild = (_: number, node: any) => !!node.children && node.children.length > 0;

  isTablet(): boolean {
    if (window.screen.width <= 1024) {
      return true;
    }

    return false;
  }

  addFolder(node) {
    this.pathArray = [];
    this.addNameText = null;
    this.mode = 'Folder';
    this.hintText = `Adding folder to path`;
    this.selectedNode = node;
    this.getRootPath(node);
  }

  addSubmit() {
    if (this.mode === 'Folder') {
      this.addFolderSubmit();
    } else {
      this.addReportSubmit();
    }
  }

  addReportSubmit() {
    this.actionPending = 'add';
    let request: ReportManagement = new ReportManagement();
    request.appId = +this.reportSavePackage.appId;
    request.locId = this.selectedNode.LOC_ID;
    request.mode = 'ADD';
    request.bkmkPkgTx = this.reportSavePackage;
    request.reportName = this.addNameText;
    request.reportId = +this.reportSavePackage.reportId;
    request.userId = this.userDetails.attuid;

    this.myReportService.changeReport(request).subscribe(resp => {
      this.notifService.showSuccessNotification(`Successfully added report - ${this.addNameText} to My Reports`);
      this.closeForAdd();
      this.actionPending = null;
    }, err => {
      this.actionPending = null;
    });

  }

  updateSubmit(type = 'update') {
    this.actionPending = type;
    let request: ReportManagement = new ReportManagement();
    request.appId = +this.reportSavePackage.appId;
    let successMessage = '';
    if (type === 'moveAndUpdate') {
      successMessage = `Successfully updated report - ${this.addNameText} and moved to ${this.selectedNode.LOC_NM_TX}`;
      request.locId = this.selectedNode.LOC_ID;
    } else {
      successMessage = `Successfully updated report - ${this.addNameText}`;
      request.locId = -1;
    }

    request.mode = 'UPDATE';
    request.bkmkPkgTx = this.reportSavePackage;
    request.reportName = this.addNameText;
    request.reportId = +this.reportSavePackage.reportId;
    request.userId = this.userDetails.attuid;
    request.bkmkId = this.bkmkId;

    this.myReportService.changeReport(request).subscribe(resp => {
      this.notifService.showSuccessNotification(successMessage);
      this.closeForUpdate();
      this.actionPending = null;
    }, err => {
      this.actionPending = null;
    });

  }

  addFolderSubmit() {
    this.actionPending = 'add';

    this.reportService.addBookmarkLocation(this.addNameText, this.selectedNode.LOC_ID, this.userDetails.attuid).subscribe(resp => {
      this.notifService.showSuccessNotification(`Successfully added new location - ${this.addNameText}`);
      this.getData();

      this.actionPending = null;
    }, err => {
      this.actionPending = null;
    });
  }

  addReport(node) {
    this.pathArray = [];
    this.addNameText = null;
    this.mode = 'Report';
    this.hintText = `Adding report to path`;
    this.selectedNode = node;
    this.getRootPath(node);
  }

  moveIntoFolder(node) {

    this.pathArray = [];
    this.addNameText = this.data.name;
    this.mode = 'Move Report';
    this.hintText = `Moving report to path:`;
    this.selectedNode = node;
    this.getRootPath(node);
  }

  updateReport(node) {
    this.pathArray = [];
    this.addNameText = this.data.name;
    this.mode = 'Move Report';
    this.hintText = `Moving report to path:`;
    this.selectedNode = node;
    this.getRootPath(node);
  }

  cancelUpdateAction() {
    this.mode = 'Update Report';
    this.addNameText = this.data.name;
    this.hintText = '';
  }

  setMapLookup() {
    for (let i = 0; i < this.flatData.length; i += 1) {
      this.mapLookupData[this.flatData[i].LOC_ID] = i;
    }
  }

  getRootPath(node) {
    this.pathArray.unshift(node.LOC_NM_TX);
    if (node.LOC_ID < 0) {
      return;
    }

    while (node.LOC_ID > 0) {
      this.getRootPath(this.flatData[this.mapLookupData[node.PARNT_LOC_ID]]);
      return;
    }

  }

  closeForUpdate() {
    this.dialogRef.close({ action: 'reload-table' });
  }

  closeForAdd() {
    this.dialogRef.close({ action: 'reload-table-add', reportName: this.addNameText });
  }
}
