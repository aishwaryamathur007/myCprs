import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SaveMyReportModalComponent } from './save-my-report-modal.component';

describe('SaveMyReportModalComponent', () => {
  let component: SaveMyReportModalComponent;
  let fixture: ComponentFixture<SaveMyReportModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SaveMyReportModalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SaveMyReportModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
