import { EventEmitter, ChangeDetectionStrategy, ChangeDetectorRef, Component, Input, OnChanges, OnInit, Output, SimpleChanges, ViewChild, AfterViewInit, ElementRef, Renderer2 } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatTable, MatTableDataSource } from '@angular/material/table';
import { DesignModalComponent } from 'src/app/common/component/report-table/design-modal/design-modal.component';
import { ReportColumnDetails } from 'src/app/common/component/report-table/models/report-column-details';
import { ReportFilter } from 'src/app/common/component/report-table/models/report-filter';
import { ReportRequestDetails } from 'src/app/common/component/report-table/models/report-request-details';
import { ReportSortDetails } from 'src/app/common/component/report-table/models/report-sort-details';
import { SaveMyReportModalComponent } from 'src/app/common/component/report-table/save-my-report-modal/save-my-report-modal.component';
import { ReportTableService } from 'src/app/common/component/report-table/service/report-table.service';
import * as  FileSaver from 'file-saver';
import { DatePipe } from '@angular/common';
import { MyReportsService } from 'src/app/common/component/my-reports/service/my-reports.service';
import { ReportSavePackage } from 'src/app/common/component/report-table/models/report-save-package';
import * as _ from 'lodash-es';
import { UserDetails } from '../../../shared/service/user.service';
import { ReportDownloadRequest } from 'src/app/common/component/report-table/models/report-download-request';
import { Router } from '@angular/router';

@Component({
  selector: 'report-table',
  templateUrl: './report-table.component.html',
  styleUrls: ['./report-table.component.scss'],
  providers: [DatePipe]
})

export class ReportTableComponent implements OnInit, OnChanges, AfterViewInit {

  @Input() appId: number;
  @Input() rptId: number;
  @Input() userDetails: UserDetails;
  @Input() hideHeader: boolean = false;
  @Input() reportExtras: any = null;
  @Input() bookMarkId: any = 0;
  @Input() bookMarkLocation: string;
  @Input() originalFilter: ReportFilter[];
  @Input() fromMyReports: boolean = false;
  @Input() colsOrder = null;
  @Input() backButton?: boolean = false;
  @Output() reloadMyReports: EventEmitter<any> = new EventEmitter();
  @Output() openSubReportAction: EventEmitter<any> = new EventEmitter();

  reportSettings: any;
  tableDataSource: MatTableDataSource<any> = new MatTableDataSource();
  columnDetails: any[];
  columndBindsToDisplay: string[];
  pageTotalFooterBinds: string[];
  visibleColumnDetails: any[];
  tableData: any[];
  paginator: MatPaginator;
  pageSize = 100;
  colSetting: any;
  loading: boolean = true;
  totalDetails: any;
  paginatorLoaded: boolean = false;
  filter: ReportFilter[] = [];
  sortOrder: ReportSortDetails[] = [];
  donwloading: any;
  showTotals: any = true;
  hasUpdateAccess: any = false;
  showPageTotals: boolean = true;
  goToPage = 1;
  pageNumbers = [];
  errorData: boolean = false;

  @ViewChild(MatTable, { static: false }) table: MatTable<any>;

  @ViewChild('paginator', { static: false }) set matPaginator(mp: MatPaginator) {
    if (mp && this.tableDataSource) {
      this.paginator = mp;
      this.tableDataSource.paginator = this.paginator;
      this.paginatorLoaded = true;
      // Adding the whole data to datasource after paginator is available on DOM.
      this.tableDataSource.data = this.tableData;
      setTimeout(() => {
        let noOfPages = this.tableDataSource.paginator.getNumberOfPages();
        this.pageNumbers = [...Array(noOfPages)].map((element, index) => index + 1);
        this.pageEvent(null);
        this.cdr.detectChanges();
      }, 300);

    }
  }

  constructor(private service: ReportTableService,
    private myReportsService: MyReportsService,
    private dialog: MatDialog,
    private cdr: ChangeDetectorRef,
    private datePipe: DatePipe,
    private router: Router,
    public el: ElementRef, public renderer: Renderer2) {
  }

  ngAfterViewInit(): void {

  }

  onScroll() {

  }

  back() {
    this.router.navigate(['/application-reports']);
  }

  ngOnChanges(changes: SimpleChanges): void {
    this.cdr.detectChanges();
  }

  ngOnInit(): void {
    this.getSettingsData();
  }

  async getSettingsData() {
    this.loading = true;
    this.filter = this.originalFilter ? this.originalFilter : [];

    await this.service.getReportSettings(this.appId + '', this.rptId + '', this.bookMarkId, this.colsOrder).toPromise().then(resp => {
      this.reportSettings = resp[0];
      this.columnDetails = this.reportSettings.colSettings;
      this.sortOrder = this.reportSettings.sortOrder;
      if (this.bookMarkId) {
        this.filter = this.reportSettings.originalSettingsData.filter ?? [];
      }
      this.setVisibleColumns(this.columnDetails);
    });

    if (this.bookMarkId) {
      await this.myReportsService.getUserOwnerAccess(this.bookMarkId, this.userDetails.attuid).toPromise().then(resp => {
        this.hasUpdateAccess = resp;
      });
    }

    this.getReportData();
  }

  async getReportData() {
    this.loading = true;
    this.paginatorLoaded = false;
    let reportRequestDetails: ReportRequestDetails = new ReportRequestDetails();
    reportRequestDetails.appId = +this.appId;
    reportRequestDetails.reportId = +this.rptId;
    reportRequestDetails.originFilter = this.originalFilter;
    let filterArr = this.filter;

    filterArr.forEach(e => {
      if (e.operation === 'like' || e.operation === 'not like') {
        e.filterValue = e.filterValue.split('*').join('%');
        if (e.filterValue.charAt(e.filterValue.length - 1) !== '%') {
          e.filterValue = e.filterValue + '%';
        }
      }

    });
    reportRequestDetails.filter = filterArr;
    reportRequestDetails.origin = '0';

    let visibleColumns: ReportColumnDetails[] = this.visibleColumnDetails.map(x => {
      return {
        columnNumber: x.columnNumber,
        bind: x.bind,
        colTitle: x.columnName,
        dataType: x.dataType,
        fieldType: x.fieldType,
        formulaTx: x.formulaTx,
        sqlColName: x.sqlColName
      };
    });

    let sortDetails: ReportSortDetails[] = this.sortOrder.map(x => {

      return {
        bind: x.bind,
        columnName: x.columnName,
        order: x.order,
        columnNumber: x.columnNumber
      };
    });

    reportRequestDetails.listOfColumnDetails = visibleColumns;
    reportRequestDetails.listOfSortingDetail = sortDetails;
    reportRequestDetails.webUId = this.userDetails.attuid;
    reportRequestDetails.extras = this.reportExtras;
    this.tableDataSource.paginator = this.paginator;
    this.errorData = false;
    await this.service.getReportData(reportRequestDetails).toPromise().then(resp => {
      console.log(resp);
      if (resp === null) {
        this.errorData = true;
      }
      this.tableData = resp === null ? [] : resp;
      // Adding the only first page to initate paginator and decrease initial load time.
      this.tableDataSource = new MatTableDataSource(this.tableData.slice(0, this.pageSize));
      this.loading = false;
    });

    this.cdr.detectChanges();
  }

  setVisibleColumns(details: any[]) {
    this.columndBindsToDisplay = details.filter(x => x.show).map(a => a.bind);
    this.columndBindsToDisplay.unshift('LINE_NB');
    this.visibleColumnDetails = details.filter(x => x.show);
    this.pageTotalFooterBinds = this.visibleColumnDetails.map(x => x.bind + '_PAGE');
    this.pageTotalFooterBinds.unshift('LINE_NB_PAGE');

    let sumColumnCount = this.visibleColumnDetails.filter(ele => ele.dataType === '2')?.length ?? 0;
    this.showTotals = sumColumnCount ? true : false;

    this.visibleColumnDetails.forEach(ele => {
      ele['_sortType'] = null;
    });

    this.sortOrder.forEach((ele, index) => {
      let element = this.visibleColumnDetails.find(x => x.columnNumber === ele.columnNumber);
      if (element) {
        element['_sortType'] = ele.order;
      } else {
        this.removeFromSort(index);
      }
    });

    if (!this.sortOrder.length) {
      let defaultSort = {
        bind: this.visibleColumnDetails[0].bind,
        order: 'ASC',
        columnName: this.visibleColumnDetails[0].columnName,
        columnNumber: this.visibleColumnDetails[0].columnNumber
      };
      this.visibleColumnDetails[0]['_sortType'] = 'ASC';
      this.sortOrder.push(defaultSort);
    }
  }

  removeFromSort(index) {
    this.sortOrder.splice(index, 1);
  }

  design(tabIndex: number) {
    const dialogRef = this.dialog.open(DesignModalComponent, {
      data: {
        columnDetails: _.cloneDeep(this.columnDetails),
        sortDetails: _.cloneDeep(this.sortOrder),
        filter: _.cloneDeep(this.filter),
        defaultTabIndex: tabIndex,
        reportId: +this.rptId
      },
      width: '90%',
    });

    dialogRef.afterClosed().subscribe(val => {
      if (val) {
        this.columnDetails = val.columnDetails;
        this.sortOrder = val.sortDetails;

        this.filter = val.filterDetails;
        this.setVisibleColumns(this.columnDetails);
        this.getReportData();
        this.cdr.detectChanges();
      }
    });
  }

  saveToMyReports(view) {

    let reportSavePackage: ReportSavePackage = new ReportSavePackage();
    reportSavePackage.dataareanm = this.reportSettings.originalSettingsData.RPT_NM_TX;
    reportSavePackage.designops = '';
    reportSavePackage.reportId = this.rptId + '';
    reportSavePackage.origin = '0';
    reportSavePackage.currentApplLvl = this.reportSettings.originalSettingsData.currentApplLvl ?? '1';
    reportSavePackage.filter = this.filter;
    reportSavePackage.reportbkmknm = this.bookMarkId ? this.reportSettings.originalSettingsData.reportbkmknm : null;
    reportSavePackage.reportbkmk = this.reportSettings.originalSettingsData.reportbkmk ?? '0';
    let columnOrder = this.visibleColumnDetails.map(x => x.columnNumber);
    reportSavePackage.colsOrder = columnOrder;
    let sortColumns = this.sortOrder.map(x => x.columnNumber).join(',');
    let sortColumnOrderValue = this.sortOrder.map(x => x.order).join(',');
    reportSavePackage.sortByOrder = sortColumnOrderValue;
    reportSavePackage.sortOnColNum = sortColumns;
    reportSavePackage.appId = this.appId + '';
    reportSavePackage.appName = this.reportSettings.originalSettingsData.APPL_NM_TX;
    reportSavePackage.rptCodeNmTx = this.reportSettings.rptCodeName;

    const dialogRef = this.dialog.open(SaveMyReportModalComponent, {
      data: {
        view: view,
        name: this.reportSettings.reportName,
        currentParentLoc: this.bookMarkLocation,
        reportSavePackage: reportSavePackage,
        userDetails: this.userDetails,
        bkmkId: this.bookMarkId
      },
      width: '95vw',
    });

    dialogRef.afterClosed().subscribe(val => {
      if (val) {
        if (val.action === 'reload-table') {
          if (!this.fromMyReports) {
            this.getSettingsData();
          } else {
            this.reloadMyReports.emit('reload-my-reports');
          }

        } else if (val.action === 'reload-table-add') {
          if (this.fromMyReports) {
            this.reloadMyReports.emit({ action: 'reload-my-reports-add', reportName: val.reportName });
          }
        }
      }
    });
  }

  getTotal(columnName: string) {
    return this.tableData.map(t => t[columnName]).reduce((acc, value) => acc + value, 0);
  }

  getPageTotal(columnName: string) {
    let pageIndex = this.tableDataSource.paginator.pageIndex;
    let pageSize = this.tableDataSource.paginator.pageSize;
    let startIndex = pageSize * pageIndex;
    let endIndex = startIndex + pageSize;
    endIndex = endIndex > this.tableData.length ? this.tableData.length : endIndex;
    return this.tableData.map(t => t[columnName]).slice(startIndex, endIndex).reduce((acc, value) => acc + value, 0);
  }

  getPageIndex(listIndex: string) {
    if (this.tableDataSource.paginator) {
      let pageIndex = this.tableDataSource.paginator.pageIndex;
      let pageSize = this.tableDataSource.paginator.pageSize;
      this.cdr.detectChanges();
      return pageIndex * pageSize + listIndex;
    }

  }

  async download() {
    if (this.donwloading) { return; }

    this.donwloading = true;
    let totalValue = { LINE_NB: 'Total' };
    this.visibleColumnDetails.forEach(x => {
      if (x.dataType === '2') {
        totalValue = { ...totalValue, ... { [x.bind]: this.getTotal(x.bind) } };
      } else {
        totalValue = { ...totalValue, ... { [x.bind]: null } };
      }

    });

    let data = _.cloneDeep(this.tableData);
    data.push(totalValue);
    let titleDetails = {};
    this.visibleColumnDetails.forEach(x => {
      titleDetails = { ...titleDetails, ...{ [x.bind]: x.columnName } };
    });

    let requestBody: ReportDownloadRequest = {
      input: data,
      colTitles: titleDetails,
      noOfSortedCols: this.sortOrder.length,
      noOfFilterCols: this.filter.length,
      appId: this.appId,
      rptType: 0,
      rptId: this.rptId
    };

    await this.service.downloadReport(requestBody).toPromise().then(resp => {
      let date = this.datePipe.transform(Date.now(), 'yyyy-MM-dd');
      if (resp) {
        FileSaver.saveAs(resp, this.reportSettings.reportName + ' ' + date + '.xlsx');
      }
      this.donwloading = false;
    });
  }

  isTablet(): boolean {
    if (window.screen.width <= 1024) {
      return true;
    }

    return false;
  }

  openSubReport(rowData) {
    this.openSubReportAction.emit({
      subReportDetails: this.reportSettings.subReportDetails,
      rowData: rowData
    });

  }

  pageEvent(event) {
    if (this.tableDataSource.paginator.getNumberOfPages() > 1) {
      this.showPageTotals = true;
    } else {
      this.showPageTotals = false;
    }

    if (this.tableDataSource.paginator.getNumberOfPages() !== this.pageNumbers.length) {
      this.updateGoToArray();
    }

    if (event) {
      this.goToPage = event.pageIndex + 1;
    }
    this.cdr.detectChanges();
  }

  updateGoToArray() {
    this.goToPage = 1;
    let noOfPages = this.tableDataSource.paginator.getNumberOfPages();
    this.pageNumbers = [...Array(noOfPages)].map((element, index) => index + 1);
  }

  goToChange() {
    this.tableDataSource.paginator.pageIndex = this.goToPage - 1;
    const event: PageEvent = {
      length: this.tableDataSource.paginator.length,
      pageIndex: this.tableDataSource.paginator.pageIndex,
      pageSize: this.tableDataSource.paginator.pageSize
    };
    this.tableDataSource.paginator.page.next(event);
  }

  scrollToTop() {
    let scrollElement = document.getElementById('scroll-focus-element-' + this.rptId);
    scrollElement.scrollIntoView();
  }

  showBackToTop() {
    let scrollFocusElement = document.getElementById('scroll-focus-element-' + this.rptId);
    let tableContainer = document.getElementById('table-container-' + this.rptId);
    if (!scrollFocusElement || !tableContainer) { return false; }
    let scrollFocusVisible = this.isInViewport(scrollFocusElement);
    let containerVisible = this.isElementVisibleInViewportPercentage(tableContainer, 1);

    if (!scrollFocusVisible && containerVisible) {
      return true;
    }
    return false;

  }

  isElementVisibleInViewportPercentage(el, percentVisible) {
    let rect = el.getBoundingClientRect();
    let windowHeight = (window.innerHeight || document.documentElement.clientHeight);

    return !(
      Math.floor(100 - (((rect.top >= 0 ? 0 : rect.top) / +-rect.height) * 100)) < percentVisible ||
      Math.floor(100 - ((rect.bottom - windowHeight) / rect.height) * 100) < percentVisible
    );
  }

  isInViewport(element) {
    const rect = element.getBoundingClientRect();
    return (
      rect.top >= 0 &&
      rect.bottom <= (window.innerHeight || document.documentElement.clientHeight)
    );
  }

}
