import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DrilldownModalComponent } from './drilldown-modal.component';

describe('DrilldownModalComponent', () => {
  let component: DrilldownModalComponent;
  let fixture: ComponentFixture<DrilldownModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DrilldownModalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DrilldownModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
