import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ErrorNotificationService } from '../service/error-notification.service';
import * as _ from 'lodash-es';
import { NotificationService } from 'src/app/common/services/notification.service';

@Component({
  selector: 'fmc-error-details-dialog',
  templateUrl: './error-details-dialog.component.html',
  styleUrls: ['./error-details-dialog.component.scss'],
})
export class ErrorDetailsDialogComponent implements OnInit {
  errorDetails: any;
  now: Date = new Date();
  browser: any;
  app: any;

  constructor(
    public dialogRef: MatDialogRef<ErrorDetailsDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private errorService: ErrorNotificationService,
    private _notifService: NotificationService
  ) {
    this.errorDetails = data.errorDetails;
    this.browser = window.navigator.userAgent;
    this.app = this.data.app;
  }

  ngOnInit(): void {}
  sendErrorDetails() {
    this.errorService.sendErrorDetails(this.errorDetails).subscribe(
      (resp) => {
        console.log('Error Detail E-Mail sent Successfully.');
        this._notifService.showSuccessNotification(
          'Error Detail E-Mail sent Successfully.'
        );
      },
      (err) => {
        console.error(err);
        this._notifService.showErrorNotification(
          'Unable to send Error Detail E-Mail.'
        );
      }
    );
  }

  openLink() {
    const link = 'feedback'
    console.log(window.location.origin + '/' + link);
    location.href = window.location.origin + '/' + link;
  }
}
