import { Component, HostListener, Inject, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBarRef, MAT_SNACK_BAR_DATA } from '@angular/material/snack-bar';
import { ErrorDetailsDialogComponent } from 'src/app/common/component/error-notification/error-details-dialog/error-details-dialog.component';

@Component({
  selector: 'error-notification',
  templateUrl: './error-notification.component.html',
  styleUrls: ['./error-notification.component.scss']
})
export class ErrorNotificationComponent implements OnInit {

  color = '#a31b0b';

  @HostListener('click')
  onClick() {
    this.closeSnackbar();
  }

  constructor(private snackBarRef: MatSnackBarRef<ErrorNotificationComponent>,
    @Inject(MAT_SNACK_BAR_DATA) public data,
    private dialog: MatDialog) {
  }

  ngOnInit() {

  }

  closeSnackbar() {
    this.snackBarRef.dismiss();
  }

  showDetails() {
    let dialogRef = this.dialog.open(ErrorDetailsDialogComponent, {
      data: this.data,
      width: '80%'
    });
  }

}
