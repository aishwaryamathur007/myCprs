import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OrganiseReportsComponent } from './organise-reports.component';

describe('OrganiseReportsComponent', () => {
  let component: OrganiseReportsComponent;
  let fixture: ComponentFixture<OrganiseReportsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OrganiseReportsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OrganiseReportsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
