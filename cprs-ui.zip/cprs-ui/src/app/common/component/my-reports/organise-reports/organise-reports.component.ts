import { NestedTreeControl } from '@angular/cdk/tree';
import { Component, ElementRef, Injectable, Input, OnInit, Pipe, PipeTransform, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatTreeNestedDataSource } from '@angular/material/tree';
import { forkJoin, Observable } from 'rxjs';
import { ConfirmComponent } from 'src/app/common/component/confirm/confirm.component';
import { ConfigType } from 'src/app/common/component/confirm/model/confirm-config';
import { ReportManagement } from 'src/app/common/component/my-reports/models/report-management';
import { MyReportsService } from 'src/app/common/component/my-reports/service/my-reports.service';
import { NotificationService } from 'src/app/common/services/notification.service';
import { FormControl } from '@angular/forms';
import { map, startWith } from 'rxjs/operators';
import { MatChipInputEvent } from '@angular/material/chips';
import { MatAutocompleteSelectedEvent } from '@angular/material/autocomplete';

@Component({
  selector: 'organise-reports',
  templateUrl: './organise-reports.component.html',
  styleUrls: ['./organise-reports.component.scss']
})
export class OrganiseReportsComponent implements OnInit {

  @Input() treeData: any[];
  @Input() flatData: any[];
  @Input() userDetails: any;
  @Input() appId: any[];


  @ViewChild('userAccessInput', { static: false }) userAccessInput: ElementRef;

  mapLookupData: any = {};
  treeControl = new NestedTreeControl<any>(node => node.children);
  dataSource = new MatTreeNestedDataSource<any>();
  show: boolean = false;
  moveToFolderMode = false;
  view: string = null;
  actionPending: any;
  invisibleList: any[] = [];
  loadingList: boolean;
  selectFolder: any;
  actionReportName: any;
  pathArray: any = [];
  selectedReport: any;
  // Report Management Variables
  hasManageReportAccess: any;
  mrOwnerDetails: any;
  masterUserList: string[] = [];
  accessGrantedList: string[] = [];
  masterFilterValue: string = '';
  reportNameTextVal: string = null;

  userAccessControl = new FormControl();
  filteredUsers: Observable<any[]>;
  allGroups: string[] = [];
  allUsers: string[] = [];

  constructor(private service: MyReportsService,
    private notifService: NotificationService,
    private dialog: MatDialog) { }

  ngOnInit(): void {
    this.getData();
    this.setMapLookup();
    this.dataSource.data = this.treeData;
  }

  hasChild = (_: number, node: any) => !!node.children && node.children.length > 0;

  async getData() {

    this.getInvisibleCustomerReports();
    // this.dataSource._data.subscribe(data => {
    //   this.treeControl.toggle(data[0]);
    // });
    this.show = true;
  }

  getInvisibleCustomerReports() {
    this.loadingList = true;
    this.service.getInvisibleCustomReports(this.appId, this.userDetails.attuid).toPromise().then(resp => {
      this.invisibleList = resp;
      this.loadingList = false;
    });
  }

  setMapLookup() {
    for (let i = 0; i < this.flatData.length; i += 1) {
      this.mapLookupData[this.flatData[i].OPT_ID] = i;
    }
  }

  isTablet(): boolean {
    if (window.screen.width <= 1024) {
      return true;
    }

    return false;
  }

  deleteFolder(node) {
    if (this.actionPending) { return; }

    let request: ReportManagement = new ReportManagement();

    request.appId = node.APPL_ID;
    request.reportId = node.RPT_ID;
    request.userId = this.userDetails.attuid; // TODO: change later;
    request.locId = node.OPT_ID - 30000;
    request.mode = 'ORGANIZE';
    request.modeOfOrganizeReport = 'DELETEFOLDER';
    let folderName = node.OPT_NM_TX;

    const dialogRef = this.dialog.open(ConfirmComponent, {
      data: {
        type: ConfigType.Confirm,
        content: `Are you sure you want to delete folder: <b>${folderName}</b> ?` +
          '<br>' + 'Removing this folder will remove all folders contained in this folder and move all ' +
          'reports under My Reports(s).'
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.actionPending = 'deleteFolder';
        this.service.changeReport(request).subscribe(resp => {
          this.notifService.showSuccessNotification('Successfully removed the folder: ' + folderName);
          MyReportsService.reloadData.next(true);
          this.actionPending = null;
        }, err => {
          this.actionPending = null;
        });
      }
    });
  }

  deleteReportFromView(node) {
    if (this.actionPending) { return; }
    let request: ReportManagement = new ReportManagement();

    request.appId = node.APPL_ID;
    request.reportId = node.RPT_ID;
    request.userId = this.userDetails.attuid; // TODO: change later;
    request.mode = 'ORGANIZE';
    request.modeOfOrganizeReport = 'REMOVEREPORTFROMVIEW';
    request.reportName = node.OPT_NM_TX;
    request.bkmkId = node.BKMK_ID;
    let reportName = node.OPT_NM_TX;

    const dialogRef = this.dialog.open(ConfirmComponent, {
      data: {
        type: ConfigType.Confirm,
        content: `Are you sure you want to delete report <b>${reportName}</b> from view ?`
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.actionPending = 'deleteFromView';
        this.service.changeReport(request).subscribe(resp => {
          this.notifService.showSuccessNotification('Successfully removed report from view');
          this.getInvisibleCustomerReports();
          MyReportsService.reloadData.next(true);
          this.actionPending = null;
        }, err => {
          this.actionPending = null;
        });
      }
    });
  }

  addToView(report) {
    this.view = 'addReportToView';
    this.selectFolder = null;
    this.selectedReport = report;
    this.actionReportName = report.BKMK_NM_TX;
    this.pathArray = [];
  }

  moveToOtherFolder(report) {
    this.view = 'moveToFolder';
    this.selectFolder = null;
    this.selectedReport = report;
    this.actionReportName = report.OPT_NM_TX;
    this.pathArray = [];
  }

  getRootPath(node) {
    this.pathArray.unshift(node.OPT_NM_TX);
    if (node.OPT_ID < 19) {
      return;
    }

    while (node.OPT_ID > 19) {
      this.getRootPath(this.flatData[this.mapLookupData[node.PARNT_OPT_ID]]);
      return;
    }
  }

  selectedFolderChange(node) {
    this.selectFolder = node;
    this.pathArray = [];
    this.getRootPath(node);
  }

  cancelAction() {
    this.pathArray = [];
    this.selectFolder = null;
    this.selectedReport = null;
    this.view = null;
  }

  addToViewSubmit() {
    if (this.actionPending) { return; }
    let request: ReportManagement = new ReportManagement();
    let node = this.selectFolder;
    request.appId = node.APPL_ID;
    request.reportId = node.RPT_ID;
    request.userId = this.userDetails.attuid;
    request.locId = node.OPT_ID === 19 ? 0 : node.OPT_ID - 30000;
    request.mode = 'ORGANIZE';
    request.modeOfOrganizeReport = 'ADDTOVIEW';
    request.reportName = this.selectedReport.BKMK_NM_TX;
    request.bkmkId = this.selectedReport.BKMK_ID;

    let reportName = this.selectedReport.BKMK_NM_TX;

    this.actionPending = 'addToView';
    this.service.changeReport(request).subscribe(resp => {
      this.notifService.showSuccessNotification(`Successfully added report - ${reportName} to view`);
      this.getInvisibleCustomerReports();
      MyReportsService.reloadData.next(true);
      this.actionPending = null;
    }, err => {
      this.actionPending = null;
    });
  }

  moveToFolderSubmit() {
    if (this.actionPending) { return; }
    let request: ReportManagement = new ReportManagement();
    let node = this.selectFolder;
    request.appId = node.APPL_ID;
    request.reportId = node.RPT_ID;
    request.userId = this.userDetails.attuid;
    request.locId = node.OPT_ID === 19 ? 0 : node.OPT_ID - 30000;
    request.mode = 'ORGANIZE';
    request.modeOfOrganizeReport = 'MOVETOFOLDER';
    request.reportName = this.selectedReport.OPT_NM_TX;
    request.bkmkId = this.selectedReport.BKMK_ID;

    let reportName = this.selectedReport.OPT_NM_TX;
    let folderName = node.OPT_NM_TX;

    this.actionPending = 'moveToFolder';
    this.service.changeReport(request).subscribe(resp => {
      this.notifService.showSuccessNotification(`Successfully added report - ${reportName} into folder - ${folderName}`);
      this.getInvisibleCustomerReports();
      MyReportsService.reloadData.next(true);
      this.actionPending = null;
    }, err => {
      this.actionPending = null;
    });
  }

  async manageReport(node) {
    this.actionPending = 'manageReportLoad';
    this.view = 'manageReport';
    this.selectedReport = node;
    this.reportNameTextVal = node.OPT_NM_TX;

    this.hasManageReportAccess = false;
    await this.service.getOwnerDetails(this.selectedReport.BKMK_ID).toPromise().then(resp => {
      let ownerId = { ownerId: resp.ownerName };
      this.mrOwnerDetails = { ...resp.listOfMPIReportOwners[0], ...ownerId };
    });

    await this.service.getUserOwnerAccess(this.selectedReport.BKMK_ID, this.userDetails.attuid).toPromise().then(resp => {
      this.hasManageReportAccess = resp;
    });

    if (!this.hasManageReportAccess) {
      this.actionPending = null;
      return;
    }


    await this.service.getUserAccesGrantDetails(this.selectedReport.BKMK_ID, this.selectedReport.APPL_ID).then(resp => {
      this.masterUserList = resp.masterList;
      this.accessGrantedList = resp.accessList;
      this.allUsers = resp.allUsers;
      this.allGroups = resp.allGroups;

      this.actionPending = null;
    });

    this.filteredUsers = this.userAccessControl.valueChanges.pipe(
      startWith<any>(''),
      map((user: string | null) => {
        if (user) {
          return this._filter(user);
        } else {
          let visibleArray = this.masterUserList.filter(x => {
            return this.accessGrantedList.indexOf(x) < 0; // Returns true for items not found in b.
          });
          return visibleArray;
        }
      }
      ));
  }

  submitManageReport() {
    if (this.actionPending) { return; }
    let saveAccessData = this.accessGrantedList.map(x => {
      let valueString = '';
      if (this.allUsers.includes(x)) {
        let userId = x.substring(x.indexOf('(') + 1, x.indexOf(')'));
        valueString = `US:${userId}`;
      }
      if (this.allGroups.includes(x)) {
        valueString = `GP:${x}`;
      }

      return valueString;
    });

    let request: ReportManagement = new ReportManagement();
    let node = this.selectedReport;
    request.appId = node.APPL_ID;
    request.reportId = node.RPT_ID;
    request.userId = this.userDetails.attuid;
    request.mode = 'MANAGE';
    request.modeOfOrganizeReport = 'SUBMITCHANGES';
    request.bkmkId = this.selectedReport.BKMK_ID;
    request.reportName = this.reportNameTextVal;
    request.mpiReportUserDataDetails = saveAccessData;

    this.actionPending = 'mangeReportUpdate';
    this.service.changeReport(request).subscribe(resp => {
      this.notifService.showSuccessNotification(`Successfully updated report - ${this.reportNameTextVal}'s user access.'`);
      this.getInvisibleCustomerReports();
      MyReportsService.reloadData.next(true);
      this.view = null;

      this.actionPending = null;
    }, err => {
      this.actionPending = null;
    });

  }

  _filter(value: string): string[] {
    const filterValue = value.toLowerCase();
    let visibleArray = this.masterUserList.filter(x => {
      return this.accessGrantedList.indexOf(x) < 0; // Returns true for items not found in b.
    });
    return visibleArray.filter(user => user.toLowerCase().includes(filterValue));
  }

  add(event: MatChipInputEvent): void {
    const input = event.input;
    const value = event.value;
    if ((value || '').trim()) {
      this.accessGrantedList.push(value.trim());
    }
    if (input) {
      input.value = null;
    }
    this.userAccessControl.setValue(null);
  }

  remove(user: string): void {
    const index = this.accessGrantedList.indexOf(user);

    if (index >= 0) {
      this.accessGrantedList.splice(index, 1);
    }
  }

  selected(event: MatAutocompleteSelectedEvent): void {
    this.accessGrantedList.push(event.option.viewValue);
    this.userAccessInput.nativeElement.value = '';
    this.userAccessControl.setValue(null);
  }

  deleteReport() {
    if (this.actionPending) { return; }
    let request: ReportManagement = new ReportManagement();
    let node = this.selectedReport;

    request.reportId = node.RPT_ID;
    request.userId = this.userDetails.attuid;
    request.mode = 'MANAGE';
    request.modeOfOrganizeReport = 'DELETEREPORT';
    request.reportName = this.selectedReport.OPT_NM_TX;
    request.bkmkId = this.selectedReport.BKMK_ID;

    let reportName = this.selectedReport.OPT_NM_TX;

    const dialogRef = this.dialog.open(ConfirmComponent, {
      data: {
        type: ConfigType.Confirm,
        content: `Are you sure you want to delete report - <b>${reportName}</b>?`
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.actionPending = 'deleteReport';
        this.service.changeReport(request).subscribe(resp => {
          this.notifService.showSuccessNotification(`Successfully deleted report - ${reportName}`);
          this.getInvisibleCustomerReports();
          MyReportsService.reloadData.next(true);
          this.view = null;
          this.selectedReport = node;
          this.reportNameTextVal = node.OPT_NM_TX;

          this.hasManageReportAccess = false;
          this.actionPending = null;
        }, err => {
          this.hasManageReportAccess = false;
          this.actionPending = null;
        });
      }
    });

  }

  hasSubfolders(node) {
    let children = node.children;

    if (children.length) {
      let subfolderCount = children.filter(x => x.type === 'folder').length;
      if (subfolderCount > 0) {
        return true;
      }
    }
    return false;
  }
}
