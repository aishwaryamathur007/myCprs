// import { ReportSavePackage } from 'src/app/common/component/report-table/models/report-save-package';
import { ReportSavePackage } from '@report-table-library/common-report-table';

export class ReportManagement {
    appId: number;
    reportId: number;
    appName: string;
    bkmkId: number;
    reportName: string;
    mode: string;
    userId: string;
    locId: number;
    bkmkPkgTx: ReportSavePackage;
    modeOfOrganizeReport: string;
    mpiReportUserDataDetails: string[];
}
