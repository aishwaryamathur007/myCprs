import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { LinksManagement } from 'src/app/common/component/my-links/models/links-management';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class MyLinksService {

  static reloadData: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);

  constructor(private http: HttpClient) { }

  getVisbileLinks(userId: string, appId: string[]): Observable<any> {
    return this.http.get(environment.commonApiBaseUrl + '/reports/getVisibleLinks', {
      params: {
        userId: userId,
        appId: appId
      }
    }).pipe(map(response => {

      let array = this.listToTree(response);
      return { flatData: response, tree: array };
    }));
  }

  listToTree(list) {
    let mapLookupData = {};
    let currentNode;
    let result = [];

    for (let i = 0; i < list.length; i += 1) {
      mapLookupData[list[i].OPT_ID + ''] = i; // init the map lookup of each LOC_ID
      if (list[i].BKMK_ID > 0) {
        list[i].type = 'link';
      } else {
        list[i].type = 'folder';
        list[i].children = [];
      }
      // init the elements with children []
    }

    // tslint:disable-next-line: prefer-for-of
    for (let i = 0; i < list.length; i += 1) {
      currentNode = list[i];

      if (+currentNode.PARNT_OPT_ID > 0) {
        list[mapLookupData[currentNode.PARNT_OPT_ID]].children.unshift(currentNode);
      } else {
        result.unshift(currentNode);
      }
    }
    return result;
  }


  getInvisibleLinks(appId: string[], userId: string): Observable<any> {
    return this.http.get(environment.commonApiBaseUrl + '/reports/getInvisibleLinks', {
      params: {
        appId,
        userId
      }
    });
  }

  changeLink(request: LinksManagement): Observable<any> {
    return this.http.post<any>(environment.commonApiBaseUrl + '/reports/linkManagement', request, {
      responseType: 'text' as 'json'
    });
  }

}
