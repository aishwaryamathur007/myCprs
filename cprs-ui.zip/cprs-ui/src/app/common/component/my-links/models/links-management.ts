export class LinksManagement {
    userId: string;
    locId: number;
    locNmTx: string;
    displayName: string;
    linkId: number;
    modeOfOrganizeLink: string;
    linkTx: string;
    appId: number;
    reportId: number;
    reportName: string;

}
