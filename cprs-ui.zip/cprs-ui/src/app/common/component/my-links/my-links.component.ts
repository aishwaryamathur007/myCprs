import { NestedTreeControl } from '@angular/cdk/tree';
import { Component, Input, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatTreeNestedDataSource } from '@angular/material/tree';
import { AddLinkModalComponent } from 'src/app/common/component/my-links/components/add-link-modal/add-link-modal.component';
import { MyLinksService } from 'src/app/common/component/my-links/service/my-links.service';
import { UserDetails } from 'src/app/shared/service/user.service';

@Component({
  selector: 'my-links',
  templateUrl: './my-links.component.html',
  styleUrls: ['./my-links.component.scss']
})
export class MyLinksComponent implements OnInit {

  @Input() userDetails: UserDetails;
  @Input() appId: any[];

  flatData: any;
  treeControl = new NestedTreeControl<any>(node => node.children);
  dataSource = new MatTreeNestedDataSource<any>();
  mapLookupData: any = {};
  show: boolean = false;
  treeData: any;
  selectedTab = 0;

  hasChild = (_: number, node: any) => !!node.children && node.children.length > 0;


  constructor(private service: MyLinksService,
    private dialog: MatDialog) { }

  ngOnInit(): void {
    this.getData();
    MyLinksService.reloadData.subscribe(val => {
      if (val) {
        this.getData();
      }
    });
  }

  async getData() {
    this.show = false;

    await this.service.getVisbileLinks(this.userDetails.attuid, this.appId).toPromise().then(resp => {
      this.flatData = resp.flatData;
      this.setMapLookup();
      this.treeData = resp.tree;
      this.dataSource.data = resp.tree;
      this.treeControl.dataNodes = resp.tree;

      this.show = true;
      this.treeControl.expandAll();
    });
  }

  setMapLookup() {
    for (let i = 0; i < this.flatData.length; i += 1) {
      this.mapLookupData[this.flatData[i].OPT_ID] = i;
    }
  }

  reloadAction(event) {

    if (event.action === 'reload-my-reports') {
      this.getData();
    }
  }

  openLink(node) {
    let link: string = node.OPT_CODE_NM_TX;
    if (link.includes('javascript')) {
      link = link.substring(link.indexOf('(') + 2, link.indexOf(')') - 1);
    }
    link = link.includes('http') ? link : 'http://' + link;

    window.open(link, '_blank');
  }

  addLink() {
    const dialogRef = this.dialog.open(AddLinkModalComponent, {
      data: {
        appId: this.appId,
        userDetails: this.userDetails
      },
      width: '90%',
    });

    dialogRef.afterClosed().subscribe(val => {
      if (val === 'reload') {
        this.getData();
      }
    });
  }


}
