import { NestedTreeControl } from '@angular/cdk/tree';
import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatTreeNestedDataSource } from '@angular/material/tree';
import { LinksManagement } from 'src/app/common/component/my-links/models/links-management';
import { MyLinksService } from 'src/app/common/component/my-links/service/my-links.service';
import { NotificationService } from 'src/app/common/services/notification.service';
import { UserDetails } from 'src/app/shared/service/user.service';

@Component({
  selector: 'add-link-modal',
  templateUrl: './add-link-modal.component.html',
  styleUrls: ['./add-link-modal.component.scss']
})
export class AddLinkModalComponent implements OnInit {

  view: string = '';
  show = false;
  mode = '';

  treeControl = new NestedTreeControl<any>(node => node.children);
  dataSource = new MatTreeNestedDataSource<any>();
  addLinkText = '';
  addLinkUrl = '';
  flatData: any[] = [];
  mapLookupData: any = {};
  pathArray: string[] = [];
  selectedNode: any;
  currentParentLoc: any;
  originalName: any;
  actionPending: string;
  userDetails: UserDetails;
  treeData: any;
  hintText: string;
  appId: any;
  dataChanged: boolean = false;

  hasChild = (_: number, node: any) => !!node.children && node.children.length > 0;

  constructor(public dialogRef: MatDialogRef<AddLinkModalComponent>,
    private notifService: NotificationService,
    private service: MyLinksService,
    @Inject(MAT_DIALOG_DATA) public data: any) {

    this.dialogRef.addPanelClass('add-link-dialog');
    this.userDetails = this.data.userDetails,
      this.appId = this.data.appId;
  }

  ngOnInit(): void {
    this.getFolderData();
  }

  async getFolderData() {
    this.show = false;
    await this.service.getVisbileLinks(this.userDetails.attuid, this.appId).toPromise().then(resp => {
      this.flatData = resp.flatData;
      this.setMapLookup();
      this.treeData = resp.tree;
      this.dataSource.data = resp.tree;
      this.treeControl.dataNodes = resp.tree;
      this.mode = null;
      this.show = true;
    });
  }

  setMapLookup() {
    for (let i = 0; i < this.flatData.length; i += 1) {
      this.mapLookupData[this.flatData[i].OPT_ID] = i;
    }
  }

  getRootPath(node) {
    this.pathArray.unshift(node.OPT_NM_TX);
    if (node.OPT_ID < 41) {
      return;
    }

    while (node.OPT_ID > 41) {
      this.getRootPath(this.flatData[this.mapLookupData[node.PARNT_OPT_ID]]);
      return;
    }
  }

  addFolder(node) {
    this.pathArray = [];
    this.addLinkText = null;
    this.mode = 'Folder';
    this.hintText = `Adding folder to path`;
    this.selectedNode = node;
    this.getRootPath(node);
  }

  addLink(node) {
    this.pathArray = [];
    this.addLinkText = null;
    this.addLinkUrl = null;
    this.mode = 'Link';
    this.hintText = `Adding link to path`;
    this.selectedNode = node;
    this.getRootPath(node);
  }

  addLinkSubmit() {
    if (this.actionPending) { return; }
    let request: LinksManagement = new LinksManagement();
    let node = this.selectedNode;
    request.userId = this.userDetails.attuid;
    request.locId = node.OPT_ID === 41 ? 0 : node.OPT_ID - 50000;
    request.displayName = this.addLinkText;
    request.modeOfOrganizeLink = 'ADD';
    request.linkTx = this.addLinkUrl;
    let linkName = this.addLinkText;
    this.actionPending = 'add';

    this.service.changeLink(request).subscribe(resp => {
      this.notifService.showSuccessNotification(`Successfully added link - ${linkName}`);
      this.actionPending = null;
      this.closeToReload();
    }, err => {
      this.actionPending = null;
    });
  }

  addFolderSubmit() {
    if (this.actionPending) { return; }
    let request: LinksManagement = new LinksManagement();
    let node = this.selectedNode;
    request.userId = this.userDetails.attuid;
    request.locId = node.OPT_ID === 41 ? 0 : node.OPT_ID - 50000;
    request.locNmTx = this.addLinkText;
    request.modeOfOrganizeLink = 'ADDFOLDER';
    this.actionPending = 'addFolder';

    this.service.changeLink(request).subscribe(resp => {
      this.notifService.showSuccessNotification(`Successfully added folder - ${this.addLinkText}`);
      this.actionPending = null;
      this.dataChanged = true;
      this.getFolderData();
    }, err => {
      this.actionPending = null;
    });
  }

  close() {
    if (this.dataChanged) {
      this.closeToReload();
    } else {
      this.dialogRef.close(null);
    }

  }

  closeToReload() {
    this.dialogRef.close('reload');
  }

  isTablet(): boolean {
    if (window.screen.width <= 1024) {
      return true;
    }

    return false;
  }

  hasSubfolders(node) {
    let children = node.children;

    if (children.length) {
      let subfolderCount = children.filter(x => x.type === 'folder').length;
      if (subfolderCount > 0) {
        return true;
      }
    }
    return false;
  }



}
