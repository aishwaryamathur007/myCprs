import { NestedTreeControl } from '@angular/cdk/tree';
import { Component, Input, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatTreeNestedDataSource } from '@angular/material/tree';
import { ConfirmComponent } from 'src/app/common/component/confirm/confirm.component';
import { ConfigType } from 'src/app/common/component/confirm/model/confirm-config';
import { LinksManagement } from 'src/app/common/component/my-links/models/links-management';
import { MyLinksService } from 'src/app/common/component/my-links/service/my-links.service';
import { NotificationService } from 'src/app/common/services/notification.service';

@Component({
  selector: 'organise-links',
  templateUrl: './organise-links.component.html',
  styleUrls: ['./organise-links.component.scss']
})
export class OrganiseLinksComponent implements OnInit {

  @Input() treeData: any[];
  @Input() flatData: any[];
  @Input() userDetails: any;
  @Input() appId: any[];

  mapLookupData: any = {};
  treeControl = new NestedTreeControl<any>(node => node.children);
  dataSource = new MatTreeNestedDataSource<any>();
  show: boolean = false;
  view: string = null;
  actionPending: any;
  invisibleList: any[] = [];
  loadingList: boolean;
  selectFolder: any;
  pathArray: any[];
  selectedLink: any;
  actionLinkName: any;
  displayName: any;
  url: string;

  constructor(private service: MyLinksService,
    private notifService: NotificationService,
    private dialog: MatDialog) { }

  ngOnInit(): void {
    this.getData();
    this.setMapLookup();
    this.dataSource.data = this.treeData;
  }

  hasChild = (_: number, node: any) => !!node.children && node.children.length > 0;

  async getData() {

    this.getInvisibleLinks();
    // this.dataSource._data.subscribe(data => {
    //   this.treeControl.toggle(data[0]);
    // });
    if (this.dataSource.data.length > 0) {
      this.treeControl.toggle(this.dataSource.data[0]);
    }
    this.show = true;
  }

  getInvisibleLinks() {
    this.loadingList = true;
    this.service.getInvisibleLinks(this.appId, this.userDetails.attuid).toPromise().then(resp => {
      this.invisibleList = resp;
      this.loadingList = false;
    });
  }

  setMapLookup() {
    for (let i = 0; i < this.flatData.length; i += 1) {
      this.mapLookupData[this.flatData[i].OPT_ID] = i;
    }
  }

  isTablet(): boolean {
    if (window.screen.width <= 1024) {
      return true;
    }

    return false;
  }

  addToView(link) {
    this.view = 'addLinkToView';
    this.selectFolder = null;
    this.selectedLink = link;
    this.actionLinkName = link.BKMK_NM_TX;
    this.pathArray = [];
  }

  moveToOtherFolder(link) {
    this.view = 'moveToFolder';
    this.selectFolder = null;
    this.selectedLink = link;
    this.actionLinkName = link.OPT_NM_TX;
    this.pathArray = [];
  }

  getRootPath(node) {
    this.pathArray.unshift(node.OPT_NM_TX);
    if (node.OPT_ID < 41) {
      return;
    }

    while (node.OPT_ID > 41) {
      this.getRootPath(this.flatData[this.mapLookupData[node.PARNT_OPT_ID]]);
      return;
    }
  }

  selectedFolderChange(node) {
    this.selectFolder = node;
    this.pathArray = [];
    this.getRootPath(node);
  }

  hasSubfolders(node) {
    let children = node.children;

    if (children.length) {
      let subfolderCount = children.filter(x => x.type === 'folder').length;
      if (subfolderCount > 0) {
        return true;
      }
    }
    return false;
  }

  cancelAction() {
    this.pathArray = [];
    this.selectFolder = null;
    this.selectedLink = null;
    this.view = null;
  }

  addToViewSubmit() {
    if (this.actionPending) { return; }
    let request: LinksManagement = new LinksManagement();
    let node = this.selectFolder;
    request.userId = this.userDetails.attuid;
    request.locId = node.OPT_ID === 41 ? 0 : node.OPT_ID - 50000;
    request.linkId = this.selectedLink.LINK_ID;
    request.modeOfOrganizeLink = 'ADDTOVIEW';

    let linkName = this.selectedLink.LINK_NM_TX;
    this.actionPending = 'addToView';
    this.service.changeLink(request).subscribe(resp => {
      this.notifService.showSuccessNotification(`Successfully added link - ${linkName} to view`);
      this.getInvisibleLinks();
      MyLinksService.reloadData.next(true);
      this.actionPending = null;
    }, err => {
      this.actionPending = null;
    });
  }

  deleteLinkFromView(node) {
    if (this.actionPending) { return; }
    let request: LinksManagement = new LinksManagement();

    request.userId = this.userDetails.attuid; // TODO: change later;
    request.modeOfOrganizeLink = 'DELETEFROMVIEW';
    request.linkId = node.OPT_ID - 40000;
    let linkName = node.OPT_NM_TX;

    const dialogRef = this.dialog.open(ConfirmComponent, {
      data: {
        type: ConfigType.Confirm,
        content: `Are you sure you want to delete link <b>${linkName}</b> from view ?`
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.actionPending = 'deleteFromView';
        this.service.changeLink(request).subscribe(resp => {
          this.notifService.showSuccessNotification('Successfully removed link from view');
          this.getInvisibleLinks();
          MyLinksService.reloadData.next(true);
          this.actionPending = null;
        }, err => {
          this.actionPending = null;
        });
      }
    });
  }

  moveToFolderSubmit() {
    if (this.actionPending) { return; }
    let request: LinksManagement = new LinksManagement();
    let node = this.selectFolder;
    request.userId = this.userDetails.attuid;
    request.locId = node.OPT_ID === 41 ? 0 : node.OPT_ID - 50000;
    request.linkId = this.selectedLink.OPT_ID - 40000;
    request.modeOfOrganizeLink = 'MOVETOFOLDER';
    let linkName = this.selectedLink.LINK_NM_TX;
    let folderName = node.OPT_NM_TX;

    this.actionPending = 'moveToFolder';
    this.service.changeLink(request).subscribe(resp => {
      this.notifService.showSuccessNotification(`Successfully added link - ${linkName} into linkName - ${folderName}`);
      this.getInvisibleLinks();
      MyLinksService.reloadData.next(true);
      this.actionPending = null;
    }, err => {
      this.actionPending = null;
    });
  }

  deleteFolder(node) {
    if (this.actionPending) { return; }
    let request: LinksManagement = new LinksManagement();

    request.userId = this.userDetails.attuid;
    request.locId = node.OPT_ID === 41 ? 0 : node.OPT_ID - 50000;
    request.modeOfOrganizeLink = 'DELETEFOLDER';

    let folderName = node.OPT_NM_TX;

    const dialogRef = this.dialog.open(ConfirmComponent, {
      data: {
        type: ConfigType.Confirm,
        content: `Are you sure you want to delete folder: <b>${folderName}</b> ?` +
          '<br>' + 'Removing this folder will remove all folders contained in this folder and move all ' +
          'links under My Link(s).'
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.actionPending = 'deleteFolder';
        this.service.changeLink(request).subscribe(resp => {
          this.notifService.showSuccessNotification('Successfully removed the folder: ' + folderName);
          MyLinksService.reloadData.next(true);
          this.actionPending = null;
        }, err => {
          this.actionPending = null;
        });
      }
    });
  }

  deleteLink(node) {
    if (this.actionPending) { return; }
    let request: LinksManagement = new LinksManagement();

    request.userId = this.userDetails.attuid;
    request.linkId = node.OPT_ID - 40000;
    request.modeOfOrganizeLink = 'DELETE';

    let linkName = node.OPT_NM_TX;

    const dialogRef = this.dialog.open(ConfirmComponent, {
      data: {
        type: ConfigType.Confirm,
        content: `Are you sure you want to delete link: <b>${linkName}</b> ?`
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.actionPending = 'deleteFolder';
        this.service.changeLink(request).subscribe(resp => {
          this.notifService.showSuccessNotification('Successfully removed the link: ' + linkName);
          MyLinksService.reloadData.next(true);
          this.actionPending = null;
        }, err => {
          this.actionPending = null;
        });
      }
    });
  }

  updateLink(node) {
    this.view = 'update';
    this.selectedLink = node;
    this.displayName = node.OPT_NM_TX;
    let link: string = node.OPT_CODE_NM_TX;
    if (link.includes('javascript')) {
      link = link.substring(link.indexOf('(') + 2, link.indexOf(')') - 1);
    }
    link = link.includes('http') ? link : 'http://' + link;
    this.url = link;
  }

  updateLinkSubmit() {
    if (this.actionPending) { return; }
    let request: LinksManagement = new LinksManagement();

    request.userId = this.userDetails.attuid;
    request.linkId = this.selectedLink.OPT_ID - 40000;
    request.modeOfOrganizeLink = 'UPDATE';
    request.displayName = this.displayName;
    request.linkTx = this.url;

    let linkName = this.selectedLink.OPT_NM_TX;

    this.actionPending = 'updateLink';
    this.service.changeLink(request).subscribe(resp => {
      this.notifService.showSuccessNotification('Successfully updated the link: ' + linkName);
      MyLinksService.reloadData.next(true);
      this.actionPending = null;
    }, err => {
      this.actionPending = null;
    });
  }


}
