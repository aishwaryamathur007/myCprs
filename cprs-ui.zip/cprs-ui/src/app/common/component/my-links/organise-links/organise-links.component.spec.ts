import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OrganiseLinksComponent } from './organise-links.component';

describe('OrganiseLinksComponent', () => {
  let component: OrganiseLinksComponent;
  let fixture: ComponentFixture<OrganiseLinksComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OrganiseLinksComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OrganiseLinksComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
