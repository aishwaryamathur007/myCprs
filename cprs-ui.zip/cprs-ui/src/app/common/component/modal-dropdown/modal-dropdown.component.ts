import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'modal-dropdown',
  templateUrl: './modal-dropdown.component.html',
  styleUrls: ['./modal-dropdown.component.scss']
})
export class ModalDropdownComponent implements OnInit {
  selectedValue:any;
  selectedObj:any;
  constructor(public dialogRef: MatDialogRef<ModalDropdownComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this.dialogRef.addPanelClass('confirm-dialog');
    this.dialogRef.disableClose = true;
  }

  ngOnInit() {
    this.selectedValue = this.data.data[0];
  }

  ok() {
    this.dialogRef.close({data:this.selectedValue});
  }

  cancel() {
    this.dialogRef.close(false);
  }

}

