import { Component, EventEmitter, OnInit, Output, OnDestroy, Input } from '@angular/core';
import { FormControl, FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRouteSnapshot } from '@angular/router';
import { AuthGuard } from 'src/app/shared/guards/auth.guard';
import { UserAuthService } from 'src/app/shared/service/user-auth.service';

@Component({
  selector: 'customer-search',
  templateUrl: './customer-search.component.html',
  styleUrls: ['./customer-search.component.scss']
})
export class CustomerSearchComponent implements OnInit {
  @Output() fetchRecords = new EventEmitter();
  @Input() searchData: any;
  @Input() isDashboard: any;
  searchForm: FormGroup;
  fetchingReport: boolean;
  alreadySearchedObj: any;
  stored: any;
  searchSection:boolean = true;
  userObj:any;
  getUserData:any;
  constructor(private fb: FormBuilder, private userAuthService:UserAuthService,private authguard:AuthGuard) { 
    this.getUserData = this.authguard.customerSearch.subscribe(user => {
      this.userObj = user;
    });
  }

  ngOnInit() {
    this.setupSearchForm();
    if(this.userObj['securityLevel'] == 5 || this.userObj['securityLevel'] == 2 || this.userObj['securityLevel'] == 6) {
      if(this.isDashboard && this.userObj['securityLevel'] == 2 || (this.isDashboard && this.userObj['securityLevel'] == 6)){
        this.searchSection = true;
      } else {
        this.searchSection = false;
      }
    } else {
      this.searchSection = true;
    }    
  }


  setupSearchForm() {
    this.searchForm = this.fb.group({
      searchType: new FormControl('1'),
      searchTypeValue: new FormControl(this.searchData)
    });
  }

  fetchReport() {
    let searchObj = this.searchForm.value;
    this.fetchRecords.emit(searchObj);
  }

  cancel() {
    this.searchForm.reset();
  }
  ngOnDestory(){
    this.getUserData.unsbscribe();
  }

}
