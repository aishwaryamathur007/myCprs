import { Component, HostListener, Inject, OnInit } from '@angular/core';
import { MatSnackBarRef, MAT_SNACK_BAR_DATA } from '@angular/material/snack-bar';

@Component({
  selector: 'snackbar',
  templateUrl: './snackbar.component.html',
  styleUrls: ['./snackbar.component.scss']
})
export class SnackbarComponent implements OnInit {

  icon = 'check_circle_outline';
  color = '#0b6900';
  preText: string = '';


  @HostListener('click')
  onClick() {
    this.closeSnackbar();
  }

  constructor(private snackBarRef: MatSnackBarRef<SnackbarComponent>,
    @Inject(MAT_SNACK_BAR_DATA) public data) {
    this.icon = this.data.icon ? this.data.icon : this.icon;
    this.color = this.data.color ? this.data.color : this.color;

    if (this.icon === 'check_circle_outline') {
      this.preText = 'Success:';
    } else if (this.icon === 'highlight_off') {
      this.preText = 'Error:';
    } else if (this.icon === 'warning') {
      this.preText = 'Warning:';
    }
  }

  ngOnInit() {

  }

  closeSnackbar() {
    this.snackBarRef.dismiss();
  }

}
