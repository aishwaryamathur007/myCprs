import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MailAttachementComponent } from './mail-attachement.component';

describe('MailAttachementComponent', () => {
  let component: MailAttachementComponent;
  let fixture: ComponentFixture<MailAttachementComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MailAttachementComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MailAttachementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
