import { Component, Inject, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { DashboardService } from 'src/app/cpr-views/service/dashboard.service';
import { NotificationService } from '../../services/notification.service';

@Component({
  selector: 'mail-attachement',
  templateUrl: './mail-attachement.component.html',
  styleUrls: ['./mail-attachement.component.scss']
})
export class MailAttachementComponent implements OnInit {
  mailForm:FormGroup;
  isSubmit:boolean = false;
  confirMail:boolean = false;
  validMail:boolean = false;
 constructor(public dialogRef: MatDialogRef<MailAttachementComponent>,private dbservice: DashboardService, 
   private notifService: NotificationService, @Inject(MAT_DIALOG_DATA) public data: any) {
    this.dialogRef.addPanelClass('confirm-dialog');
    this.dialogRef.disableClose = true;
  }

  ngOnInit() {
    this.mailForm = new FormGroup({
      fileType: new FormControl('xls', [Validators.required]),
      mailAdd: new FormControl('', [Validators.required,Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")]),
      cMailAdd: new FormControl('', [Validators.required,Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")])
      });
  }

  ok() {
    this.confirMail = false;
    this.validMail = false;
    this.isSubmit = true;
      if(this.mailForm.controls.mailAdd.value != this.mailForm.controls.cMailAdd.value) {
        this.confirMail = true;
      } else if(!(this.mailForm.controls.mailAdd.value).includes('att.com')) {
        this.validMail = true;
      }
       else {
        if(this.mailForm.valid){
          let obj = {
            "cntrctCustId": this.data.custId,
            "cntrctSrceId": this.data.srceId,
            "fileExtensions": this.mailForm.controls.fileType.value,
            "offerEffectiveDate": this.data.offrEffDt,
            "offerId": this.data.offrId,
            "emailAddress": this.mailForm.controls.cMailAdd.value,
            "offrActnId": this.data.offrActnId,
            "annivDt": this.data.annivDt
          };
          this.dbservice.emailOptions(obj,this.data.reportType).subscribe(resp => {
            this.notifService.showSuccessNotification(resp);
            this.dialogRef.close(true);
          },error => {
            this.notifService.showErrorNotification(error);
          });
      }
    }
  }

  cancel() {
    this.dialogRef.close(false);
  }

}

