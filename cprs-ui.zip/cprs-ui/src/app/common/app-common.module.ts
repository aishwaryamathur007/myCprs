import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
// import { ReportTableComponent } from 'src/app/common/component/report-table/report-table.component';
import { 
  ReportTableComponent, 
  DesignModalComponent,
  SaveMyReportModalComponent,
  DrilldownModalComponent
 } from '@report-table-library/common-report-table';
import { SharedModule } from 'src/app/shared/root-material/shared.module';
import { FlexLayoutModule } from '@angular/flex-layout';
//import { DesignModalComponent } from './component/report-table/design-modal/design-modal.component';
import { MatRadioModule } from '@angular/material/radio';
//import { SaveMyReportModalComponent } from './component/report-table/save-my-report-modal/save-my-report-modal.component';
import { MyReportsComponent } from './component/my-reports/my-reports.component';
import { OrganiseReportsComponent } from './component/my-reports/organise-reports/organise-reports.component';
import { MatNativeDateModule, MatRippleModule } from '@angular/material/core';
import { ConfirmComponent } from 'src/app/common/component/confirm/confirm.component';
import { SnackbarComponent } from 'src/app/common/component/snackbar/snackbar.component';
import { MatChipsModule } from '@angular/material/chips';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
//import { DrilldownModalComponent } from './component/report-table/sub-reports/drilldown-modal/drilldown-modal.component';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MyLinksComponent } from './component/my-links/my-links.component';
import { OrganiseLinksComponent } from './component/my-links/organise-links/organise-links.component';
import { AddLinkModalComponent } from './component/my-links/components/add-link-modal/add-link-modal.component';
import { UtilityService } from 'src/app/common/services/utility.service';
import { ErrorNotificationComponent } from './component/error-notification/error-notification.component';
import { ErrorDetailsDialogComponent } from './component/error-notification/error-details-dialog/error-details-dialog.component';
import { CustomerSearchComponent } from './component/customer-search/customer-search.component';
import { ModalDropdownComponent } from './component/modal-dropdown/modal-dropdown.component';
import { MailAttachementComponent } from './component/mail-attachement/mail-attachement.component';


@NgModule({
  declarations: [
    //ReportTableComponent,
    //DesignModalComponent,
    //SaveMyReportModalComponent,
    MyReportsComponent,
    OrganiseReportsComponent,
    ConfirmComponent,
    SnackbarComponent,
    //DrilldownModalComponent,
    MyLinksComponent,
    OrganiseLinksComponent,
    AddLinkModalComponent,
    ErrorNotificationComponent,
    ErrorDetailsDialogComponent,
    CustomerSearchComponent,
    ModalDropdownComponent,
    MailAttachementComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    FlexLayoutModule,
    MatRadioModule,
    MatRippleModule,
    MatChipsModule,
    MatAutocompleteModule,
    MatDatepickerModule,
    MatNativeDateModule
  ],
  exports: [
    //ReportTableComponent,
    MyReportsComponent,
    ConfirmComponent,
    SnackbarComponent,
    //DrilldownModalComponent,
    MyLinksComponent,
    CustomerSearchComponent
  ],
  providers: [
    MatDatepickerModule,
    MatNativeDateModule,
    UtilityService,
    DatePipe
  ]
})
export class AppCommonModule { }
