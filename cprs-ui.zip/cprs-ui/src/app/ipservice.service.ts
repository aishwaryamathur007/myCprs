import { HttpBackend, HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class IpServiceService {
  private http: HttpClient;
  constructor(private handler: HttpBackend) {
    this.http = new HttpClient(handler);
  }
  public getIPAddress(): Observable<string> {
    const key = 'IpAddress';
    const localValue = sessionStorage.getItem(key);
    if (localValue) {
      return of(localValue);
    } else {
      return this.http.get('https://jsonip.com/').pipe(
        map((resp) => {
          const ipAddress = resp['ip'];
          sessionStorage.setItem(key, ipAddress);
          return resp['ip'];
        })
      );
    }
  }
}
