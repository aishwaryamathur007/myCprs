import { APP_BASE_HREF } from '@angular/common';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ConfirmguardGuard } from './shared/guards/confirmguard.guard';

const routes: Routes = [
  {
    path: '',
    loadChildren: () => import('src/app/cpr-views/cpr-views.module').then(m => m.CprViewsModule),
  },
  {
    path: '**', redirectTo: ''
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  providers: [
    ConfirmguardGuard,
    { provide: APP_BASE_HREF, useValue: '/cprs' },
  ]
})
export class AppRoutingModule { }
