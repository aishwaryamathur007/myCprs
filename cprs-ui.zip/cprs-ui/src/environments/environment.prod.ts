export let environment = {
  production: true,
  env: 'prod',
  commonApiBaseUrl: 'https://absdw.web.att.com/common-api',
  cprApiBaseUrl: 'https://absdw.web.att.com/cprs-api',
  oidcUrl: `https://oidc.idp.elogin.att.com/mga/sps/oauth/oauth20/authorize?response_type=code&client_id=absdwweb_PROD&state=#stateString#&redirect_uri=#redirectUri#&scope=openid%20profile%20email%20organization_code`
};
