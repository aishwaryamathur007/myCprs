// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  env: 'local',
<<<<<<< HEAD
  commonApiBaseUrl: 'http://localhost:8085/common-api',
  cprApiBaseUrl: 'http://localhost:8086/cpr-api',
=======
  //commonApiBaseUrl: 'http://localhost:8085/common-api',
  commonApiBaseUrl: 'https://absweb.dev.att.com/common-api',
  //cprApiBaseUrl: 'http://localhost:8084/cprs-api',
  cprApiBaseUrl: 'https://absweb.dev.att.com/cprs-api',
>>>>>>> 88205ffe39f662c668d4cd51b73c93099aae423a
  oidcUrl: `https://oidc.stage.elogin.att.com/mga/sps/oauth/oauth20/authorize?response_type=code&client_id=absdwsuite_NONPROD&state=#stateString#&redirect_uri=#redirectUri#&scope=openid%20profile%20email`
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.