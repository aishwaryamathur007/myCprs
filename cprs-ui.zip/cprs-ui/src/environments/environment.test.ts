export let environment = {
  production: true,
  env: 'test',
  commonApiBaseUrl: 'https://absweb.test.att.com/common-api',
  cprApiBaseUrl: 'https://absweb.test.att.com/cprs-api',
  oidcUrl: `https://oidc.idp.elogin.att.com/mga/sps/oauth/oauth20/authorize?response_type=code&client_id=absdwuat_PROD&state=#stateString#&redirect_uri=#redirectUri#&scope=openid%20profile%20email%20organization_code`
};
