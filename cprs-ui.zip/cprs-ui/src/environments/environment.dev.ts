export let environment = {
  production: true,
  env: 'dev',
  commonApiBaseUrl: 'https://absweb.dev.att.com/common-api',
  cprApiBaseUrl: 'https://absweb.dev.att.com/cprs-api',
  oidcUrl: `https://oidc.idp.elogin.att.com/mga/sps/oauth/oauth20/authorize?response_type=code&client_id=absdw_PROD&state=#stateString#&redirect_uri=#redirectUri#&scope=openid%20profile%20email%20organization_code`
};
