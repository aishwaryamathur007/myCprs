import { HttpClient } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { BehaviorSubject, forkJoin, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { ReportManagement } from '../models/report-management';

@Injectable({
  providedIn: 'root'
})
export class MyReportsService {

  // commonApiBaseUrl = 'http://localhost:8084/common-api'
  static reloadData: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  constructor(private http: HttpClient, @Inject('env') private env) { }

  getVisbileReports(userId: string, appId: string[]): Observable<any> {
    return this.http.get(this.env.commonApiBaseUrl + '/reports/getVisibleReports', {
      params: {
        userId: userId,
        appId: appId,
        reportId: '1'
      }
    }).pipe(map(response => {

      let array = this.listToTree(response);
      return { flatData: response, tree: array };
    }));
  }

  listToTree(list) {
    let mapLookupData = {};
    let currentNode;
    let result = [];

    for (let i = 0; i < list.length; i += 1) {
      mapLookupData[list[i].OPT_ID + ''] = i; // init the map lookup of each LOC_ID
      if (list[i].RPT_ID > 0) {
        list[i].type = 'report';
      } else {
        list[i].type = 'folder';
        list[i].children = [];
      }
      // init the elements with children []
    }
    // tslint:disable-next-line: prefer-for-of
    for (let i = 0; i < list.length; i += 1) {
      currentNode = list[i];

      if (+currentNode.PARNT_OPT_ID > 0) {

        list[mapLookupData[currentNode.PARNT_OPT_ID]].children.push(currentNode);
      } else {
        result.push(currentNode);
      }
    }
    return result;
  }

  changeReport(request: ReportManagement): Observable<any> {
    return this.http.post<any>(this.env.commonApiBaseUrl + '/reports/reportManagement', request, {
      responseType: 'text' as 'json'
    });
  }

  getInvisibleCustomReports(appId: string[], userId: string): Observable<any> {
    return this.http.get(this.env.commonApiBaseUrl + '/reports/getInvisibleReports', {
      params: {
        appId,
        userId
      }
    });
  }

  getOwnerDetails(reportBmrkId: string): Observable<any> {
    return this.http.get(this.env.commonApiBaseUrl + '/reports/getMpiContactDetails', {
      params: {
        reportBmrkId
      }
    });
  }

  getUserOwnerAccess(reportBkmkId: string, userId: string): Observable<any> {
    return this.http.get(this.env.commonApiBaseUrl + '/reports/validateReportPermissionForUser', {
      params: {
        reportBkmkId,
        userId
      }
    });
  }

  getMasterUserList(appId: string, reportBmrkId: string): Observable<any> {
    return this.http.get(this.env.commonApiBaseUrl + '/reports/getMasterUserList', {
      params: {
        appId,
        reportBmrkId
      }
    });
  }

  getAccessGrantedUserList(reportBmrkId: string): Observable<any> {
    return this.http.get(this.env.commonApiBaseUrl + '/reports/getAccessUserList', {
      params: {
        reportBmrkId
      }
    });
  }

  getMasterGroupList(appId: string, reportBmrkId: string): Observable<any> {
    return this.http.get(this.env.commonApiBaseUrl + '/reports/getMasterGroupList', {
      params: {
        appId,
        reportBmrkId
      }
    });
  }

  getAccessGroupList(appId: string, reportBmrkId: string): Observable<any> {
    return this.http.get(this.env.commonApiBaseUrl + '/reports/getAccessGroupList', {
      params: {
        appId,
        reportBmrkId
      }
    });
  }

  async getUserAccesGrantDetails(reportBmrkId: string, appId: string): Promise<any> {
    let masterList = [];
    let accessList = [];

    let masterUserList = [];
    let masterGroupList = [];
    await forkJoin([this.getMasterUserList(appId, reportBmrkId),
    this.getAccessGrantedUserList(reportBmrkId),
    this.getMasterGroupList(appId, reportBmrkId),
    this.getAccessGroupList(appId, reportBmrkId),
    ]).toPromise().then(resp => {
      let users = resp[0].concat(resp[1]);
      masterUserList = (users as any[]).map(user => `${user.firstNm} ${user.lastNm} (${user.webUserId})`);
      let accessUserList = (resp[1] as any[]).map(user => `${user.firstNm} ${user.lastNm} (${user.webUserId})`);

      let groups = resp[2].concat(resp[3]);
      masterGroupList = (groups as any[]).map(user => `${user.BKMK_GP_NM_TX}`);
      let accessGroupsList = (resp[3] as any[]).map(user => `${user.BKMK_GP_NM_TX}`);

      masterList = masterUserList.concat(masterGroupList);
      accessList = accessUserList.concat(accessGroupsList);
    });


    return {
      masterList: masterList, accessList: accessList, allUsers: masterUserList, allGroups: masterGroupList
    };
  }

}
