import { ReportSavePackage } from "../../report-table/models/report-save-package";

export class ReportManagement {
    appId: number;
    reportId: number;
    appName: string;
    bkmkId: number;
    reportName: string;
    mode: string;
    userId: string;
    locId: number;
    bkmkPkgTx: ReportSavePackage;
    modeOfOrganizeReport: string;
    mpiReportUserDataDetails: string[];
}
