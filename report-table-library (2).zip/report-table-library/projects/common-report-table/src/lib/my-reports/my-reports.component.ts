import { NestedTreeControl } from '@angular/cdk/tree';
import { AfterViewInit, Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { MatTree, MatTreeNestedDataSource } from '@angular/material/tree';
import { MyReportsService } from './service/my-reports.service';
import { ReportTableService } from '../report-table/service/report-table.service';
import { NotificationService } from '../services/notification.service';

@Component({
  selector: 'lib-my-reports',
  templateUrl: './my-reports.component.html',
  styleUrls: ['./my-reports.component.scss']
})
export class MyReportsComponent implements OnInit {

  @Input() appId: string[];
  @Input() appName;
  @Input() userDetails: any;
  @Output() openSubReportActionFromReports: EventEmitter<any> = new EventEmitter();

  flatData: any;
  treeControl = new NestedTreeControl<any>(node => node.children);
  dataSource = new MatTreeNestedDataSource<any>();
  mapLookupData: any = {};
  show = false;
  treeData: any;
  showReport = false;
  selectedNode: any = null;
  selectedTab = 0;
  addReportActionName: any = '';

  constructor(private myReportService: MyReportsService,
              private notifService: NotificationService) { }


  ngOnInit(): void {
    MyReportsService.reloadData.subscribe(val => {
      if (val) {
        this.showReport = false;
        this.getData();
      }
    });
    this.getData();
  }

  hasChild = (_: number, node: any) => !!node.children && node.children.length > 0;

  async getData(reloadForAdd = false) {
    this.show = false;

    await this.myReportService.getVisbileReports(this.userDetails.attuid, this.appId).toPromise().then(resp => {
      this.flatData = resp.flatData;
      this.setMapLookup();
      this.treeData = resp.tree;
      this.dataSource.data = resp.tree;
      this.treeControl.dataNodes = resp.tree;

      if (this.selectedNode) {
        if (reloadForAdd) {
          const optId = this.findReportInMapByName(this.addReportActionName);
          const newSelectedNode = this.flatData[this.mapLookupData[optId]];
          this.openReport(newSelectedNode);
        } else {
          const optId = this.selectedNode.OPT_ID;
          const newSelectedNode = this.flatData[this.mapLookupData[optId]];
          this.openReport(newSelectedNode);
        }

      }
      this.show = true;
      this.treeControl.expandAll();
    });
  }

  setMapLookup() {
    for (let i = 0; i < this.flatData.length; i += 1) {
      this.mapLookupData[this.flatData[i].OPT_ID] = i;
    }
  }

  findReportInMapByName(name: string) {
    // tslint:disable-next-line: forin
    for (const key in this.mapLookupData) {
      const value = this.flatData[this.mapLookupData[key]];
      if (value.type === 'report' && value.OPT_NM_TX.includes(name)) {
        return value.OPT_ID;
      }
    }
    return -1;
  }

  openReport(node) {
    this.showReport = false;
    setTimeout(() => {
      this.showReport = true;
      this.selectedNode = node;
    }, 500);

  }

  reloadAction(event) {

    if (event.action === 'reload-my-reports') {
      this.getData();
    } else if (event.action === 'reload-my-reports-add') {
      this.addReportActionName = event.reportName;
      this.getData(true);
    }

  }

  openSubReportEvent(event) {
    this.openSubReportActionFromReports.emit(event);
  }

}
