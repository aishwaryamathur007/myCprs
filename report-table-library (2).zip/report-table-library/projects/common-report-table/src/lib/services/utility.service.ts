import { DatePipe } from '@angular/common';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UtilityService {

  constructor(private datePipe: DatePipe, private http: HttpClient) { }

  toDateFromString(dateStringValue: string): Date {
    // Converts only string in "yyyy-mm-dd" format
    if (!dateStringValue) {
      return null;
    }
    dateStringValue = this.datePipe.transform(dateStringValue, 'yyyy-MM-dd');
    const dateArr = dateStringValue.split('-');

    return new Date(parseInt(dateArr[0], 10), parseInt(dateArr[1], 10) - 1, parseInt(dateArr[2], 10));
  }

  getStringFromDate(date: Date, format): any {
    if (!date) {
      return '';
    }
    const dateStringFormat: string = this.datePipe.transform(date, format);
    return dateStringFormat.replace(/T.*/gi, '');
  }
}
