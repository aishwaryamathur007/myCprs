import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  firstName: string = 'Firstname';
  lastName: string = 'Lastname';
  fullName: string;
  attuid: string = 'ps573k';
  email: string;
  orgCode: string;
  constructor(private http: HttpClient) {
  }

  setUserDetails(obj: any) {

    this.firstName = obj.firstName;
    this.lastName = obj.lastName;
    this.fullName = obj.fullName;
    this.attuid = obj.attuid;
    this.email = obj.email;
    this.orgCode = obj.orgCode;
  }

  getUserDetails() {
    let user: UserDetails = {
      firstName: this.firstName,
      lastName: this.lastName,
      fullName: this.fullName,
      attuid: this.attuid,
      email: this.email,
      orgCode: this.orgCode
    };
    return user;
  }


}

export interface UserDetails {
  firstName: string;
  lastName: string;
  fullName: string;
  attuid: string;
  email: string;
  orgCode: string;
}

