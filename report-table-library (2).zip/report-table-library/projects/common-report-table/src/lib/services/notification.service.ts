import { Injectable } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { SnackbarComponent } from '../snackbar/snackbar.component';

export const DISMISS_TIME = 8000;
@Injectable({
  providedIn: 'root'
})
export class NotificationService {


  constructor(private snackBar: MatSnackBar) { }

  showErrorNotification(message: string, icon: string = 'highlight_off', color: string = '#a31b0b', dismiss = DISMISS_TIME) {
    this.snackBar.openFromComponent(SnackbarComponent, {
      data: {
        message: message,
        icon: icon,
        color: color
      },
      verticalPosition: 'top',
      horizontalPosition: 'center',
      duration: dismiss,
    });
  }

  showSuccessNotification(message: string, icon: string = '', color: string = '', dismiss = DISMISS_TIME) {
    this.snackBar.openFromComponent(SnackbarComponent, {
      data: {
        message: message,
        icon: icon,
        color: color
      },
      verticalPosition: 'top',
      horizontalPosition: 'center',
      duration: dismiss
    });
  }

  showWarningNotification(message: string, icon: string = 'warning_amber', color: string = '#fc7703', dismiss = DISMISS_TIME) {
    this.snackBar.openFromComponent(SnackbarComponent, {
      data: {
        message: message,
        icon: icon,
        color: color
      },
      verticalPosition: 'top',
      horizontalPosition: 'center',
      duration: 15000,
    });
  }

}
