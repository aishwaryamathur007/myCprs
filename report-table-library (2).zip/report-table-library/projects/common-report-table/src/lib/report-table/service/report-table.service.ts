import { HttpClient } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { ReportRequestDetails } from '../models/report-request-details';

@Injectable({
  providedIn: 'root'
})
export class ReportTableService {

  // commonApiBaseUrl = 'http://localhost:8084/common-api'

  constructor(private http: HttpClient, @Inject('env') private env) { }

  getReportData(request: ReportRequestDetails): Observable<any> {
    return this.http.post<any>(this.env.commonApiBaseUrl + '/reports/getReportDetails', request);
  }

  getReportSettings(appId: string, reportId: string, bkmkId: string, colsOrderOverride: string): Observable<any> {
    return this.http.get<any>(this.env.commonApiBaseUrl + '/reports/getReportSettings', {
      params: {
        appId,
        reportId,
        bkmkId
      }
    }).pipe(map(response => {
      return response.map(x => {

        let columnNames = x?.COL_DSPL_TITLS_TX?.split(';^;') ?? [];
        let colSettings = [];
        let defaultColumns = x?.DFLT_COLS_TX?.split(',') ?? [];
        let columnFilterDisable = x?.COL_FILTER_DISABLE?.split(',') ?? [];
        defaultColumns = colsOrderOverride ? colsOrderOverride.split(',') ?? [] : defaultColumns;
        columnNames.forEach((element, index) => {
          let obj = {
            columnNumber: index + 1 + '',
            columnName: element?.replace(';^', ''),
            bind: (x?.COL_NM_TX?.split(';^;') ?? [])[index]?.replace(';^', ''),
            show: defaultColumns.includes(index + 1 + '') ? true : false,
            order: defaultColumns.indexOf(index + 1 + '') + 1,
            disableFilter: columnFilterDisable.includes(index + 1 + '') ? true : false,
            dataType: (x?.DATA_TYPE_TX?.split(',') ?? [])[index],
            fieldType: (x?.FLD_TYPE_TX?.split(',') ?? [])[index],
            formulaTx: (x?.FORMULAS_TX?.split(';^;') ?? [])[index],
            sqlColName: (x?.SQL_COL_NM_TX?.split(';^;') ?? [])[index],
          };
          colSettings.push(obj);

        });

        colSettings = colSettings.filter(a => a.order)
          .sort((a, b) => a.order - b.order)
          .concat(colSettings.filter(a => !a.order));

        let sortOrdersString = x?.DFLT_SORT_TX ?? '';

        let sortOrder = sortOrdersString.split(',').filter(ele => defaultColumns.includes(ele.split(' ')[0])).map(a => {
          let order = a.split(' ');

          return {
            bind: (x?.COL_NM_TX?.split(';^;') ?? [])[order[0] - 1],
            columnName: (x?.COL_DSPL_TITLS_TX?.split(';^;') ?? [])[order[0] - 1],
            order: order[1],
            columnNumber: order[0]
          };
        });

        return {
          rptCodeName: x.RPT_CODE_NM_TX,
          reportDesc: x.RPT_DESC_TX,
          reportName: bkmkId ? x.BKMK_NM_TX : x.RPT_NM_TX,
          colSettings: colSettings,
          sortOrder: sortOrder,
          subReportDetails: x.SUB_RPTS_DETAILS,
          originalSettingsData: x
        };
      });

    }));
  }


  getReportFilterSearch(reportId: string, sqlColName: string, searchValue): Observable<any> {
    return this.http.get(this.env.commonApiBaseUrl + '/reports/getReportFilterSearch', {
      params: {
        reportId,
        sqlColName,
        searchValue
      }
    });
  }

  downloadReport(requestBody) {
    return this.http.post(this.env.commonApiBaseUrl + '/reports/downloadReport', requestBody,
      {
        responseType: 'blob'
      });
  }

  getUserLocations(userId: string): Observable<any> {
    return this.http.get(this.env.commonApiBaseUrl + '/reports/getBkmkLocIdByUser', {
      params: {
        userId
      }
    }).pipe(map(response => {

      let array = [{
        LOC_ID: 0,
        LOC_NM_TX: 'My Reports',
        PARNT_LOC_ID: -1,
        children: this.listToTree(response)
      }];
      return { flatData: response, tree: array };
    }));
  }

  listToTree(list) {
    let mapLookupData = {};
    let currentNode;
    let result = [];

    for (let i = 0; i < list.length; i += 1) {
      mapLookupData[list[i].LOC_ID] = i; // init the map lookup of each LOC_ID
      list[i].children = []; // init the elements with children []
    }

    // tslint:disable-next-line: prefer-for-of
    for (let i = 0; i < list.length; i += 1) {
      currentNode = list[i];

      if (currentNode.PARNT_LOC_ID !== 0) {
        list[mapLookupData[currentNode.PARNT_LOC_ID]].children.push(currentNode);
      } else {
        result.push(currentNode);
      }
    }
    return result;
  }

  addBookmarkLocation(locationName: string, parentLocId: string, userId: string): Observable<any> {
    return this.http.get(this.env.commonApiBaseUrl + '/reports/addBkmkLocId', {
      params: {
        locationName,
        parentLocId,
        userId
      },
      responseType: 'text' as 'json'
    });
  }

}
