import { ReportColumnDetails } from './report-column-details';
import { ReportFilter } from './report-filter';
import { ReportSortDetails } from './report-sort-details';

export class ReportRequestDetails {

    appId: number;
    reportId: number;
    filter: ReportFilter[] = [];
    originFilter: ReportFilter[] = [];
    origin: string = '4';
    listOfColumnDetails: ReportColumnDetails[] = [];
    listOfSortingDetail: ReportSortDetails[] = [];
    webUId: string;
    extras: any;
}
