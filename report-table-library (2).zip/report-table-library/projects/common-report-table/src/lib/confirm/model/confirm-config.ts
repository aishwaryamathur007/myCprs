export enum ConfigType {
    Confirm = 1,
    Alert = 2
}

export class ConfirmConfig {
    type: ConfigType = ConfigType.Confirm;
    content: string = ''; // This can be HTML to support lists , url and other functions.;
}
