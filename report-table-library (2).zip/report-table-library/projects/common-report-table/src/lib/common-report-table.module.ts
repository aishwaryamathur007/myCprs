import { ModuleWithProviders, NgModule } from '@angular/core';
// import { CommonReportTableComponent } from './common-report-table.component';
import { ReportTableComponent } from './report-table/report-table.component';
import { DesignModalComponent } from './report-table/design-modal/design-modal.component';
import { SaveMyReportModalComponent } from './report-table/save-my-report-modal/save-my-report-modal.component';
import { DrilldownModalComponent } from './report-table/sub-reports/drilldown-modal/drilldown-modal.component';
// import { AppRoutingModule } from './app-routing.module';
import { MatRadioModule } from '@angular/material/radio';
import { MatNativeDateModule, MatRippleModule } from '@angular/material/core';
import { MatChipsModule } from '@angular/material/chips';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatInputModule } from '@angular/material/input';
import { MatTableModule } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSortModule } from '@angular/material/sort';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { MatCardModule } from '@angular/material/card';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatSelectModule } from '@angular/material/select';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatIconModule } from '@angular/material/icon';
import { MatDividerModule } from '@angular/material/divider';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatListModule } from '@angular/material/list';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatTabsModule } from '@angular/material/tabs';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatMenuModule } from '@angular/material/menu';
import { MatBadgeModule } from '@angular/material/badge';
import { MatTreeModule } from '@angular/material/tree';
import { CdkTreeModule } from '@angular/cdk/tree';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonModule } from '@angular/common';
import { SnackbarComponent } from './snackbar/snackbar.component';
import { MyReportsComponent } from './my-reports/my-reports.component';
import { OrganiseReportsComponent } from './my-reports/organise-reports/organise-reports.component';
import { ConfirmComponent } from './confirm/confirm.component';


@NgModule({
  declarations: [ReportTableComponent, DesignModalComponent, SaveMyReportModalComponent, DrilldownModalComponent, SnackbarComponent, MyReportsComponent, OrganiseReportsComponent, ConfirmComponent],
  imports: [
    MatRadioModule,
    MatNativeDateModule,
    MatRippleModule,
    MatChipsModule,
    MatInputModule,
    MatTableModule,
    MatAutocompleteModule,
    MatDatepickerModule,
    MatFormFieldModule,
    MatPaginatorModule,
    MatCheckboxModule,
    MatSortModule,
    MatDialogModule,
    MatButtonModule,
    MatCardModule,
    DragDropModule,
    MatSelectModule,
    MatToolbarModule,
    MatSidenavModule,
    MatIconModule,
    MatDividerModule,
    MatProgressSpinnerModule,
    MatListModule,
    MatExpansionModule,
    MatTabsModule,
    MatTooltipModule,
    MatButtonToggleModule,
    MatMenuModule,
    MatBadgeModule,
    MatTreeModule,
    CdkTreeModule,
    MatSnackBarModule,
    FlexLayoutModule,
    CommonModule,
    FormsModule,
    ReactiveFormsModule

  ],
  exports: [ReportTableComponent, DesignModalComponent, SaveMyReportModalComponent, DrilldownModalComponent, SnackbarComponent, MyReportsComponent, OrganiseReportsComponent, ConfirmComponent]
})
export class CommonReportTableModule {
  public static forRoot(environment: { [key: string]: any }): ModuleWithProviders<CommonReportTableModule> {

    return {
      ngModule: CommonReportTableModule,
      providers: [
        {
          provide: 'env',
          useValue: environment
        }
      ]
    };
  }
}
